{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {
    "id": "PGvPDrFRFryZ"
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: dataprep in d:\\anaconda\\lib\\site-packages (0.4.5)\n",
      "Requirement already satisfied: metaphone<0.7,>=0.6 in d:\\anaconda\\lib\\site-packages (from dataprep) (0.6)\n",
      "Requirement already satisfied: varname<0.9.0,>=0.8.1 in d:\\anaconda\\lib\\site-packages (from dataprep) (0.8.3)\n",
      "Requirement already satisfied: scipy<2.0,>=1.8 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.11.1)\n",
      "Requirement already satisfied: jsonpath-ng<2.0,>=1.5 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.5.3)\n",
      "Requirement already satisfied: flask<3,>=2 in d:\\anaconda\\lib\\site-packages (from dataprep) (2.2.5)\n",
      "Requirement already satisfied: aiohttp<4.0,>=3.6 in d:\\anaconda\\lib\\site-packages (from dataprep) (3.8.1)\n",
      "Requirement already satisfied: pandas<2.0,>=1.1 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.3.5)\n",
      "Requirement already satisfied: nltk<4.0.0,>=3.6.7 in d:\\anaconda\\lib\\site-packages (from dataprep) (3.7)\n",
      "Requirement already satisfied: python-stdnum<2.0,>=1.16 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.18)\n",
      "Requirement already satisfied: regex<2022.0.0,>=2021.8.3 in d:\\anaconda\\lib\\site-packages (from dataprep) (2021.11.10)\n",
      "Requirement already satisfied: wordcloud<2.0,>=1.8 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.9.2)\n",
      "Requirement already satisfied: numpy<2.0,>=1.21 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.22.4)\n",
      "Requirement already satisfied: tqdm<5.0,>=4.48 in d:\\anaconda\\lib\\site-packages (from dataprep) (4.64.0)\n",
      "Requirement already satisfied: jinja2<3.1,>=3.0 in d:\\anaconda\\lib\\site-packages (from dataprep) (3.0.3)\n",
      "Requirement already satisfied: ipywidgets<8.0,>=7.5 in d:\\anaconda\\lib\\site-packages (from dataprep) (7.6.5)\n",
      "Requirement already satisfied: rapidfuzz<3.0.0,>=2.1.2 in d:\\anaconda\\lib\\site-packages (from dataprep) (2.15.1)\n",
      "Requirement already satisfied: python-crfsuite==0.9.8 in d:\\anaconda\\lib\\site-packages (from dataprep) (0.9.8)\n",
      "Requirement already satisfied: sqlalchemy==1.3.24 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.3.24)\n",
      "Requirement already satisfied: bokeh<3,>=2 in d:\\anaconda\\lib\\site-packages (from dataprep) (2.4.2)\n",
      "Requirement already satisfied: pydot<2.0.0,>=1.4.2 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.4.2)\n",
      "Requirement already satisfied: flask_cors<4.0.0,>=3.0.10 in d:\\anaconda\\lib\\site-packages (from dataprep) (3.0.10)\n",
      "Requirement already satisfied: pydantic<2.0,>=1.6 in d:\\anaconda\\lib\\site-packages (from dataprep) (1.10.12)\n",
      "Requirement already satisfied: dask[array,dataframe,delayed]>=2022.3.0 in d:\\anaconda\\lib\\site-packages (from dataprep) (2023.8.0)\n",
      "Requirement already satisfied: yarl<2.0,>=1.0 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (1.6.3)\n",
      "Requirement already satisfied: charset-normalizer<3.0,>=2.0 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (2.0.4)\n",
      "Requirement already satisfied: multidict<7.0,>=4.5 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (5.1.0)\n",
      "Requirement already satisfied: attrs>=17.3.0 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (21.4.0)\n",
      "Requirement already satisfied: aiosignal>=1.1.2 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (1.2.0)\n",
      "Requirement already satisfied: frozenlist>=1.1.1 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (1.2.0)\n",
      "Requirement already satisfied: async-timeout<5.0,>=4.0.0a3 in d:\\anaconda\\lib\\site-packages (from aiohttp<4.0,>=3.6->dataprep) (4.0.1)\n",
      "Requirement already satisfied: typing-extensions>=3.6.5 in d:\\anaconda\\lib\\site-packages (from async-timeout<5.0,>=4.0.0a3->aiohttp<4.0,>=3.6->dataprep) (4.7.1)\n",
      "Requirement already satisfied: tornado>=5.1 in d:\\anaconda\\lib\\site-packages (from bokeh<3,>=2->dataprep) (6.1)\n",
      "Requirement already satisfied: pillow>=7.1.0 in d:\\anaconda\\lib\\site-packages (from bokeh<3,>=2->dataprep) (9.0.1)\n",
      "Requirement already satisfied: packaging>=16.8 in d:\\anaconda\\lib\\site-packages (from bokeh<3,>=2->dataprep) (21.3)\n",
      "Requirement already satisfied: PyYAML>=3.10 in d:\\anaconda\\lib\\site-packages (from bokeh<3,>=2->dataprep) (6.0)\n",
      "Requirement already satisfied: cloudpickle>=1.5.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (2.0.0)\n",
      "Requirement already satisfied: fsspec>=2021.09.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (2022.2.0)\n",
      "Requirement already satisfied: toolz>=0.10.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (0.11.2)\n",
      "Requirement already satisfied: click>=8.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (8.0.4)\n",
      "Requirement already satisfied: importlib-metadata>=4.13.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (6.8.0)\n",
      "Requirement already satisfied: partd>=1.2.0 in d:\\anaconda\\lib\\site-packages (from dask[array,dataframe,delayed]>=2022.3.0->dataprep) (1.2.0)\n",
      "Requirement already satisfied: colorama in d:\\anaconda\\lib\\site-packages (from click>=8.0->dask[array,dataframe,delayed]>=2022.3.0->dataprep) (0.4.4)\n",
      "Requirement already satisfied: Werkzeug>=2.2.2 in d:\\anaconda\\lib\\site-packages (from flask<3,>=2->dataprep) (2.3.6)\n",
      "Requirement already satisfied: itsdangerous>=2.0 in d:\\anaconda\\lib\\site-packages (from flask<3,>=2->dataprep) (2.0.1)\n",
      "Requirement already satisfied: Six in d:\\anaconda\\lib\\site-packages (from flask_cors<4.0.0,>=3.0.10->dataprep) (1.16.0)\n",
      "Requirement already satisfied: zipp>=0.5 in d:\\anaconda\\lib\\site-packages (from importlib-metadata>=4.13.0->dask[array,dataframe,delayed]>=2022.3.0->dataprep) (3.7.0)\n",
      "Requirement already satisfied: ipython>=4.0.0 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (8.2.0)\n",
      "Requirement already satisfied: nbformat>=4.2.0 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (5.3.0)\n",
      "Requirement already satisfied: ipython-genutils~=0.2.0 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (0.2.0)\n",
      "Requirement already satisfied: ipykernel>=4.5.1 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (6.9.1)\n",
      "Requirement already satisfied: jupyterlab-widgets>=1.0.0 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (1.0.0)\n",
      "Requirement already satisfied: traitlets>=4.3.1 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (5.1.1)\n",
      "Requirement already satisfied: widgetsnbextension~=3.5.0 in d:\\anaconda\\lib\\site-packages (from ipywidgets<8.0,>=7.5->dataprep) (3.5.2)\n",
      "Requirement already satisfied: debugpy<2.0,>=1.0.0 in d:\\anaconda\\lib\\site-packages (from ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (1.5.1)\n",
      "Requirement already satisfied: jupyter-client<8.0 in d:\\anaconda\\lib\\site-packages (from ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (6.1.12)\n",
      "Requirement already satisfied: nest-asyncio in d:\\anaconda\\lib\\site-packages (from ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (1.5.5)\n",
      "Requirement already satisfied: matplotlib-inline<0.2.0,>=0.1.0 in d:\\anaconda\\lib\\site-packages (from ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (0.1.2)\n",
      "Requirement already satisfied: pygments>=2.4.0 in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (2.11.2)\n",
      "Requirement already satisfied: setuptools>=18.5 in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (67.7.1)\n",
      "Requirement already satisfied: decorator in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (5.1.1)\n",
      "Requirement already satisfied: stack-data in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.2.0)\n",
      "Requirement already satisfied: backcall in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.2.0)\n",
      "Requirement already satisfied: prompt-toolkit!=3.0.0,!=3.0.1,<3.1.0,>=2.0.0 in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (3.0.20)\n",
      "Requirement already satisfied: pickleshare in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.7.5)\n",
      "Requirement already satisfied: jedi>=0.16 in d:\\anaconda\\lib\\site-packages (from ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.18.1)\n",
      "Requirement already satisfied: parso<0.9.0,>=0.8.0 in d:\\anaconda\\lib\\site-packages (from jedi>=0.16->ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.8.3)\n",
      "Requirement already satisfied: MarkupSafe>=2.0 in d:\\anaconda\\lib\\site-packages (from jinja2<3.1,>=3.0->dataprep) (2.1.3)\n",
      "Requirement already satisfied: ply in d:\\anaconda\\lib\\site-packages (from jsonpath-ng<2.0,>=1.5->dataprep) (3.11)\n",
      "Requirement already satisfied: pyzmq>=13 in d:\\anaconda\\lib\\site-packages (from jupyter-client<8.0->ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (22.3.0)\n",
      "Requirement already satisfied: jupyter-core>=4.6.0 in d:\\anaconda\\lib\\site-packages (from jupyter-client<8.0->ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (4.9.2)\n",
      "Requirement already satisfied: python-dateutil>=2.1 in d:\\anaconda\\lib\\site-packages (from jupyter-client<8.0->ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (2.8.2)\n",
      "Requirement already satisfied: pywin32>=1.0 in d:\\anaconda\\lib\\site-packages (from jupyter-core>=4.6.0->jupyter-client<8.0->ipykernel>=4.5.1->ipywidgets<8.0,>=7.5->dataprep) (302)\n"
     ]
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: jsonschema>=2.6 in d:\\anaconda\\lib\\site-packages (from nbformat>=4.2.0->ipywidgets<8.0,>=7.5->dataprep) (4.4.0)\n",
      "Requirement already satisfied: fastjsonschema in d:\\anaconda\\lib\\site-packages (from nbformat>=4.2.0->ipywidgets<8.0,>=7.5->dataprep) (2.15.1)\n",
      "Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in d:\\anaconda\\lib\\site-packages (from jsonschema>=2.6->nbformat>=4.2.0->ipywidgets<8.0,>=7.5->dataprep) (0.18.0)\n",
      "Requirement already satisfied: joblib in d:\\anaconda\\lib\\site-packages (from nltk<4.0.0,>=3.6.7->dataprep) (1.3.1)\n",
      "Requirement already satisfied: pyparsing!=3.0.5,>=2.0.2 in d:\\anaconda\\lib\\site-packages (from packaging>=16.8->bokeh<3,>=2->dataprep) (3.0.4)\n",
      "Requirement already satisfied: pytz>=2017.3 in d:\\anaconda\\lib\\site-packages (from pandas<2.0,>=1.1->dataprep) (2021.3)\n",
      "Requirement already satisfied: locket in d:\\anaconda\\lib\\site-packages (from partd>=1.2.0->dask[array,dataframe,delayed]>=2022.3.0->dataprep) (0.2.1)\n",
      "Requirement already satisfied: wcwidth in d:\\anaconda\\lib\\site-packages (from prompt-toolkit!=3.0.0,!=3.0.1,<3.1.0,>=2.0.0->ipython>=4.0.0->ipywidgets<8.0,>=7.5->dataprep) (0.2.5)\n",
      "Requirement already satisfied: executing<0.9.0,>=0.8.3 in d:\\anaconda\\lib\\site-packages (from varname<0.9.0,>=0.8.1->dataprep) (0.8.3)\n",
      "Requirement already satisfied: pure_eval<1.0.0 in d:\\anaconda\\lib\\site-packages (from varname<0.9.0,>=0.8.1->dataprep) (0.2.2)\n",
      "Requirement already satisfied: asttokens<3.0.0,>=2.0.0 in d:\\anaconda\\lib\\site-packages (from varname<0.9.0,>=0.8.1->dataprep) (2.0.5)\n",
      "Requirement already satisfied: notebook>=4.4.1 in d:\\anaconda\\lib\\site-packages (from widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (6.4.8)\n",
      "Requirement already satisfied: Send2Trash>=1.8.0 in d:\\anaconda\\lib\\site-packages (from notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (1.8.0)\n",
      "Requirement already satisfied: prometheus-client in d:\\anaconda\\lib\\site-packages (from notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.13.1)\n",
      "Requirement already satisfied: nbconvert in d:\\anaconda\\lib\\site-packages (from notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (6.4.4)\n",
      "Requirement already satisfied: terminado>=0.8.3 in d:\\anaconda\\lib\\site-packages (from notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.13.1)\n",
      "Requirement already satisfied: argon2-cffi in d:\\anaconda\\lib\\site-packages (from notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (21.3.0)\n",
      "Requirement already satisfied: pywinpty>=1.1.0 in d:\\anaconda\\lib\\site-packages (from terminado>=0.8.3->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (2.0.2)\n",
      "Requirement already satisfied: matplotlib in d:\\anaconda\\lib\\site-packages (from wordcloud<2.0,>=1.8->dataprep) (3.5.1)\n",
      "Requirement already satisfied: idna>=2.0 in d:\\anaconda\\lib\\site-packages (from yarl<2.0,>=1.0->aiohttp<4.0,>=3.6->dataprep) (3.3)\n",
      "Requirement already satisfied: argon2-cffi-bindings in d:\\anaconda\\lib\\site-packages (from argon2-cffi->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (21.2.0)\n",
      "Requirement already satisfied: cffi>=1.0.1 in d:\\anaconda\\lib\\site-packages (from argon2-cffi-bindings->argon2-cffi->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (1.15.0)\n",
      "Requirement already satisfied: pycparser in d:\\anaconda\\lib\\site-packages (from cffi>=1.0.1->argon2-cffi-bindings->argon2-cffi->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (2.21)\n",
      "Requirement already satisfied: kiwisolver>=1.0.1 in d:\\anaconda\\lib\\site-packages (from matplotlib->wordcloud<2.0,>=1.8->dataprep) (1.3.2)\n",
      "Requirement already satisfied: cycler>=0.10 in d:\\anaconda\\lib\\site-packages (from matplotlib->wordcloud<2.0,>=1.8->dataprep) (0.11.0)\n",
      "Requirement already satisfied: fonttools>=4.22.0 in d:\\anaconda\\lib\\site-packages (from matplotlib->wordcloud<2.0,>=1.8->dataprep) (4.25.0)\n",
      "Requirement already satisfied: jupyterlab-pygments in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.1.2)\n",
      "Requirement already satisfied: testpath in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.5.0)\n",
      "Requirement already satisfied: mistune<2,>=0.8.1 in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.8.4)\n",
      "Requirement already satisfied: defusedxml in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.7.1)\n",
      "Requirement already satisfied: entrypoints>=0.2.2 in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.4)\n",
      "Requirement already satisfied: bleach in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (4.1.0)\n",
      "Requirement already satisfied: pandocfilters>=1.4.1 in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (1.5.0)\n",
      "Requirement already satisfied: beautifulsoup4 in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (4.11.1)\n",
      "Requirement already satisfied: nbclient<0.6.0,>=0.5.0 in d:\\anaconda\\lib\\site-packages (from nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.5.13)\n",
      "Requirement already satisfied: soupsieve>1.2 in d:\\anaconda\\lib\\site-packages (from beautifulsoup4->nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (2.3.1)\n",
      "Requirement already satisfied: webencodings in d:\\anaconda\\lib\\site-packages (from bleach->nbconvert->notebook>=4.4.1->widgetsnbextension~=3.5.0->ipywidgets<8.0,>=7.5->dataprep) (0.5.1)\n"
     ]
    }
   ],
   "source": [
    "!pip install  dataprep"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {
    "id": "FCEovcSJdxLw"
   },
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import pandas as pd\n",
    "import math\n",
    "\n",
    "from datetime import timedelta, datetime\n",
    "\n",
    "from dataprep.clean import clean_country\n",
    "\n",
    "import matplotlib.pyplot as plt\n",
    "%matplotlib inline\n",
    "plt.style.use(\"seaborn\")\n",
    "plt.rcParams[\"figure.figsize\"] = (20, 5)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "MmOaye24dxLw"
   },
   "source": [
    "### Exploring and preparing the data"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {
    "id": "r6hCnPlddxLw"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>week.year</th>\n",
       "      <th>revenue</th>\n",
       "      <th>units</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>03.2019</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>06.2019</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>08.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>...</th>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>235569</th>\n",
       "      <td>CN</td>\n",
       "      <td>2452476</td>\n",
       "      <td>27.2020</td>\n",
       "      <td>41160.00</td>\n",
       "      <td>200</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>235570</th>\n",
       "      <td>CN</td>\n",
       "      <td>2452476</td>\n",
       "      <td>27.2020</td>\n",
       "      <td>50856.00</td>\n",
       "      <td>400</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>235571</th>\n",
       "      <td>CN</td>\n",
       "      <td>2452476</td>\n",
       "      <td>27.2020</td>\n",
       "      <td>79920.00</td>\n",
       "      <td>1200</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>235572</th>\n",
       "      <td>CN</td>\n",
       "      <td>4553904</td>\n",
       "      <td>27.2020</td>\n",
       "      <td>4788.00</td>\n",
       "      <td>100</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>235573</th>\n",
       "      <td>CN</td>\n",
       "      <td>4553904</td>\n",
       "      <td>27.2020</td>\n",
       "      <td>4188.00</td>\n",
       "      <td>100</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "<p>235574 rows × 5 columns</p>\n",
       "</div>"
      ],
      "text/plain": [
       "       country       id week.year   revenue  units\n",
       "0           KR   702234   03.2019    808.08      1\n",
       "1           KR   702234   06.2019   1606.80      2\n",
       "2           KR  3618438   08.2019    803.40      1\n",
       "3           KR  3618438   09.2019    803.40      1\n",
       "4           KR  3618438   09.2019    803.40      1\n",
       "...        ...      ...       ...       ...    ...\n",
       "235569      CN  2452476   27.2020  41160.00    200\n",
       "235570      CN  2452476   27.2020  50856.00    400\n",
       "235571      CN  2452476   27.2020  79920.00   1200\n",
       "235572      CN  4553904   27.2020   4788.00    100\n",
       "235573      CN  4553904   27.2020   4188.00    100\n",
       "\n",
       "[235574 rows x 5 columns]"
      ]
     },
     "execution_count": 3,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Read CSV file\n",
    "\n",
    "df1 = pd.read_csv('https://raw.githubusercontent.com/AImmanuel/Customer-Segmentation/main/sales_asia.csv', \n",
    "                  dtype={'week.year': str}, \n",
    "                  sep=';', \n",
    "                  decimal=',')\n",
    "\n",
    "df1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "MIVB5Y5jdxLx",
    "outputId": "e330a5e0-c1b3-47f9-9b8d-66d016a129e5"
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "<class 'pandas.core.frame.DataFrame'>\n",
      "RangeIndex: 235574 entries, 0 to 235573\n",
      "Data columns (total 5 columns):\n",
      " #   Column     Non-Null Count   Dtype  \n",
      "---  ------     --------------   -----  \n",
      " 0   country    235574 non-null  object \n",
      " 1   id         235574 non-null  int64  \n",
      " 2   week.year  235574 non-null  object \n",
      " 3   revenue    235574 non-null  float64\n",
      " 4   units      235574 non-null  int64  \n",
      "dtypes: float64(1), int64(2), object(2)\n",
      "memory usage: 9.0+ MB\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "((235574, 5), None)"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Print the shape and basic information about the data.\n",
    "df1.shape, df1.info()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {
    "id": "D0ihJZAVdxLx"
   },
   "outputs": [],
   "source": [
    "# Splitting 'week.year' column on '.' and creating 'week' and 'year' columns\n",
    "\n",
    "df1['week'] = df1['week.year'].astype(str).str.split('.').str[0]\n",
    "df1['year'] = df1['week.year'].astype(str).str.split('.').str[1]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 204
    },
    "id": "OI2P55WCv2ZV",
    "outputId": "cc7bba7f-7d69-4c56-ef95-11cdf0a7a3bd"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>week.year</th>\n",
       "      <th>revenue</th>\n",
       "      <th>units</th>\n",
       "      <th>week</th>\n",
       "      <th>year</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>03.2019</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "      <td>03</td>\n",
       "      <td>2019</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>06.2019</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "      <td>06</td>\n",
       "      <td>2019</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>08.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>08</td>\n",
       "      <td>2019</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>09</td>\n",
       "      <td>2019</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>09</td>\n",
       "      <td>2019</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id week.year  revenue  units week  year\n",
       "0      KR   702234   03.2019   808.08      1   03  2019\n",
       "1      KR   702234   06.2019  1606.80      2   06  2019\n",
       "2      KR  3618438   08.2019   803.40      1   08  2019\n",
       "3      KR  3618438   09.2019   803.40      1   09  2019\n",
       "4      KR  3618438   09.2019   803.40      1   09  2019"
      ]
     },
     "execution_count": 6,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df1.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {
    "id": "I-36EMcXdxLx"
   },
   "outputs": [],
   "source": [
    "# Using Monday as first day of the week\n",
    "\n",
    "df1['date'] = pd.to_datetime(df1['year'].map(str) + df1['week'].map(str) + '-1', format='%Y%W-%w')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 204
    },
    "id": "OBqDEwUFyu0B",
    "outputId": "1405d0d2-f02c-454a-f583-5ec0544cedc9"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>week.year</th>\n",
       "      <th>revenue</th>\n",
       "      <th>units</th>\n",
       "      <th>week</th>\n",
       "      <th>year</th>\n",
       "      <th>date</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>03.2019</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "      <td>03</td>\n",
       "      <td>2019</td>\n",
       "      <td>2019-01-21</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>06.2019</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "      <td>06</td>\n",
       "      <td>2019</td>\n",
       "      <td>2019-02-11</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>08.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>08</td>\n",
       "      <td>2019</td>\n",
       "      <td>2019-02-25</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>09</td>\n",
       "      <td>2019</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>09.2019</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>09</td>\n",
       "      <td>2019</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id week.year  revenue  units week  year       date\n",
       "0      KR   702234   03.2019   808.08      1   03  2019 2019-01-21\n",
       "1      KR   702234   06.2019  1606.80      2   06  2019 2019-02-11\n",
       "2      KR  3618438   08.2019   803.40      1   08  2019 2019-02-25\n",
       "3      KR  3618438   09.2019   803.40      1   09  2019 2019-03-04\n",
       "4      KR  3618438   09.2019   803.40      1   09  2019 2019-03-04"
      ]
     },
     "execution_count": 8,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df1.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "dMrWJNfzdxLx",
    "outputId": "ec5fd58c-7d3e-471f-d439-61b5216563eb"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "Index(['country', 'id', 'week.year', 'revenue', 'units', 'week', 'year',\n",
       "       'date'],\n",
       "      dtype='object')"
      ]
     },
     "execution_count": 9,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Print the columns \n",
    "\n",
    "df1.columns"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "metadata": {
    "id": "Ex5z6Kl1dxLx"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>revenue</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-01-21</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "      <td>2019-02-11</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-02-25</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id  revenue  units       date\n",
       "0      KR   702234   808.08      1 2019-01-21\n",
       "1      KR   702234  1606.80      2 2019-02-11\n",
       "2      KR  3618438   803.40      1 2019-02-25\n",
       "3      KR  3618438   803.40      1 2019-03-04\n",
       "4      KR  3618438   803.40      1 2019-03-04"
      ]
     },
     "execution_count": 10,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Removing unnecesary columns\n",
    "\n",
    "df2 = df1.drop(['week.year', 'week', 'year'], axis=1)\n",
    "df2.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "metadata": {
    "id": "Hv7y4c2-dxLx"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-01-21</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "      <td>2019-02-11</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-02-25</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-03-04</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id  monetary  units       date\n",
       "0      KR   702234    808.08      1 2019-01-21\n",
       "1      KR   702234   1606.80      2 2019-02-11\n",
       "2      KR  3618438    803.40      1 2019-02-25\n",
       "3      KR  3618438    803.40      1 2019-03-04\n",
       "4      KR  3618438    803.40      1 2019-03-04"
      ]
     },
     "execution_count": 11,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#Renaming columns\n",
    "\n",
    "df2.rename({'revenue': 'monetary'}, axis=\"columns\", inplace=True)\n",
    "df2.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "oBC8ZeQDdxLy",
    "outputId": "1f15016c-42b7-49b0-e2c3-a4685bc28d64"
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "<class 'pandas.core.frame.DataFrame'>\n",
      "RangeIndex: 235574 entries, 0 to 235573\n",
      "Data columns (total 5 columns):\n",
      " #   Column    Non-Null Count   Dtype         \n",
      "---  ------    --------------   -----         \n",
      " 0   country   235574 non-null  object        \n",
      " 1   id        235574 non-null  int64         \n",
      " 2   monetary  235574 non-null  float64       \n",
      " 3   units     235574 non-null  int64         \n",
      " 4   date      235574 non-null  datetime64[ns]\n",
      "dtypes: datetime64[ns](1), float64(1), int64(2), object(1)\n",
      "memory usage: 9.0+ MB\n"
     ]
    }
   ],
   "source": [
    "df2.info()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 13,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 297
    },
    "id": "WV5lfK4IdxLy",
    "outputId": "fd3336f6-8fd7-4cd6-cfea-de6853960dc4"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>count</th>\n",
       "      <td>2.355740e+05</td>\n",
       "      <td>2.355740e+05</td>\n",
       "      <td>235574.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>mean</th>\n",
       "      <td>3.193118e+06</td>\n",
       "      <td>2.840211e+03</td>\n",
       "      <td>8.599642</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>std</th>\n",
       "      <td>7.371744e+06</td>\n",
       "      <td>2.247532e+04</td>\n",
       "      <td>602.939290</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>min</th>\n",
       "      <td>6.000180e+05</td>\n",
       "      <td>-1.061539e+05</td>\n",
       "      <td>-150000.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>25%</th>\n",
       "      <td>2.214396e+06</td>\n",
       "      <td>3.994800e+02</td>\n",
       "      <td>1.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>50%</th>\n",
       "      <td>3.140856e+06</td>\n",
       "      <td>1.150320e+03</td>\n",
       "      <td>1.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>75%</th>\n",
       "      <td>3.892650e+06</td>\n",
       "      <td>2.216160e+03</td>\n",
       "      <td>2.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>max</th>\n",
       "      <td>2.419308e+08</td>\n",
       "      <td>2.415857e+06</td>\n",
       "      <td>150000.000000</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "                 id      monetary          units\n",
       "count  2.355740e+05  2.355740e+05  235574.000000\n",
       "mean   3.193118e+06  2.840211e+03       8.599642\n",
       "std    7.371744e+06  2.247532e+04     602.939290\n",
       "min    6.000180e+05 -1.061539e+05 -150000.000000\n",
       "25%    2.214396e+06  3.994800e+02       1.000000\n",
       "50%    3.140856e+06  1.150320e+03       1.000000\n",
       "75%    3.892650e+06  2.216160e+03       2.000000\n",
       "max    2.419308e+08  2.415857e+06  150000.000000"
      ]
     },
     "execution_count": 13,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Find basic description of the Dataframe\n",
    "\n",
    "df2.describe()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "metadata": {
    "id": "g3NeSfPA46JM"
   },
   "outputs": [],
   "source": [
    "# We have 235574 transactions in the period of time icluded in the dataset\n",
    "# Biggest transaction was 150,000 units. But it seems there was a return of that amount as well, -150,000 units\n",
    "# Most expensive purchase was 2.41 Millions"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 15,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "SMjrADYXdxLy",
    "outputId": "957e1ec9-4e79-442c-a691-84d7fe64964c"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "country     0\n",
       "id          0\n",
       "monetary    0\n",
       "units       0\n",
       "date        0\n",
       "dtype: int64"
      ]
     },
     "execution_count": 15,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Check if there are any null values in the Dataframe\n",
    "\n",
    "df2.isnull().sum()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "VfddguWY4TUf",
    "outputId": "7851c0e8-7134-43d3-ddee-664e2b8217cd"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(Timestamp('2019-01-07 00:00:00'), Timestamp('2020-11-30 00:00:00'))"
      ]
     },
     "execution_count": 16,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# View the period of time included in the dataset\n",
    "\n",
    "df2['date'].min(), df2['date'].max()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 17,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "wGNkehy83Sy7",
    "outputId": "0cae2089-8d0e-4aa2-f678-cc430201da51"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "array(['KR', 'PK', 'MM', 'VN', 'IN', 'SA', 'PH', 'AF', 'CN', 'BD', 'ID',\n",
       "       'TH', 'IQ', 'MY', 'JP', 'IR', 'TR', 'UZ'], dtype=object)"
      ]
     },
     "execution_count": 17,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# List thr different countries with sales in the chosen period\n",
    "\n",
    "df2['country'].unique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "EzqHjFq531Sw",
    "outputId": "d40a8cb3-e322-4fb0-806d-84fb0a414716"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "18"
      ]
     },
     "execution_count": 18,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Count the number of unique country names\n",
    "\n",
    "df2['country'].nunique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 19,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "b7WFvvE6Et4_",
    "outputId": "ae9d64f1-6fe1-4f88-ec6c-db296426a370"
   },
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "D:\\Anaconda\\lib\\site-packages\\dask\\dataframe\\core.py:7047: FutureWarning: Meta is not valid, `map_partitions` and `map_overlap` expects output to be a pandas object. Try passing a pandas object as meta or a dict or tuple representing the (name, dtype) of the columns. In the future the meta you passed will not work.\n",
      "  warnings.warn(\n"
     ]
    },
    {
     "data": {
      "application/vnd.jupyter.widget-view+json": {
       "model_id": "",
       "version_major": 2,
       "version_minor": 0
      },
      "text/plain": [
       "  0%|                                                                                            | 0/8 [00:00<…"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Country Cleaning Report:\n",
      "\t235574 values cleaned (100.0%)\n",
      "Result contains 235574 (100.0%) values in the correct format and 0 null values (0.0%)\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "array(['South Korea', 'Pakistan', 'Myanmar', 'Vietnam', 'India',\n",
       "       'Saudi Arabia', 'Philippines', 'Afghanistan', 'China',\n",
       "       'Bangladesh', 'Indonesia', 'Thailand', 'Iraq', 'Malaysia', 'Japan',\n",
       "       'Iran', 'Turkey', 'Uzbekistan'], dtype=object)"
      ]
     },
     "execution_count": 19,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Transforming country codes into full country names with clean_country function from dataprep library\n",
    "\n",
    "clean_country(df2, \"country\")['country_clean'].unique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 20,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "_NfRCnq131Ob",
    "outputId": "7029a7b9-ef23-41c9-a31f-b05bfe4eac16"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "21837"
      ]
     },
     "execution_count": 20,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Total number of customers in all countries\n",
    "\n",
    "df2['id'].nunique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 21,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 235
    },
    "id": "9UHW6jQh31KE",
    "outputId": "afc2d85a-6f50-4434-b9c9-4034d5c77c77"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>date</th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>2019-01-21</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-02-11</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-02-25</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-03-04</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-03-04</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "           country       id  monetary  units\n",
       "date                                        \n",
       "2019-01-21      KR   702234    808.08      1\n",
       "2019-02-11      KR   702234   1606.80      2\n",
       "2019-02-25      KR  3618438    803.40      1\n",
       "2019-03-04      KR  3618438    803.40      1\n",
       "2019-03-04      KR  3618438    803.40      1"
      ]
     },
     "execution_count": 21,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Putting date into the index for plotting the time series\n",
    "\n",
    "df2b = df2.set_index(\"date\")\n",
    "df2b.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 22,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 343
    },
    "id": "1z7xzmT78Mxh",
    "outputId": "eda5e425-894b-47cc-f9a0-4bfd87f02b23"
   },
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAABKcAAAF0CAYAAAD2ElpbAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMSwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy/YYfK9AAAACXBIWXMAAAsTAAALEwEAmpwYAABKPklEQVR4nO3deXhTZd7/8U/adEk3oGyl7Fhoi9IWQQZQURAZ95nhARf0cYS6IDrgMyg/HUARh2VcxhEGR8UFEHEpqIziwqoom0ChbC0FytoCpUApJSklTX5/hMa2pE3UtqeF9+u6vKSnd5PvSb5J7nxynxOT0+l0CgAAAAAAADCAn9EFAAAAAAAA4NJFOAUAAAAAAADDEE4BAAAAAADAMIRTAAAAAAAAMAzhFAAAAAAAAAxDOAUAAAAAAADDEE4BAIB6r1+/fpo7d+4F2w8dOqTY2FhlZmb6dDlPP/20Ro4cKUlyOp365JNPdPbs2Wqt1Zt169YpNjZWZ86c8fj7zMxMxcbG6tChQ7ValxHK3h8AAODiZTa6AAAAgLpi7NixcjqdkqT169dr/PjxuvXWWxUUFGRwZQAAABcvwikAAIDzwsPD3f8uDakAAABQszisDwAAXDKefvppTZgwQc8884y6du2qfv366fXXXy/3+5EjR+rQoUO6//77JUlXXnmlPv30UxUWFmr06NH63e9+p6SkJCUnJ2vfvn0er8dut+uFF17Q1VdfrYSEBN1zzz3asmWL+/f79u3To48+qquuukq/+93vNG7cOBUWFnq8rBMnTujxxx9X165dNWDAAK1fv77KfezXr5/ee+893XXXXUpISNBdd92l7du3u39/7tw5vfzyy7r66qvVrVs3JScnKysrq9zfv/jii7r++ut13XXX6dSpU+Uu/w9/+IPeeust98/PP/+8kpKSZLfbJUnHjh1TbGysDh48KEl655131LdvX3Xt2lX33HOPNm/eXO7yvP2+1NmzZ3XffffprrvuqvSQRwAAUD8RTgEAgEvK/Pnz1bx5cy1YsECDBg3Sa6+9pm3btpUb06JFC02fPl2StHTpUt1yyy3617/+pUOHDmnOnDn69NNP5efnp7/97W8er2Pu3Ln64Ycf9J///EeLFi1Su3btNHLkSDmdTuXn52vIkCEKCAjQBx98oOnTp2vjxo2VXtaoUaOUl5enefPmacKECXr77be97uNrr72mO+64Q5999pnat2+vYcOGKT8/X5I0bdo0ff/993r11Vf1ySefqH379vrf//1fnT592v33KSkpmjZtmv7973+rQYMG5S67T58+Wrt2rfvndevWqaioSDt27JAkrVq1Sh06dFDr1q310Ucfac6cOXruuef02Wef6brrrtOf//xnd3Dl7fel7Ha7Ro0aJavVqpkzZyo0NNTrbQAAAOoPwikAAHBJad26tZ544gl16NBBI0aMUMOGDcutLJIkf39/dygTGRmp4OBgZWdnKzQ0VK1atVKHDh3097//XU8++aTH6zh06JCCg4PVqlUrtW7dWs8884ymTp0qh8OhL7/8Ug6HQy+++KI6deqkHj16aOrUqfr222+1d+/ecpezZ88e/fTTT3rhhRcUHx+v3r17V3qdZd1yyy269957ddlll2nixIkym8366quvVFRUpFmzZmnChAnq0aOHLrvsMo0bN05hYWFauHCh++9vvvlmJSQkqEuXLhdcdp8+fZSamqri4mLl5eUpOztbvXr10oYNGyRJP/zwg6677jpJ0ptvvqnRo0fr+uuvV7t27TR8+HB169ZN8+bN8+n3kuvwyrFjx+rQoUN65513FBER4XX/AQBA/cI5pwAAQL1nNpvlcDgu2F563iiz+ecpT9u2bcuNCQ0NdR+SVpVHHnlEjzzyiHr16qWrrrpK/fv31x/+8AePY++77z4tX75c1157rfvwwT/96U/y9/fXrl27FB8fr+DgYPf4Ll26KCAgQHv27Cl33qvMzEwFBgaqY8eO7m0JCQlea+3evbv734GBgYqNjdWuXbt04MABFRcXKzk5WSaTyT3m7Nmz5YKxNm3aVHrZXbt2ldlsVlpamnJzc5WQkKCePXtqw4YNGjp0qFavXq1//vOfOnPmjHJycjR+/Hg999xz7r8vLi5WYGCg19+X+u6773Tu3DklJSWpYcOGXvcdAADUP4RTAACg3ouIiCh3WFqp0vMllV1tUzb4KOXLyc+TkpK0bNkyrVixQitXrtSrr76qefPmaf78+Rd8m1+7du30zTffaOXKlfr+++/17rvvas6cOUpJSSkXSlXkKWArra80TAoICPBaq7+//wWX6+/vr5KSEknSu+++q8aNG5cbExYW5v53VTWazWb17t1ba9eu1bFjx9SjRw9dddVVevfdd7V9+3adPXtW3bt3V1FRkSRp6tSp6ty5c7nLCA4Odu9rZb8vFRkZqVdeeUUPPvigPvroI91zzz1e9x8AANQvHNYHAADqvc6dO2vTpk0XbN+0aZOaNm2qJk2a/OLLLLuySHIdgrZlyxbdfvvteumll/Txxx8rMzNTO3fuvOBvP/nkEy1dulT9+/fXCy+8oG+//VZ5eXlav369LrvsMmVkZLjDG0natm2bzp07pw4dOpS7nNjYWBUXFys9Pd29reIhiJ6Unv9Jcq2K2rlzp2JjY9WmTRuZzWadOHFCbdu2Vdu2bdWmTRtNnz693Anbvbn22mu1Zs0abdq0SVdddZW6dOmis2fP6r333tPVV1+tgIAAhYeHq2nTpjp69Kj7utq2bes+H5e335dKTExU9+7dNXz4cP3zn//UsWPHfK4TAADUD4RTAACg3hsyZIjWrl2rF198UXv27FFWVpZSUlI0ffp0PfTQQ7/qMkNCQiS5wqAzZ87oyJEj+vvf/67U1FQdPHhQn332mcLCwtSuXbsL/ragoECTJk3SqlWrdOjQIX3++edyOByKj4/X7bffrqCgII0ZM0aZmZnasGGDxo4dq969eysmJqbc5XTo0EHXXXedxo4dqy1btmjDhg166aWXvNb+8ccf64svvtCePXs0fvx4mc1m3XzzzQoNDdU999yjSZMm6fvvv9f+/fs1ceJELVu2TJdddpnPt02fPn20ZcsW7d+/X0lJSQoICFDXrl21aNEi9enTxz3uwQcf1Ouvv66vvvpKBw8e1Ouvv64PPvhA7du39+n3ZQ0bNkyRkZGaPHmyz3UCAID6gcP6AABAvRcXF6dZs2bp3//+t1JSUlRcXKy2bdvqqaee0uDBg3/VZXbq1El9+/bVsGHDNHr0aD311FOaPHmyHn/8cZ0+fVrx8fF66623PJ6ge+jQoTpx4oSeeeYZnThxQu3bt9e0adPcocvbb7+tyZMna9CgQQoJCdHvf/97PfXUUx7r+Oc//6kJEyboz3/+syIiIvTwww9r4sSJVdY+aNAgvffee9qzZ4+SkpI0a9Ys92F7Y8aMkdls1t/+9jcVFhYqLi5OM2fOrPI8UxU1b95cHTp0UFhYmPsQvKuuukqrV68uF07df//9Kioq0ksvvaS8vDy1a9dO06ZNU7du3Xz6fVmBgYF69tlnNWzYMP3pT38qdz0AAKB+Mzl9OckCAAAA6oV+/fpp2LBhuu+++4wuBQAAwCcc1gcAAAAAAADDEE4BAAAAAADAMBzWBwAAAAAAAMOwcgoAAAAAAACGIZwCAAAAAACAYQinAAAAAAAAYBiz0QXURTk5OUaX4FV0dHS9qBO1g35ARfQEPKEvUBl6AxXRE/CEvoAn9AUqU7E3oqOjKx3LyikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYsxFXumvXLn3wwQeaMGGCsrKy9I9//EMtWrSQJA0YMEC9e/fW0qVLtXTpUvn7+2vgwIHq1q2biouLNW3aNBUUFMhiseixxx5TRESEMjMzNWvWLPn7+yshIUGDBw+WJKWkpCg1NVX+/v564IEHFBMTY8TuAgAAAAAAoBK1Hk4tXLhQK1euVHBwsCRp7969uu2223T77be7x+Tn5+vrr7/W1KlTde7cOY0fP14JCQlavHix2rRpozvvvFOrVq3SggULNHToUM2cOVOjR49W8+bNNXXqVGVlZUmSduzYocmTJ+v48eN65ZVXNGXKlNreXQAAAAAAAFSh1g/ra968uZ588kn3z1lZWUpNTdVzzz2n//znP7LZbNq9e7diY2MVEBCgkJAQRUVFaf/+/crIyFBSUpIkqWvXrtq6dausVqvsdruioqJkMpmUmJiobdu2KSMjQ4mJiTKZTGrSpIlKSkpUUFBQ27sLAAAAAAA8mJ0epl4p0Tp8xt/oUmCwWl851bNnT+Xm5rp/jomJ0Q033KAOHTro008/VUpKitq1a6eQkBD3GIvFIqvVKpvN5t4eHBzs3maxWNxjg4ODlZubq4CAAIWHh19wGREREV5rjI6Oro5drXH1pU7UDvoBFdET8IS+QGXoDVRET8AT+gKe/Nq+eCPF9f81J5vr8Y7VWBDqDF97w5BzTpXVo0cPhYaGuv/97rvvqnPnzioqKnKPsdlsCg0NlcVicW8vKipyb7PZbO6xRUVFCgkJkdlsLre9bLDlTU5OTnXsWo2Kjo6uF3WidtAPqIiegCf0BSpDb6AiegKe0Bfw5Lf1hSu4KDhdoJycwuorCnVCxd6oKqgy/Nv6Jk2apN27d0uStm7dqg4dOigmJkbp6ekqLi6W1WpVdna2WrdurdjYWKWmpkqSNm3apLi4OHcQdeTIETmdTqWlpSk+Pl5xcXFKS0uTw+FQXl6enE6nT6umAAAAAAAAUHsMXzn14IMP6t1335XZbFbDhg318MMPKyQkRDfffLOee+45ORwO3X333QoMDNSAAQM0Y8YMjR8/XmazWaNGjZIkPfTQQ5o+fbocDocSEhLUsaNrPWBcXJzGjRsnp9Op5ORkI3cTAAAAAAAAHpicTqfT6CLqmvqwVJUltSiLfkBF9AQ8oS9QGXoDFdET8IS+gCe/pS96pbgO83rkigI9EM9hfRebenVYHwAAAAAAAC5dhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwZiOudNeuXfrggw80YcIEHTlyRDNmzJDJZFLr1q2VnJwsPz8/LV26VEuXLpW/v78GDhyobt26qbi4WNOmTVNBQYEsFosee+wxRUREKDMzU7NmzZK/v78SEhI0ePBgSVJKSopSU1Pl7++vBx54QDExMUbsLgAAAAAAACpR6yunFi5cqDfeeEPnzp2TJM2ePVt33323Jk6cKKfTqQ0bNig/P19ff/21XnjhBY0dO1bz5s3TuXPntHjxYrVp00YTJ05Unz59tGDBAknSzJkzNXLkSE2cOFG7d+9WVlaWsrKytGPHDk2ePFlPPPGE3nnnndreVQAAAAAAAHhR6+FU8+bN9eSTT7p/zsrKUufOnSVJXbt21ZYtW7R7927FxsYqICBAISEhioqK0v79+5WRkaGkpCT32K1bt8pqtcputysqKkomk0mJiYnatm2bMjIylJiYKJPJpCZNmqikpEQFBQW1vbsAAAAAAACoQq0f1tezZ0/l5uaW22YymSRJFotFVqtVVqtVISEh7t+XbrfZbO7twcHB7m0Wi8U9Njg4WLm5uQoICFB4ePgFlxEREeG1xujo6N+0j7WlvtSJ2kE/oCJ6Ap7QF6gMvYGK6Al4Ql/Ak9/aFxHhEYqO9v5eHfWPr71hyDmnyioNpiTJZrMpNDRUISEhKioqumC7xWJxby8qKnJvs9ls7rFFRUUKCQmR2Wwut71ssOVNTk7Ob92tGhcdHV0v6kTtoB9QET0BT+gLVIbeQEX0BDyhL+DJb+sLV3BRcLpAOTmF1VcU6oSKvVFVUGX4t/W1a9dO27dvlyRt2rRJ8fHxiomJUXp6uoqLi2W1WpWdna3WrVsrNjZWqamp7rFxcXHuIOrIkSNyOp1KS0tTfHy84uLilJaWJofDoby8PDmdTp9WTQEAAAAAAKD2GL5y6v7779ebb74pu92uli1bqmfPnvLz89PNN9+s5557Tg6HQ3fffbcCAwM1YMAAzZgxQ+PHj5fZbNaoUaMkSQ899JCmT58uh8OhhIQEdezYUZIUFxencePGyel0Kjk52cjdBAAAAAAAgAcmp9PpNLqIuqY+LFVlSS3Koh9QET0BT+gLVIbeQEX0BDyhL+DJb+mLXimuw7weuaJAD8RzWN/Fpl4d1gcAAAAAAIBLF+EUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAEnSd9nBevy7xoZc96ubI/TOjjCv4747FKyR3xtT46XoYKG/7vq6mQqKTUaXgl/p2/0WjVnVyOgycJF7fl1Dzd8dYnQZAOoxwikAACBJemZ1pDYeC9L+0/61ft2f7ArT29sjvI57Zk2k1ucG6VBh7dd4KRq7OlIHCs16Y6v3+wZ104SfGumHHItOETCiBn1zIESvbGpodBkA6jHCKQAAUE6Rve5PD4rsvNGuDdbzt7OV27veszu4DwEAdVfdn30CAAAAAADgokU4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMOYjS6g1JgxYxQSEiJJatasmQYOHKgZM2bIZDKpdevWSk5Olp+fn5YuXaqlS5fK399fAwcOVLdu3VRcXKxp06apoKBAFotFjz32mCIiIpSZmalZs2bJ399fCQkJGjx4sMF7CQAAAAAAgLLqRDhVXFwsSZowYYJ72z/+8Q/dfffduvzyy/XWW29pw4YN6tSpk77++mtNnTpV586d0/jx45WQkKDFixerTZs2uvPOO7Vq1SotWLBAQ4cO1cyZMzV69Gg1b95cU6dOVVZWljp06GDQXgIAAAAAAKCiOhFO7d+/X2fPntXf//53lZSU6J577lFWVpY6d+4sSeratavS0tLk5+en2NhYBQQEKCAgQFFRUdq/f78yMjJ0xx13uMcuWLBAVqtVdrtdUVFRkqTExERt27aNcAoAAAAAAKAOqRPhVFBQkG6//XbdcMMNOnz4sKZMmSJJMplMkiSLxSKr1Sqr1eo+9K/sdpvN5t4eHBzs3maxWNxjg4ODlZub61M90dHR1bVrNaq+1InaQT+gInoCnvjSF02aNlV0s1ooxgNf+7Zp02aKblrDxVxiPN325vMzRYslRNHRIRf8HvVH8+ZRahb6y/6G1xF4UlVf0DOXrt9630eERyg6OqKaqkFd4mtv1IlwqkWLFoqKipLJZFJ0dLTCwsKUlZXl/r3NZlNoaKhCQkJUVFR0wXaLxeLeXlRU5N5ms9ncY4uKisoFW1XJycmppj2rOdHR0fWiTtQO+gEV0RPwxHtfuCYPeceOKcd+rnaKqnDd3vvWNe7YsVw1OGev4ZouHZX1ht3eTJJZNptVOTn5tV4XqoPrMXP06BHZgx2+/xWvI/Cg8r7w9TkcF6Pf9nzh6p2C0wXKySmsvqJQJ1TsjaqCqjrxbX0rVqzQnDlzJEknTpyQzWZTYmKitm/fLknatGmT4uPjFRMTo/T0dBUXF8tqtSo7O1utW7dWbGysUlNT3WPj4uIUEhIis9msI0eOyOl0Ki0tTfHx8YbtIwAAAAAAAC5UJ1ZO9evXTzNmzND48eNlMpn06KOPKjw8XG+++absdrtatmypnj17ys/PTzfffLOee+45ORwO3X333QoMDNSAAQPcf282mzVq1ChJ0kMPPaTp06fL4XAoISFBHTt2NHhPAQAAAAAAUFadCKfKBkplPf/88xds69+/v/r3719uW1BQkP76179eMLZTp06aNGlS9RUKAAAAAACAalUnDusDAAAAAADApYlwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAoBptyA3U1A0NjC4DAACg3iCcAgAAqEZ/+b6JFu4N1VEr0ywAAABfMGsCAACoAVY70ywAAABfMGsCAAAAAACAYQinAAAADHDyrJ+eXdtQRXaT0aUAAAAYyqdwKjs7W8uWLZPT6dSrr76qv/zlL9q2bVtN1wYYzmrQG4bDZ/w1d2eoIdcNAKgdT69qpCUHQzRja7jRpQAAgN/I4ZQ+3hWqM+f40OnX8CmceuuttxQYGKjU1FSdOHFCw4cP14cffljTtQGGmr87RDd81kLT0yJq/boHftVcM7Y00PYTAbV+3QCA2pFf7JqG5Z/1N7gSAADwWy3YHap/bW6gh5c3MbqUesmncOrcuXO69tprlZaWpl69eunyyy9XSUlJTdcGGGpDbpAkad3RIMNqyLPxhgUA6orDZ/x1oogzIgAAgAsdtrreux0+U33v4RYfsOiNS2SFtc/hVH5+vlJTU5WQkKD8/HwVFxfXdG3AL/JDTpC+2mfxOu7AaX/9e0vtr4YCAIfTmOt9e3u45lXjocKHCv112xfNddyHoOaHnCAVGrC8fefJAPVKiVZONU4QB37VXLd+EVVtlwcAAC5N+wrMPh3+99y6RpqdQTjlduONN+qxxx5TXFycWrVqpWeeeUa33HJLTdeGOmTIt0117fwW1XZ5mflm9UqJ1prD1bcqacyqxnphfSOv4+76prk+2BmmzccCq+26ARhr8oYG6pUSLbuj6nG7zj/37CswVzmuuETqlRLt02G9qw4H6ScfVlje+t/munp+tE4XVz0R+WKvRb1SovXdoWCvl7nmiG/Bzzs7wjV9SwOv43z1/E+NdLzIX69trvr2ycw3a8yqxrrx8+p7/fDVpA0NJcnrp41Op3TPN0217ohxq2R9seJQsNfeAQAAdZ/dId3zbTP1N2B+VJf5FE51795d77//vh5//HFJ0osvvqi4uLgaLQy/XlGJNGl9A+Wfrb5DD/YWBMjurL5J8Zx015uF6QauYDpRjbePkapz2SjqvyK7Sb1SojV8Ue1fd57NT/ctbup1NU1BsavG6jwe/4u9rlVBO7ycp+2VTa6AxtvqyY3HXEHFvMwwr9f95I+NNWplY6/jTpw/r9CBwqqDsU/3uPbli30hVY7bc8qsv/5gTPBz9vyXRZwtqfp14fCZqve1JpWcDyrtjqprXHskSPtOB+iJH7zfh0bZdjxAf1sTqQELmcQCQFkHC/3VKyVab2+/NFaW1BSHU/rP1vCL5tD1tLxAHbPV3X0p9jI3uVRVeY8VFhaqsLBQU6ZMkdVqdf9cUlKil19+ubZqxC/0n60R+nJfqP7fKu+riGx2k5wGHGZSepVGXPfFZHZ6mAZ+1VzjVxhz/d5WqZTy5dP+wnOuwGLw181+Y1WXttJw5uvd3sfe+t/muu2L5tV23VM2NNSeUwF6cWPVK3QyTrpq3Hrc++rFv69vqKkbqm/FT2lQ4Wvv1mUE09XD5iVgqwuyf0HId85h3OGjvlpzJMhrkCy5guztx72PW3owWL1SopWZ7/12yrX6MfeoxN4CswYuauZ1NWaJU7rrm6ZKy/P+HP7ujjAtPeh9Fajk2/PynlOuGqvzm7A+zAzVjzneV04esfr7tEoWVftsT4hP71EOFfpr9I+RXvti2UHXKT3e2eE9nNpzyuzTh/dFJdJRqzHBxoeZodqYW71Hd5zz4bH12Z4QzckIV/Iy7x8c3vrf5np1k/cFBq9ujtDd3zT1pUSfpR4LVImX53C7Qxq+oonu+NL7Yfhj1zRS30+9jysoNunTPVV/aIjfrspH3Wuvvabk5GQdOHBAycnJ7v8effRRtW/fvrZq/E0cDofeeustjR07VhMmTNCRI0eMLqnGnTyfeJ/08u0/VrtJ/T5rod7zo2ujLEg6UeRXrS92286/ud94uNouUiuzg7XkgPeJ5KCvmunaBdHK9fKpxNydoRqwsIVe93JoTelhVoe8rCqRpO+zg7XMx8nuxSSvmj8BOnHWX8eLvAcc244HaLIPAZH1/GqaM+eqr85F+0K0cG/1nSsJuNj1WRCtq314XT9q9dN32dX3PFq6InLGFu9vEP/6Q2MlL/P+huX3C1voweVNvYYlM86vhPzYy0rHnScD9IdFURr4lfcPQdYeCdLOk96DsaNWP5+CDcm3N4ilhxQb8Rr31I+ROmw1610vb/K/2W/RgdMBGr7C+5vYmdsjNH5tpNdxvVKide0C74dm//WHxjpsNWtORtX39eEzrtU003w4NHtaWgM9tcr7ysk/LWquUSsb66yX74RatM91aPbB01W/vjqcrjfGB7yMk6Rn1zbUh5neXwt/yAnyaZ/tDmn14SCvQe3ZEqn/Z1HaVI2nwngxtaFW5li8Ph4eWd5Eqw8H6+Nd1TcHuG9xM938X+9BRN9Po/XHRVFeb58vzx+G720unHH+HIgvpXqfS01La6DHv/f+2Bq3ppF6pXh/rh+zqpH6LIj2eh/mnZ8PHvPyZUx2h2v++Mlu7yvLP9kVpv2nq++bx7/Zb9Fj3zXRg14CNG/hVVnLD1lUVOJ93nr3N830UmrDS/L9R22q8l3g2LFjJUmvv/66RowYUSsFVbf169fr3LlzmjRpkjIzMzVnzhyNGTPG6LJqlFOuSdzBQrO+r2LiefD0z3f/ikPBcsq1kqnsqqbSyyq1/FCwHE7X7xxOkxxSuZ+nbGwoSfpr13w1DnaUuzyH0+T6t9P1RCBJ+04HVFljUYlJE9a5Pl2Z2vuET/u/+IBFJjllOl+6SSr371Irs4PlX8V89/tsV417TgW4J/AVh5vk+tTd1xqfXu2aoE3qdaLK27HUd4eCVeIs8zuZJKfc41PPv9BsP6Yqb8fiEunZdR6uW6bz1+m6nxxOafIG176Y/U6U64nSfij9d+kn+e9sD1evFmd/vrIKLwgzzp/n5v2McHWOPFdpjWU/Ha9qX6Sfb0ezn2894c3iAxYtP2RRn2ibbmlnq3RciVMauyZSrcLsejyhoMrLHLemkUIDHHqm+6kqx5Xuy/irTio0oPJX0ze3hWtvQYDaR5zTI1ecrnRcapnJR7k3nlW8UHt7g/rM+RqjQkp0WQN7peM257neoG08FlTlfVh2xZS3+9rXGn8eZ1Guzb9cf5eU6fftJ1zXve5ocJXXvbbM+Yd8rdHXcSuzg6v8Js6Mk64atx0PrPIyVx3+5TV+s1s6cdL72O+zg3XEWnmNu065Hq8rcyz6Ltvm7q+ybeaUa19/aY2+jlt2yKK9BefkcJpc97GkEqdJjvPPaVkFrhpXZFv0fXblj+uyNS49GOx6Tj5/GY7zz8mlz8OlKr4muP9vKv9A++5QsPZH2H9+XS39//l6D5yftK84VHU/lv0U3dfbZ0Xp67XKPH+ff/1wOuU+R+Mz3fPVINChSJt04sSFl136XL8y+8Iay74mfr3f9Zo5d2e4Lo8857pe/bxC2tOKaV/35cu9IWoRWnkicMR6vsacqm/H0vO4HbGatfRgsPs1t2z/lD5nvJTaUJL0Qs8TF7xWl+2L0nHensP/sbGBTp711w2tbOrbyua6jDKvwaU/f7HX9cn8uLWRXl/jSl8/pvg4P/o+O1iNgytPBErv62/3W5TYpLjSnlh84Ocvn/H1udnX+/qrfSFqEFR5jbnnnzu/3W+pck6Rcj7Q+DAzTIlNfPsSJ19rXHzAovAAp7vHpfLz57+ff2yNXNlYIxMLKn0cLNoXonVHg7X8kMXr/HHJwRAtOSg1s5S457TShc9Bz6xx9UR8o2IFVpExlPbONS2KdFt7a6XjUnaF6ozdTyO+a+KusbK+KLWizPkSy82bK0yivzsUXGWNpYfCf7E3RC3Dyj/+K87nS/2S58fK3veUfRR/nx1c7vauaNL5OfP/rWysBy8/fcHzXOnPM88fcvjpnlB1b3bW5+uuyrLz76W+yw4u9+Jb8fXmhxzXuFc3NdCwzqcvGFf67+XnV6CVOE1VXnfZ4Kf0OdUpqeEZ6eTJ4Av23Zd9KbUyO1jtIyqfZ352fuVSxsmq50dlg8/qeo4qXfTx0a4wmavIskr70VbiV+Vl2uxl3u9V4wdF9Z3J6aw8E87OzlbLli2VlZXl8fcdOnSoscKqy+zZsxUTE6Orr75akvTII4/ozTffrPJvcnJyaqO03yQ6OrrSOoctbaL0k5zsGwAAAACA+m7N4LqfUXhSMbeIjq58xV+VK6fef/99Pf3003rllVcu+J3JZNK///3v31Bm7bDZbAoJ+fn4UD8/P5WUlMjfv/KovqobrC6prM6P75IS3pBGdJeaeDk0duJKKam59Mfz57c3mc6vNCrzb0kae/6cRs9f7zoW1M/k+b8vd0nL9koTrit/eX6mny/TzyTlWaWX10h3XS7FellJPXGl1L2FdEvHqsctSJf2nJTGX6tyn0iU/cRKkjbkuOocf62q/DSksFj651opOUlqFXHhwpOyl/nCD9KVLaTbvNT4yXZpb770t2urvh0/y5BWHnDdjiaTa6ypzO91/m9Pn3Vdd3KS1NLLKu6JK6VeraSbYspft6nCdf91sWt86X1Y9r5z35cmKWWH63DC5/pceF1lb9fs09LMVOm+LtJlXk4x8PxKqX1D6X8Tqh43b5t0qEAa07vqcb4qOCv9a5308JVSlJdVyhNXSr1bSf29ZPMfbJUOF0pP9qp63OYj0n8zpWc93I5lnSqSXvtJGt5NauZlhXtpjTdWqLFiv0/43vV/T/dhuRqPSgt3eq8xv0ia9pP0aDepqQ81XtfW9V9VZqdJJ2zSX3tWPW7T+dtxwnWuHvWv0N+lPx84Jb26TnqwqxTt5egjX2uckyadOiv9pUfV4zbkSF/t9n47Tlz58799GXt9W6mPlxpfWydZz0l/u6bqce9sdj22vF3vcZs0Y71rnyPPf+Dn6fnUZJKe+05KaPbz60xlSvfb19snOUnq0Ejy93M9N/n7ue5n0/n7O+uk6772tR/7t3fdjv4m12X5Vegdfz/p8a9d45/rc+FKoLKfVn+7W9pw/vmx4u1SdiVv5nFp7lbpse5SYx9er2/s4Hoe9+X28fT6UfZ1+I0NUla+99v72BnpPxul//udFF7m6LWKH206Jf39B6lfu/L9WHYuUXr9487PKbxd95pD0pIs7+Nyz0hvbHQ9T4RV8dmc0+l6zRzQQbqmzc/3rV+Z+7j03yO/cf3NxOs9jyvts9Jx3mo8Uii9lSo91ct1O1b2+m8ySf/3rdQj2vV6XZUZ66Vgs+v5rCo/HJCW7/O9xid7SSFVHIlTejve1lHq5uUc/c/7+Lj+4YC0woca959yvS54u68dTlc/XttG6tuu6st8bZ0UESQNTap63PK90o8HL3xcl1upL9djf+FO1+1YWqOnx4HTKY3/zrfXmX+tk5qGSH9OdP3saSWi0yl9t1/6fr/32zG7wPV8//96S0FVvBssvR3/GCsleDlF5StrXPOT0hrLKlvnB9uk3Sd8r/GZa6TAMitVKs7HS5zSpB+kP8VJXbwcsfvSatdrf+k809P7HpNJemGlZLN7r3HtIWlxlqvGIP+fL1Mqf3/bHa7HwoAOUu/WlV+3n0l6ZrkU6C89fXXV170ky/UcWTqHq+w1eNWBn2sM9Kv8vU9xiTT5R1eNPb28zry4WmrbQLr78sofC5Lr9cju8H477suX5mxxzVGqWpV0ziFN+VEaFC919nJk+JQfXe877rq86nGfZkhbc73XmH5MSkn3ocYSacoq6c7OUpyXozOnrpJiGkmDO1c97ps9rv6qLxmFJ77WXuXKqYvB7Nmz1bFjR/Xu7XoXO3z4cL3xxhtV/k19XzmFSw/9gIroifrrbIm0YHeo7ux4psoJ0K9Rl/ui9NwZ3j4ZLB33/o25imlY+fJ//DJ1uTdgDHoCntAX8IS+QGWqbeVUqfz8fC1ZskSFhYUqm2UNGzbsN5RZO2JjY7Vx40b17t1bmZmZatOmjdElAQBQqSB/aUjsGaPLAAAAAGqNT+HU9OnTFRQUpHbt2slU1XFQdVCPHj20ZcsWjRs3Tk6ns96e2B0AAAAAAOBi5FM4deLECb366qs1XUuN8PPz08MPP2x0GQAAAAAAAPDAp7NZNGnSREVFRTVdCwAAAAAAAC4xPq2catSokcaMGaPOnTsrMPDnr8aoD+ecAgAAAAAAQN3lUzjVtGlTNW3a1H2+KafTWe/OPQUAAAAAAIC6x6dwau3atTKZTO5v6isNpgYNGlRzlQEAAFQiIshhdAkAAACoJj6FU8nJye5/2+12rVq1Ss2bN6+xogAAADz55Oaj2pQbpGYWwikAAICLhU/hVOfOncv93KVLF40bN04DBw6skaIAAAA8aR1WotZhVqPLAAAAQDXy6dv6Kjp9+rROnjxZ3bUAAAAAAADgEuPTyqnRo0eXOxl6Xl6ebrzxxhotDAAAAAAAABe/X3zOKUmKiIhQq1ataqQgAAAAAAAAXDp+1TmnAAAAAAAAgOrwq845BQAAAAAAAFQHwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYhnAKAAAAAAAAhiGcAgAAAAAAgGEIpwAAAAAAAGAYwikAAAAAAAAYxmx0AU6nU8OHD1eLFi0kSZ06ddKQIUOUmZmpWbNmyd/fXwkJCRo8eLAkKSUlRampqfL399cDDzygmJgYFRQUaNq0aSouLlajRo00YsQIBQUFacOGDVqwYIH8/PzUt29f9e/f38hdBQAAAAAAQAWGh1NHjx5V+/bt9fTTT5fbPnPmTI0ePVrNmzfX1KlTlZWVJUnasWOHJk+erOPHj+uVV17RlClTNH/+fF1zzTW6/vrr9fnnn2vJkiW66aabNHv2bE2ZMkXBwcEaP368unfvroYNGxqwlwAAAAAAAPDE8MP6srKydPLkST3//POaMmWKcnJyZLVaZbfbFRUVJZPJpMTERG3btk0ZGRlKTEyUyWRSkyZNVFJSooKCAu3cuVNJSUmSpKSkJG3dulXZ2dmKiopSWFiYzGazYmNjlZ6ebuzOAgAAAAAAoJxaXTm1fPlyLVq0qNy25ORk/fGPf1SvXr2UkZGh6dOn68knn5TFYnGPCQ4OVm5urgICAhQeHu7ebrFYZLVaZbVaFRISUm6bzWZzbyu73RfR0dG/ZTdrTX2pE7WDfkBF9AQ8qet9Udfru5hx26MiegKe0BfwhL5AZXztjVoNp/r166d+/fqV23b27Fn5+/tLkuLi4nTixAlZLBbZbDb3mKKiIoWEhMhsNpfbXhpAhYSEyGazKTAwUDabTaGhobJYLCoqKio3NjQ01Kc6c3Jyfstu1oro6Oh6USdqB/2AiugJeFK3+8I1cam79V3c6nZvwAj0BDyhL+AJfYHKVOyNqoIqww/rS0lJca+m2rdvn5o0aeIOoo4cOSKn06m0tDTFx8crLi5OaWlpcjgcysvLk9PpVEREhGJjY7Vp0yZJ0ubNmxUXF6eWLVvq8OHDKiwslN1uV3p6ujp16mTkrgIAAAAAAKACw0+I/sc//lHTp093fwPfiBEjJEkPPfSQpk+fLofDoYSEBHXs2FGSa3XVuHHj5HQ6lZycLEkaOHCgZsyYoWXLlik8PFwjR46U2WzW/fffr0mTJsnhcKhv376KjIw0bD8BAAAAAABwIZPT6XQaXURdUx+WJLJ0EmXRD6iInoAndbkveqW4lnmvGVw367vY1eXegDHoCXhCX8AT+gKVqVeH9QEAAAAAAODSRTgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMYzbiSn/66SetWbNGo0aNkiRlZmZq1qxZ8vf3V0JCggYPHixJSklJUWpqqvz9/fXAAw8oJiZGBQUFmjZtmoqLi9WoUSONGDFCQUFB2rBhgxYsWCA/Pz/17dtX/fv3l8Ph0Ntvv639+/crICBAw4cPV1RUlBG7DAAAAAAAAA9qfeXUe++9p3nz5snpdLq3zZw5UyNHjtTEiRO1e/duZWVlKSsrSzt27NDkyZP1xBNP6J133pEkzZ8/X9dcc40mTpyo9u3ba8mSJbLb7Zo9e7bGjh2r559/XsuWLVN+fr7Wr1+vc+fOadKkSRoyZIjmzJlT27sLAAAAAACAKtR6OBUbG6sHH3zQ/bPVapXdbldUVJRMJpMSExO1bds2ZWRkKDExUSaTSU2aNFFJSYkKCgq0c+dOJSUlSZKSkpK0detWZWdnKyoqSmFhYTKbzYqNjVV6eroyMjLcYzt16qQ9e/bU9u4CAAAAAACgCjV2WN/y5cu1aNGictseffRR9e7dW9u3b3dvs9lsslgs7p+Dg4OVm5urgIAAhYeHu7dbLBZZrVZZrVaFhISU22az2dzbqtru5+enkpIS+fv7V1l7dHT0r9vpWlZf6kTtoB9QET0BT+p6X9T1+i5m3PaoiJ6AJ/QFPKEvUBlfe6PGwql+/fqpX79+XsdZLBbZbDb3z0VFRQoJCZHZbC63vTRoCgkJkc1mU2BgoGw2m0JDQ2WxWFRUVFRubOn2spfhdDq9BlOSlJOT4+tuGiY6Orpe1InaQT+gInoCntTtvnBNXOpufRe3ut0bMAI9AU/oC3hCX6AyFXujqqDK8G/rKw2ijhw5IqfTqbS0NMXHxysuLk5paWlyOBzKy8uT0+lURESEYmNjtWnTJknS5s2bFRcXp5YtW+rw4cMqLCyU3W5Xenq6OnXqVG5sZmam2rRpY+SuAgAAAAAAoAJDvq2vooceekjTp0+Xw+FQQkKCOnbsKEmKi4vTuHHj5HQ6lZycLEkaOHCgZsyYoWXLlik8PFwjR46U2WzW/fffr0mTJsnhcKhv376KjIxUjx49tGXLFvdljBgxwsjdBAAAAAAAQAUmZ9mvzYOk+nFIAUsnURb9gIroCXhSl/uiV4prmfeawXWzvotdXe4NGIOegCf0BTyhL1CZenVYHwAAAAAAAC5dhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMMQTgEAAAAAAMAwhFMAAAAAAAAwDOEUAAAAAAAADEM4BQAAAAAAAMOYjbjSn376SWvWrNGoUaMkSevWrdPcuXPVuHFjSdKdd96pzp07KyUlRampqfL399cDDzygmJgYFRQUaNq0aSouLlajRo00YsQIBQUFacOGDVqwYIH8/PzUt29f9e/fXw6HQ2+//bb279+vgIAADR8+XFFRUUbsMgAAAAAAADyo9XDqvffeU1pamtq1a+fetnfvXt17773q2bOne1tWVpZ27NihyZMn6/jx43rllVc0ZcoUzZ8/X9dcc42uv/56ff7551qyZIluuukmzZ49W1OmTFFwcLDGjx+v7t27a+fOnTp37pwmTZqkzMxMzZkzR2PGjKntXQYAAAAAAEAlav2wvtjYWD344IPltmVlZWnFihV69tlnNWfOHJWUlCgjI0OJiYkymUxq0qSJSkpKVFBQoJ07dyopKUmSlJSUpK1btyo7O1tRUVEKCwuT2WxWbGys0tPTlZGR4R7bqVMn7dmzp5b3FgAAAAAAAFWpsZVTy5cv16JFi8pte/TRR9W7d29t37693PaEhARdddVVatasmWbOnKklS5bIZrMpPDzcPcZischqtcpqtSokJKTcNpvN5t5W1XY/Pz+VlJTI39+/ytqjo6N/9X7XpvpSJ2oH/YCK6Al4Utf7oq7XdzHjtkdF9AQ8oS/gCX2ByvjaGzUWTvXr10/9+vXzaWzfvn0VGhoqSerevbvWrVuntm3bymazuceUBk0hISGy2WwKDAyUzWZTaGioLBaLioqKyo0t3V72MpxOp9dgSpJycnJ83U3DREdH14s6UTvoB1RET8CTutwXawa7/l9Hy7vo1eXegDHoCXhCX8AT+gKVqdgbVQVVhn9bn9Pp1JNPPqnjx49LkrZt26YOHTooLi5OaWlpcjgcysvLk9PpVEREhGJjY7Vp0yZJ0ubNmxUXF6eWLVvq8OHDKiwslN1uV3p6ujp16lRubGZmptq0aWPYfgIAAAAAAOBChnxbX1kmk0nDhw/Xyy+/rMDAQLVq1Uo33HCDzGaz4uLiNG7cODmdTiUnJ0uSBg4cqBkzZmjZsmUKDw/XyJEjZTabdf/992vSpElyOBzq27evIiMj1aNHD23ZssV9GSNGjDB4bwEAAAAAAFCWyel0Oo0uoq6pD0sSWTqJsugHVERPwBP6ApWhN1ARPQFP6At4Ql+gMvXqsD4AAAAAAABcuginAAAAAAAAYBjCKQAAAAAAABiGcAoAAAAAAACGIZwCAAAAAACAYQinAAAAAAAAYBjCKQAAAAAAABiGcAoAAAAAAACGMTmdTqfRRQAAAAAAAODSxMopAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAAAAAAIYhnAIAAAAAAIBhCKcAAAAAAABgGMKpOsrpdMputxtdBuoIh8Oh/Px897+BkpISLV68WAcOHDC6FNQxDodDxcXFRpeBOoZ5BSpibgFPmF/AE+YWqEx1zi8Ip+oYp9Op06dP65133uFFAZKks2fPavbs2UpJSZEk+fnxsL3UrV69Ws8++6zmzp2rpk2bGl0O6pClS5fq1Vdf1bx585Sbmyun02l0STAY8wp4wtwCnjC/gCfMLeBJTcwveCWqI0of5CaTSbm5uVqzZo127NihwsJCgyuDEco+6fv7++vo0aPKzc3Vhg0bJPEJ56XI4XCoqKhIU6dO1fr16/Xoo4+qV69eOnPmjNGloY44dOiQ1q9fr3vvvVdhYWFasmSJ0tLSJImJ5CWIeQUqYm4BT5hfoCrMLVBRTc4vCKfqgNOnT+vs2bPunzMyMnT11VcrOzubTzkvQRX7IS8vT+Hh4br99tu1ceNGnTp1ikMzLjGnT59WUVGRgoODdd9992nUqFFq1KiRjh8/rsjISKPLg4GsVquKiookSTt27FDjxo0VFRWlAQMGqHnz5tqxY4dOnz4tk8lkcKWoTcwrUBFzC3jC/AKeMLdAZWp6fkE4ZbAvv/xSU6ZM0ccff6z//ve/kqQuXbpo2LBhatq0qbZu3arjx48bXCVqS9l+WLhwoSTJbDYrLi5OrVu31r59+/Tyyy/rxIkTfFpxiSjtiU8++UQLFy5Uq1atJEmhoaEKDg5WZmamwRXCSB999JG++eYbSVK3bt2Unp6u3NxcRUREqF27dpKko0ePGlghahvzClTE3AKeML9AZZhbwJPamF8QThno8OHDSktL05gxY3TrrbcqLS1NK1asUJs2bSRJ1113nY4fP669e/fyadYloGI/bN26VT/++KOOHDmiFStWaObMmWrUqJEiIiIUFhbGpxWXgLI9cdttt2nr1q1atmyZJNcnFy1atFBwcLDBVcIoO3bs0LZt27Rr1y4dOHBAjRs3Vo8ePbRgwQJJUkxMjI4cOeJ+/eBN58WPeQUqYm4BT5hfoDLMLeBJbc0vCKcMdOrUKbVu3VpBQUFq0qSJBg8erE8//VQlJSWSpMaNGysmJkY//fSTTp48aXC1qGkV+2HQoEFKSUlRcXGx2rdvr4EDB2r06NFq2bKlVq9ebXS5qAWeeuLzzz9XSUmJwsPDdebMGW3evFkS5wq5FOXl5alfv3668sortXz5cknSH//4R+3evVtr165Vbm6uiouL3b3Bm86LH/MKVMTcAp4wv0BlmFvAk9qaXxBOGaD0wRwWFqajR4/q5MmTcjqdiouLU2xsrL799lv32L59++qGG27gGzMuYlX1Q3x8vPbu3avk5GTFxMTIZDLplltu0YABAwyuGjXJ23PE119/LUm64YYbtGrVKjkcDr5p6RJS2h89e/bU1VdfrQ4dOqigoECbN2+WxWLRfffdpz179ui1115Tz5491blzZ4MrRk1jXoGKmFvAE+YXqAxzC1RUdlVcbc0vTE7W4tW4b7/9ViaTSZ06dVK7du3cD34/Pz/NnTtXgYGBuummmxQREaEVK1bIbDbr2muv5QXhIvVr+6GkpET+/v4GV4+a8Gt7QhLPExc5T71R8f4uKirSmjVrlJ6eruHDh7t/T29cvErPBXLFFVeoVatWzCvwq3uCucXF7df2hcRryMXMU18wt4Akbd++Xbm5uerbt6+cTqecTqdMJpNMJlOtzC/orBpktVr14osvau/evQoLC9NHH32k1NRU+fn5yc/PT1lZWYqOjtaxY8e0ePFirVq1SkuWLFFoaKgk8cC/yPzWfmDyePH5rT0h8TxxsaqqNyTXOSE2btwoSQoODlZcXJwcDoe2bdvmvgx64+LidDpls9n06quvat++ffLz89OHH36ozZs3M6+4RFVHTzC3uPhUR19IPF9cbLz1hcTcAtLatWu1bt065efny2Qyyc/PTyaTqdbmF+ZquRR4ZLfbFRoaqvvuu09hYWGy2+36+OOP1bVrV82aNUv79u3TX/7yF3Xu3FmZmZnauHGjhgwZoiuuuMLo0lED6AdURE+gMt5648CBAxo6dKh7fLNmzXT//fcrIiLCwKpRU2w2mywWiwICAhQaGqq77rpLDRo0UEREhN5//30lJSVp1qxZ2rt3L88Zlwh6Ap7QF/DE177Yv38/c4tLTGlvSFJaWpoOHDigtm3b6ptvvtHdd9+t4uJizZkzR9nZ2Xrsscdq/DmDcKqaLVmyRJJ04403Ki8vT1arVQUFBQoLC1OzZs1kMpm0YsUK3X777WrSpIn776KiotSnTx+jykYNoR9QET2Byvza3pBcqx+YPF58iouLNW/ePJ04cULx8fGKj4+X3W5XQUGBwsPD1bNnT3333Xf68ssvdccddygyMtL9tzxnXJzoCXhCX8CT39IXEnOLi1lpb5w8eVIxMTG67bbb1L59e912221q0aKF5s+fr927dysmJkbXX3+9YmJi3H9bk88ZrMurZjt27NDnn3+us2fPqkOHDmrevLn++9//as6cOVq+fLmuu+46HTp0yP3Ggm/AuLjRD6iInkBl6A2UdfbsWc2dO1chISEaMmSIVq5c6V5Rt379evdXNd98883Kzs52v6mgLy5e9AQ8oS/gCX2BypTtjXvuuUerV6/W1q1bFRERoauuukpNmzZVp06dtHLlSklyB1O10RuEU79Rfn6++98HDx5USEiIoqOj9cEHH0iSBg0apIEDByoiIkL33nuvGjZsqNatW7v/huN2Ly70AyqiJ1AZegOelPaF0+nU7t27df311ysqKkqXX3659uzZo9tvv12ZmZnasmWLJOno0aNq0aKF++/pi4sPPQFP6At4Ql+gMpX1RkJCgnbv3u0eFxQUpISEBBUUFOjHH390b6+N3uCwvl/p+PHjSklJ0alTp9StWzclJiaqcePGuvXWWxUZGaknn3xSv//979WyZUvZbDZFRkbqvffe0+nTp3XXXXcZXT6qGf2AiugJVIbegCcV+6JLly4aOXKkGjduLEkqLCzUFVdcocjISPXp00cZGRlavHixSkpK9D//8z8GV4+aQE/AE/oCntAXqIy33jh16pR69+5d7m+aNWuma6655oJDPWuayel0Omv1Gi8SCxYskN1uV9++fbVy5UoVFBRoyJAhCg4OliTNnz9f+/bt05NPPimHw6H8/Hzt2LFD11xzjcGVoybQD6iInkBl6A14UrEvTp06pXvuuUchISE6cOCAZs+eraeffloBAQHKy8tTZGSk0tPTdfnllxtdOmoIPQFP6At4Ql+gMr70xjPPPCPJtbqq4nlNaxPh1C+wYsUKbd++XVFRUcrNzdX//M//qHnz5jpy5IiWLl2qyMhI3XLLLe7xjzzyiJKTk9WjRw8Dq0ZNoR9QET2BytAb8MRbXzRs2FC33XabfvrpJ2VnZ6tt27b69NNPdcstt1zwKScuDvQEPKEv4Al9gcr82t647bbb1LNnT8Pq5qBSH33wwQfatGmTbrnlFu3bt0/ff/+9+5uVIiMj1aVLFx07dkyFhYXuv3n88ccVHR1tVMmoQfQDKqInUBl6A5740hd5eXmSpA0bNuiTTz7Rhg0bNHToUN5UXKToCXhCX8AT+gKV+S29YWQwJXHOKZ9ZrVb1799fHTp00E033aTIyEitWrVK11xzjdq1a6cGDRro3LlzCg4OltPplMlkUpcuXYwuGzWEfkBF9AQqQ2/AE1/6ori4WMXFxYqPj1diYqKuvvpqo8tGDaIn4Al9AU/oC1SmPvcG4ZQPHA6Hfve736ljx46SpNWrV6t79+5q06aN3nvvPT3yyCPasmWLTp8+LYfDIbOZm/ViRj+gInoClaE34ImvfVFYWCg/Pz/17dvX4IpR0+gJeEJfwBP6ApWp773BLNgHfn5+SkhIkORKIvfu3as777xTV155pQoKCrR06VLl5+dr6NChCgwMNLha1DT6ARXRE6gMvQFPfO2LYcOGEVheIugJeEJfwBP6ApWp771R9yqq406cOKEuXbrIarXq3XffVZs2bTRkyJA6eeei5tEPqIieQGXoDXhCX6AiegKe0BfwhL5AZepjb9Tdyuqo9PR0LVy4UHv37lWfPn107bXXGl0SDEQ/oCJ6ApWhN+AJfYGK6Al4Ql/AE/oClamPvWFyOp1Oo4uoT1asWKGTJ0/qjjvuqNOpI2oH/YCK6AlUht6AJ/QFKqIn4Al9AU/oC1SmPvYG4dQvVPpNSoBEP+BC9AQqQ2/AE/oCFdET8IS+gCf0BSpTH3uDcAoAAAAAAACG8TO6AAAAAAAAAFy6CKcAAAAAAABgGMIpAAAAAAAAGIZwCgAAoA5bu3atJkyYUOWY+fPna/369bVTEAAAQDUjnAIAAKjntm3bppKSEqPLAAAA+FXMRhcAAACA8j7++GP9+OOPCgsLU4sWLSRJOTk5euedd1RUVKSTJ0+qXbt2euKJJ7R8+XLt2bNH77//vvz8/HTllVdq7ty5Sk9Pl8PhULt27TR06FCFhIQYvFcAAACemZxOp9PoIgAAAOCyfv16ffjhh5o0aZICAwP10ksvqaioSJdddpnatm2rPn36yG636+mnn9agQYPUs2dPTZgwQTfddJN69uyp+fPny2az6b777pPJZNK8efNktVr14IMPGr1rAAAAHrFyCgAAoA7ZunWrevToIYvFIknq27evvv76a917773asmWLFi5cqMOHD+vkyZMqKiq64O83btwoq9WqLVu2SJLsdrsaNGhQq/sAAADwSxBOAQAA1GH+/v6SpNdee00lJSXq3bu3rrzySuXl5Xkc73A49MADD6hr166SpKKiIhUXF9davQAAAL8UJ0QHAACoQ5KSkrRmzRqdOXNGDodDK1eulCSlpaVp0KBB6t27tyRp165dcjgcklwBlt1ulyQlJibqm2++kd1ul8Ph0BtvvKF58+YZszMAAAA+4JxTAAAAdcznn3+uZcuWKSwsTG3bttWRI0fUq1cvffHFFwoKClJISIjCwsLUunVrDRkyRF999ZUWLVqkwYMHq3fv3pozZ4527NjhPiH6ww8/zAnRAQBAnUU4BQAAAAAAAMNwWB8AAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADAM4RQAAAAAAAAMQzgFAAAAAAAAwxBOAQAAAAAAwDCEUwAAAAAAADDM/weLiuiF7viMpwAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 1440x432 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.style.use('ggplot')\n",
    "plt.title('Units sold per week')\n",
    "\n",
    "plt.ylabel('units')\n",
    "plt.xlabel('date');\n",
    "\n",
    "df2b['units'].plot(figsize=(20,6), c='dodgerblue');"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 23,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 343
    },
    "id": "giXyE1Vc8Mps",
    "outputId": "632a7fe8-c051-4e61-ee1d-f3d4111595ac"
   },
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAABI0AAAF0CAYAAACubclCAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMSwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy/YYfK9AAAACXBIWXMAAAsTAAALEwEAmpwYAABUmUlEQVR4nO3deXhU5fn/8c/MZE9IQiAQBllEBBcCEhAJAooiWlDrAq2otUVad9t+xVqtVfH7FbVq609rF1usSxW1ESnuiooigrIpu7LKlkAI2ZdJMjPn98eZmSQzmcmAmUyW9+u6cs325Jx7zrnPOc/c88w5FsMwDAEAAAAAAACNWKMdAAAAAAAAANofikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAAIAAFI0AAECbOOecczR06NAmfzk5Obrqqqu0YcOGaIeHFuzfv19Dhw7Vtm3boh0KAABoIxSNAABAm7ntttu0fPlyLV++XJ999pmee+45xcbG6he/+IWqqqqiHR4AAAAaoWgEAADaTHJysjIzM5WZmalevXpp+PDhevjhh1VaWqovvvgi2uEBAACgEYpGAAAgquLi4iRJNpvN99wzzzyjSZMmaeTIkZo5c6a+/vprSdLKlSt16qmnqqSkxNe2uLhYp556qtatWydJ+vTTT/XDH/5Qw4cP17Rp07Rw4UJf29dff12XXXaZ/vnPf2r8+PE644wzdPvtt6u6ulqS9Oc//1mXXXZZk/h+8pOf6A9/+IPvcajp+3v99df1wx/+UE8//bTGjBmjsWPH6k9/+pPcbrevzfr163XFFVcoOztbU6ZM0T//+U/f66+//rouvfRS3X777crJydFf//rXJtP/8MMPNXLkSDmdTt+yOOmkk/T000/72tx777264447JEm7d+/W7NmzNWLECE2aNEmPPPKI6urqfG1ber2xjz76SNnZ2XrnnXeCvn8AANCxUTQCAABRU1JSot///vfKzMzU6NGjJUmvvPKKXnjhBd13331atGiRzjrrLP30pz/Vvn37dMYZZ6h79+768MMPfdN4//33lZWVpZycHG3fvl2//OUvdcUVV+itt97SzTffrD/84Q96++23fe23bdumtWvX6tlnn9UDDzygJUuW6JVXXgkr3nCm72/nzp1aunSpnn/+eT300EN69dVXfcWfI0eOaPbs2ZowYYLefPNN3X333VqwYIHmz5/v+/8tW7YoOTlZixYt0iWXXNJk2rm5uaqvr/edE8o7WmvNmjW+Np9//rnOPvts1dbWavbs2erXr58WLVqkRx55RJ999pkeeOABSWrx9cZWr16tOXPm6H//9381derUsJYdAADoeCgaAQCANvPwww9r5MiRGjlypEaMGKEJEyaourpazz77rFJSUiRJTz/9tObMmaOzzz5bAwcO1A033KBRo0ZpwYIFslqtmjZtmt59913fNN955x1deOGFkqT58+froosu0syZM9W/f39NnTpV1157rZ555hlf+/r6ev3f//2fTjzxRJ133nmaMGGCNm/eHFb84Uzfn8vl0mOPPaaTTz5ZkyZN0o033qiXX35ZhmHopZdeUnZ2tm6++WYNHDhQZ511lm677baA6d1yyy0aMGCA7HZ7k+eTk5OVk5PjKxZ9+eWXOvvss7Vu3Tq53W599913Kigo0Jlnnqm33npLsbGxuu+++zRo0CCdfvrpuv/++5WXl6fKysoWX/fasmWLbrzxRv32t7/VpZdeGtZyAwAAHVNMtAMAAABdx/XXX6+LL75YdXV1WrBggZYsWaJbbrlFJ554oiSpqqpK+fn5uueee3Tffff5/q+urs73M7YLL7xQV1xxhYqLi+V0OrVmzRrde++9ksyRQNu2bWsy8sfpdCompqHL4z2vkldKSorv52ktCWf6/vr06aPjjjvO93j48OEqKipSSUmJduzYoVWrVmnkyJG+191utxwOh+8neImJiU3i9Tdx4kQtW7ZMN910k7788kvde++9+vLLL/Xtt99q7dq1GjlypNLS0rRjxw7t27dPOTk5vv81DMNXXGrp9fT0dEnSPffco/r6evXt2zesZQYAADquDlc02r59u1566SXNnTs3aJtPPvlEH3zwgdxut0aPHq3p06e3XYAAACCo7t27a8CAAZKk++67T8XFxbrxxhv1xhtvqE+fPr5z+Tz88MM65ZRTmvxvQkKCJCk7O1v9+vXTkiVLVFtbqyFDhviKTi6XSz/5yU90xRVXBI0hNjY26GsWiyXgOe/5gsKdvr/G52qS5HuPVqtVTqdTU6ZM0a9//euA/+vWrZskKT4+PuT0J06cqCeffFL79u3TgQMHNGrUKI0cOVKrV6/WihUrdNZZZ/nex2mnnaaHHnooYBq9e/du8fWioiJJ0nXXXafi4mLdf//9evvtt33rBQAAdD4d6udpixcv1t///nfV19cHbXPw4EF98MEHmjt3rh588EE5nc4mnT0AANB+3HfffbLZbL4vg7p166bMzEwdOnRIAwYM8P29+OKL+uyzz3z/d+GFF+rjjz/WkiVLdNFFF/meP+GEE7Rnz54m/7tq1SotWLAgrHhiY2Ob/BTLMAzt37//e02/oKBAxcXFvscbN25Unz59lJ6erhNOOEG7du1qMr2dO3fqL3/5i6zW8LppQ4YMUUZGhubPn68RI0YoPj5ep59+ulasWKEvv/zSVzTyxp6VleWbV1lZmf74xz+qvr6+xde9zj//fP3P//yPampq9NRTT4UVIwAA6Jg6VNGod+/euv32232P9+7dq/vvv19z587VY489purqam3cuFGDBg3SU089pblz5+qkk04KOWQcAABET0ZGhubMmaNPPvnEd3Lrn//85/rrX/+qd955R/v27dNf//pXvfTSSzr++ON9/3fRRRfpiy++0FdffaVp06b5nr/22mv1ySef6O9//7v27Nmj999/Xw8++KB69OgRVjzZ2dnas2ePFixYoL179+rBBx9UWVnZ95p+fX297rrrLm3fvl0fffSR/v73v+uaa66RJF111VXas2ePHnjgAe3atUsrVqzQvffeq8TExLCLRpI0YcIELVy4UKeffrokacyYMfrkk0+UlpamoUOHSpIuvvhiWa1W/fa3v9W2bdv01Vdf6a677lJ1dbW6devW4uuNpaam6vbbb9ezzz6rb7/9Nuw4AQBAx9KhikZjx45tMsT76aef1uzZszV37lzl5ORo8eLFqqio0NatW3XjjTdqzpw5+te//qWqqqooRg0AAEKZPn26cnJy9OCDD6qmpkbXXHONrr32Wj366KOaOnWq3n33XT355JMaNWqU738GDBigIUOG6LTTTlOfPn18zw8bNkxPPvmk3nnnHU2bNk0PP/ywrrvuOv3iF78IK5bc3Fxdd911euKJJ3TZZZf5Trz9faafnp6u7OxsXXHFFZo7d65mz56tWbNmSZKysrI0f/58bdq0ST/84Q91xx13aOrUqbr77ruPahlOnDhR9fX1GjNmjCSz+JWQkKCJEyf62iQlJelf//qXysvLNWPGDN1www3Kzs7WH//4x7Be93fppZdq+PDhuu+++2QYxlHFCwAAOgaL0cGO8oWFhXriiSc0b948/fSnP/V96+hyudSnTx8NHjxY+/fv17XXXitJeuSRR3TZZZdp8ODB0QwbAAB0Qa+//rr+8Ic/6Msvv4x2KAAAAEetQ/9uy26365ZbblHPnj31zTffqLS0VHa7Xe+//77q6urkdru1f/9+ZWVlRTtUAAAAAACADqVDF41+8Ytf6KmnnvJdheSGG26Q3W7XOeeco3vuuUeSdPnllyslJSWaYQIAAAAAAHQ4He7naQAAAAAAAIi8DnUibAAAAAAAALQNikYAAAAAAAAIQNEIAAAAAAAAASJyImyn06m//e1vOnz4sOrr63X55Zdr9OjRvtffeustffzxx0pNTZUkXXfddbLb7S1ONz8/PxLhtiq73d4h4kTbIB/gj5xAMOQGmkNeoDnkBfyREwiG3EBz/PMiVD0mIkWjzz77TN26ddOtt96qiooK3XHHHU2KRrt27dItt9yiQYMGRWL2AAAAAAAA+J4iUjTKzc3V2LFjfY9tNluT13fv3q1FixaptLRUOTk5uvTSSyMRBgAAAAAAAI6RxTAMI1ITr6mp0SOPPKJzzz1X48eP9z2fl5en888/X0lJSXr00Uc1ZcoUjRo1KlJhAAAAAAAA4ChFrGhUVFSkxx57TFOmTNE555zje94wDNXU1CgpKUmS9P7776uiokLTp09vcZod4beY/GYUjZEP8EdOIBhyA80hL9Ac8gL+yAkEQ26gOUdzTqOIXD2ttLRU8+bN01VXXdWkYCSZo4/mzJkjh8MhwzC0adMmzm0EAAAAAADQzkTknEaLFi1SZWWlFi5cqIULF0qSzj33XNXW1mry5MmaOXOm7r//fsXExCg7O1s5OTmRCAMAAAAAAADHKCJFo1mzZmnWrFlBX584caImTpwYiVkDAAAAAACgFUTk52kAAAAAAADo2CgaAQAAAAAAIABFIwAAAAAAAASgaAQchcIaq3Lz7HpmS0q0QwEAAAAAIKIoGgFH4eN9iZKk+ZtToxwJAAAAAACRRdEIAAAAAAAAASgaAQAAAAAAIABFIwAtmr+5m658PzPaYQAAAAAA2lBMtAMA0P49s6WbJKnOJcXZohwMAAAAAKBNMNIIQNiMaAcAAAAAAGgzFI0AAAAAAAAQgKIROqR7v0jXi9+kRDsMAAAAAAA6LYpG6JCW7EvSXzamRjsMAAAAAAA6LYpGAAAAAAAACEDRCAAAAAAAAAEoGgEAAAAAACAARSMAAAAAAAAEoGgEAAAAAACAABSNAAAAAAAAEICiEQAA6DIO19D1AQAACBc9JwAA0CW8812iLn4rS79b0T3aoQAAAHQIFI0AAECXsLk4TpL0dVFclCMBAADoGCgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAAIAAFI0AAAAAAAAQgKIRAAAAAAAAAlA0AgAAAAAAQACKRgAAAAAAAAhA0QgAAAAAAAABKBoBAAAAAAAgAEUjAAAAAAAABKBoBAAAAAAAgAAUjQAAAAAAABCAohEAAAAAAAACUDQCAAAAAABAAIpGAAAAAACg03pmS4pe3pYc7TA6pJhoBwAAAAAAABAp8zenSpJmDqmKciQdDyONAAAAAAAAEICiEQAAAAAAAAJQNAIAAAAAAEAAikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASIicREnU6n/va3v+nw4cOqr6/X5ZdfrtGjR/teX7NmjRYuXCir1apJkyZp8uTJkQgDAAAAAAAAxygiRaPPPvtM3bp106233qqKigrdcccdvqKR0+nU888/r4ceekgJCQm65557NHr0aKWnp0ciFAAAAAAAAByDiPw8LTc3Vz/+8Y99j202m+/+gQMHlJWVpZSUFMXExGjo0KHaunVrJMIAAAAAAADAMYrISKOEhARJUk1Njf70pz/piiuu8L1WU1OjpKQk3+PExERVV1eHNV273d66gUZIR4mzM2jrZZ126Ojn3ZnyoU8fuxIistfoWjpTTqB1kRuRlfSNeWu12jrUsu5IsaLtkBfwR04gGHKjAcuiQbjLImIf/4qKivTYY49pypQpGj9+vO/5xMREORwO3+OamholJyeHNc38/PxWj7O12e32DhFnx2cmeFsv67KyZElpYc+78+SDubwLCvIVb2uhKULqPDmB1kZuRF51dZqkZLndLuXnH2qxfXtAXqA55AX8kRMIhtzwis7nx/bKPy9CFZAi8vO00tJSzZs3T1dddZXOOeecJq/17dtXBQUFqqyslNPp1NatWzVkyJBIhAEAAAAAAIBjFJGRRosWLVJlZaUWLlyohQsXSpLOPfdc1dbWavLkybrmmms0b948ud1uTZo0SRkZGZEIAwAAAAAAAMcoIkWjWbNmadasWUFfHz16tO9qagAAAAAAAGh/IvLzNAAAAAAAAHRsFI0AAAAAAAAQgKIRAAAAAAAAAlA0AgAAAAAAQACKRgAAAAAAAAhA0QgAAAAAAAABKBoBAAAAAAAgAEUjAAAAAAAABKBoBAAAAAAAgAAUjQAAAAAAABCAohEAAAAAAAACUDQCAAAAAABAAIpGAAAAAAAACEDRCAAAAAAAAAEoGgEAAAAAACAARSMAAAAAAAAEoGgEAACCemNXknLz7Kqst0Q7FAAAALQxikYAACCoh9amS5Le3ZMY3UAAAADQ5igaAQCAFhkGI40AAAC6GopGAAAAAAAACEDRCAAAAAAAAAEoGgEAAAAAACAARSMAAAAAAAAEoGgEAAAAAACAABSNAAAAAAAAEICiEQAAAAAAAAJQNAIAAAAAAEAAikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAAIAAFI0AAAAAAAAQgKIRAAAAAAAAAlA0AgAAAAAAQACKRgAAoM0YhpSbZ9evlmVEOxQAAAC0gKIRAABoM2V1Ztdj1aGEKEcCAACAllA0AgCgE3EZ0Y4AAAAAnQVFIwAAOgmnWxr/ml25efZohwIAANBpvb4zSbl5dn28v/OPnKZoBABAFBmtODKoxmlpvYkBAACgWYt3JUmS3v0uKcqRRB5FIwAAouTOFd017jW7tpXGRDsUNMLJugEAAEwUjQAAiJJPDyRKktYWxkc5EjRWXMvJugEAACSKRgAAAAAAAGgGRSMAAAAAAAAEoGiEiNtcHKvcPLvKakOfoLWy3qLcPLvvpGIAAAAAACB6Ilo02r59u+bOnRvw/FtvvaXbbrtNc+fO1dy5c5Wfnx/JMBBld35unkj0+W+6hWz3/h7z3B4Pr02PdEgAAAAAAKAFEbtcy+LFi7Vs2TIlJASeRHLXrl265ZZbNGjQoEjNHu1Ivdu8rXOFHmnkboNYAAANDEOyhN41AwAAoAuL2Eij3r176/bbb2/2td27d2vRokW65557tGjRokiFAAAAgsjNs2vca/ZohwEAAIB2LGIjjcaOHavCwsJmXxs3bpzOP/98JSUl6dFHH9XatWs1atSoFqdpt3eMzm1HibOtWD2lyeTkZNntyUHbpR1uuB/uMmzrZZ126Ojn3ZnyoU8fuxIittfo/A6US6sOSGP6dp6cQOtITU2T9P33F2W1Dfdbex+VlpYmuz3tWMJqIqHm6OfdWpK+MW+tVlvIecdUNdxvD/vw9hAD2h/yAv7ICQRDbjRorWURG2veJiQkdNjlG27cbf7xzzAMTZs2TUlJ5smOc3JytHv37rCKRh3h3Ed2u71DxNmW3O7ekmyqqqpSfn5Z0HZlZUmS0iWFs67tYbZrXWVlyZLSwp5358kHc3kXFOQr3hblUDqwcXnmclw5ozPkBFqHmRPl5WWS0r73/qKiziKpj6TW3I+a7crKypSfX9VC25aV1lolZYU579ZVXZ0mKVlut0v5+YeCtjviiF6M/jrPcQStibyAP3ICwZAbXq37+bG+vqekODkcDuXnF7fKNNuSf16EKiC1+dXTampqNGfOHDkcDhmGoU2bNnFuIwAAAAAAgHamzUYaLV++XA6HQ5MnT9bMmTN1//33KyYmRtnZ2crJyWmrMAAAAAAAABCGiBaNevXqpXnz5kmSxo8f73t+4sSJmjhxYiRnDQAAAAAAgO+hzX+eBgAAAAAAgPaPohEAoMvbeCRWbiPaUQAAAADtC0UjAECX9u6eRF33caau/7hntEMBAAAA2hWKRgCALm1nWawkaXtZm10bAgAAAOgQKBoBAAAAAAAgAEUjAADCYBhSbp5dP1vCz9gAAADQNVA0AgAgDDUuiyTp29K4KEcCAAAAtA2KRgAAAAAAAAhA0QgAEFH7KmwyuJw9AAAA0OFQNAIARMwn+xP0o/d666ZPerTaNFcditN/tie32vQAAAAANI/rCwMAImZriXk5+01HWu88QL9aZp6I+kcnVrXaNAEAAAAEYqRRB7eyIF65eXblV9labZq3ftpDT65PbbXpAQAAAACAjoeiUQf34Jp0SdJL36a02jTXFMbr5W2tNz0AAAAAANDxUDTq4NxG01sA6Ki+LYlVaS2HJQAAAKC94JxGAICoc7qln32YKUlaOSM/ytEAAAAAkBhpBABoB1yMlgQAAADaHYpGAAAAAAAACEDRCAAAAAAAAAEoGgEAAAAAACAARSMAAAAAANDlPbc1Rbl5dhmcb9OHohEAAAAAAOjynt6UKknaXsaF5r0oGgEAAAAAAHi43JZoh9BuhFU0OnDggD766CMZhqHHH39ct956qzZt2hTp2AAAAAAAABAlYRWN/vGPfyguLk7r1q1TcXGxbrjhBr388suRjg0AgGO2qyxGt3zaQy5+kw4AAAAck7CKRvX19ZowYYLWr1+v3NxcnXrqqXK5XJGODQCAY/bTJZlaWxivN3cnRTsUAAAAoEMKu2hUWlqqdevWafjw4SotLVVdXV2kYwMA4Jg5DfO36JV1nL4PAAAAOBZh9aTPO+883XzzzTrppJN03HHH6a677tLUqVMjHRsAAB3SH9am6cfv9op2GAAAAMD3EtZ15EaPHq3JkyfLajVrTI888ojKysoiGhgAAB3Vf3clRzsEAAAA4HsLOdKosrJSlZWVeuihh1RdXe177HK59Nhjj7VVjAAAAAAAAGhjIUcaPfHEE9qwYYMkafbs2b7nrVarxo4dG9nIAAAAAAAAEDUhi0Z33323JOmvf/2rbrrppjYJCA0MQ7JYoh0FAAAAAADoikIWjQ4cOKC+ffvqggsu0K5duwJeHzRoUMQC6+rGv9ZHLsOiZZfnK5YL/wAAAAAAgDYWsmj073//W3feeaf++Mc/BrxmsVj01FNPRSywrs7luVR0aa1VmYnuKEcDAAAAAAC6mpBFozvvvFOS9Je//KVNggEAAAAAAED7ELJo5FVaWqolS5aosrJShmH4nr/22msjFhgAAAAAAACiJ6yi0Z///GfFx8dr4MCBsnBmZgDo1FyGZGNXDwAAAHR5YRWNiouL9fjjj0c6FgBAlOXm2SVJK2fkRzkSAAAAANEW1nW5evbsKYfDEelYAAAAAAAA0E6ENdKoe/fuuuOOO3TKKacoLi7O9zznNAIAAAAAAOicwioaZWZmKjMz03c+I8MwOLcRAAAAAABAJxZW0eiLL76QxWLxXTnNWzCaPn165CIDAAAAAABA1IRVNJo9e7bvvtPp1Oeff67evXtHLCgAAAAAAABEV1hFo1NOOaXJ4+zsbP3+97/XZZddFpGgAAAAAAAAEF1hXT3NX0VFhUpKSlo7FgAAAAAAALQTYY00mjNnTpOTYBcVFem8886LaGAAAAAAAACInqM+p5Ekpaam6rjjjmvx/7Zv366XXnpJc+fObfL8mjVrtHDhQlmtVk2aNEmTJ08OP2IAAIBG6lzShiNxGt2rLtqhAAAAdCrHdE6jcCxevFjLli1TQkJCk+edTqeef/55PfTQQ0pISNA999yj0aNHKz09/ajnAQAAcPFbvVVWZ9OfzyqicAQAANCKjumcRuHo3bu3br/99oDnDxw4oKysLKWkpCgmJkZDhw7V1q1bIxUGAADo5MrqbJKkPeVhfRcGAACAMEWsdzV27FgVFhYGPF9TU6OkpCTf48TERFVXV4c1Tbvd3mrxRVJrxpnVO0u9U4K/bjP7yUpOSpbdntxq85Va731YPaXJ5OTQMaYdPvp5t3VOpB06+nl3lLwNR58+diXwmex76wg50Voxdttt3loslpDTdDiPft7htktNTZXdnhr09ZRd3hitIadZ1WgAS+vHmHZU7YMpqz36eYfbLi0tTXZ7WtDX95dLZz4rPXORNHlQ8Okk1Bz9vMOVlpYuuz096OtJ35i3Vqst5Lxjqhrut4fttT3EgPaHvIA/cgLBkBsNwl0WmZmZsvcO/npsrHmbkJDQYZdvuHG3+ce/xMREORwO3+OamholJ4dX7MjPz49UWK3Gbre3UpzmCjx46KBc5e6grVyu3pJsqqquUn5+WSvMt2HerbW83W5PjFWhYywrS5KUHua8WzfGcJWVJUtKC3verZcP0WYu74KCfMXbohxKhxadvD06rRtjRWU3Sd1kGIby8wuCtqt1Hc28j65deXm58vMrg7aqrEyVlCLDcCs//2DQdtVOi6Q+EYqxTFJa0PZOt/TYujT9YliFeiQEPyZU1EUuxrKyMuXnVwVt9cTX5nK87X2X3vvhoaDtSmutkrLCnHe4vDGWKj8/+BdR1dVpkpLldruUnx88xiOOSMR4bDrPcQStibyAP3ICwZAbXkfX7zl8+LDyXfVBW9XX95QUJ4fDofz84laKse3450WoAlLEfp4WTN++fVVQUKDKyko5nU5t3bpVQ4YMaeswAKBL+c3yDOVtb93RiGg7C7alaPHuZN2wtGe0QwnKMMxbt2GJbiBtzDDMoh4AAEBn1GYjjZYvXy6Hw6HJkyfrmmuu0bx58+R2uzVp0iRlZGS0VRgA0OW4DWl5QYKWFyRoxonBR4qg/SpxmN/xFDva/LsetGDca+Y3cytn8C0uAADofCJaNOrVq5fmzZsnSRo/frzv+dGjR2v06NGRnDUAAAAAAAC+B76yBAAAAAAAQACKRm3syfWpen1nUssNAQAAAAAAooiLZ7exl7elSJIuOyH41V0AAAAAAACijZFGAAAAAAAACEDRCAAAAAAAAAEoGgEAAAAAACAARSMAAAAAAAAEoGgEAAAAAACAABSNAAAAAAAAEICiEQAAAAAAAAJQNAIAAAAAAEAAikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAQDuUm2dXbp492mGgC6NoBAAAAAAAgAAUjQAAAAAAABCAohEAAAAAAAACUDQCAAAAAABAAIpGAAAAAAAACEDRCAAAAAAAAAEoGgEAgHbLMKIdAQAAQNdF0QgAALRLuXl2jXvNHu0wAADocsrqLMrNs+vGpT2iHQqijKIRECGPrkvTy5uiHQUAAAAAHJ1viuMkSV8XxUc5EkQbRSMgQl7fmaw7P4p2FAAAAAAAHBuKRgAAAAAAAAhA0QhAu/bajiStK4yLdhjw89K3ycrNs+tgtS3aoQAAAACIEIpGANq1P36Vrps/7RntMODnqQ1pkqR3v0uMciQA2rPNxbGqqLNEOwwAAHCMYqIdAAAAADqfqnqLfv5RpiRp5Yz8KEcDAACOBSONAAAA0OrK6+hmAgDQ0XE0BwAAAAAAQACKRgAAAAAAAAhA0QgAAAAAAAABKBoBAAAA7dihaquc7mhHAaAz2F4ao9w8u3aXc00shIeiEQAAANBOVdRZdMnbWZqw0B7tUAC0Y//v61Tl5tlbLDD/6as0SdKf16e2QVToDCgaAQAAAO3UEYct2iEA6ABe3Z4iSdpcHBeyndOwSJJcRsRDQidB0QiQ9OR6szK/tjD0Thbt15T/Zik3zy6DAyAAAAAAtAqKRoCkN3cnSZKW5SdEORIcq4p6c3fGtyYAAAAA0DooGgEAAAAAACAARSMAAAAAQFh+t6K71nBKB6DLoGgEAAAAAGjRzrIYLT2QqFs/7RntUAC0EYpGAAAAAIAWVdVboh0CgDZG0QgAAAAAAAABKBoBAAAAAAAgQEykJux2uzV//nzt2bNHsbGxuuGGG5SVleV7/a233tLHH3+s1NRUSdJ1110nu90eqXAAAAAAAABwFCJWNFq9erXq6+s1b948bdu2TS+88ILuuOMO3+u7du3SLbfcokGDBkUqBAAAAABAFDjdkiEplt+2wOPlbcl6cn2aVkzPl4XTY3UYEduEv/nmG5122mmSpCFDhmjnzp1NXt+9e7cWLVqke+65R4sWLYpUGAAAAACANjZhoV0TF/JLEjR4cn2aJOnb0tiQ7Q5VWzXzvUwVO6g4tgcRG2lUU1OjpKQk32Or1SqXyyWbzSZJGjdunM4//3wlJSXp0Ucf1dq1azVq1KiQ0+woP18LJ85w30tW7yz1Tgn+umdxKjkpWXZ7cljTDFdrLW+rZ1tPTg4dY9rho593q8XoqXSnJKfIbg++wNMOHf28O0rehqNPH7sSIrbXCO1olndMOz++tHVOuI2jn3e47bqlpspuTw3++m7z1mKxhJymwxm5GFNbiDFllzdGa8hpVtVFMsa0kO2Td5i3VmvoGMtqIxdjWlqa7Pa0oK8nbwsvxoSaSMaYLrs9PejrSd+Yt1arLeQ0Y6qOft6R3K476nHEVd5wv6X38PgX0r5y6U9TIhxUB1Sd0HC/8XLsqHmByPk+OVHrlP65Tvp5jkL29fKPYX7kausIdzn27NFT/k0b/29cnHkbH58Qcpo96sOf990fS/E26d6zwgpR6RmZsvcJ/vqchdJ3FdLfvsnSX6aGN81whbscMzMzZe8d/PVYT90rISH0cmzPwo07Yh//EhMTVVPT0DM0DMNXMDIMQ9OmTfMVlXJycrR79+4Wi0b5+fkhX28P7HZ7C3GaK6bl92K2O3jooFzl7qCtXK7ekmyqqq5Sfn7Z0QX7vWMMj9vtibEqdIxlZUmS0sOcdyvHaGRJsqqyqlL5+eVB25WVJUtKi0qM0WW+l4KCfMXbojPvo1ne7bdoFJ2cMItGR78cw2lXUV6u/PzKoK0qKrtJ6ibDMJSfXxC0Xa0rcjGWtxBjZWWqpBQZhlv5+QeDtqt2WiT1iVCMZZLSgrav8sTodoeOsaIucjGWlZUpP78qaKuqqvBiLK21SsqKUIylys+vDtqqujpNUrLcbpfy8w8FbXfEEYkYj03L/Yr2q7DKJsnscbf0Hv7fl+ZyvH1Yx3yvkVRYHiOpl6SG5diR8wKR8X1z4qE1aXpjd7LW7qvRvNySoO2KimIlZUpqvf3jjtIYvbMnSb8cEbwPLknbS2N0zZJeem5yoYZ2d4Zs27kc3bGw6EiR8i0N33T550ZdXU9JcaqtdSg/vzjo1I4ciZfUI6x5v7jRnPfPTwwzxqLDyjfqg7YqqTJjPFIROkZJchmSLayfuh3dcjx8+LDyXcFjrK83Y3Q4Wo6xPfLPi1AFpIh9tBo6dKi++uorSdK2bdvUv39/32s1NTWaM2eOHA6HDMPQpk2bOLcRAAAAAETBoWpbk9u29JMlvfTythRtKw09nuHPnp82eW+BwzVWjX/Nrh+92yvaoXRqERtpNGbMGG3YsEG///3vZRiGbrrpJi1fvlwOh0OTJ0/WzJkzdf/99ysmJkbZ2dnKycmJVCgAAAAAgHbMHIkanPfn9i4jZDN0Ids950baVxml82d0ERFbularVdddd12T5/r27eu7P3HiRE2cODFSswcAAAAAAMD30G7P/AEAAACgc6mqt6islmttA0BHwTguAAAAAG1i8n/Nk/WvnMGJvAGgI2CkEQAAAAAAQaw+FKc5n2VEOwwgKhhpBAAAAABAEL9c1lOS9G1JrIZ2D34ZdqAzYqQRAAAAAAAtqKrnfFzoeigaAQAAdGK5eXbl5tmjHQYAAOiAKBoBAABE2I7SGN3xeXcZRrQjASLjZ0t66v09idEOo1Us3pWkV7YlRzsMdFDFDj5io3Mho4Eu7I1dSfr6cFy0wwCATu8nS3rps/xELT2QEO1QgFa3r8Kmb0vjNHdV92iH0ioeXpuuJ9anRTsMdEBPb+qmaW9maf7mbtEOBWg1FI2ALuyhtem68ZOe0Q4DALqM8jq6Xh1VZb1FRzrJCIKH16YpN8+uirrWOT9Lrav1z/NS7LDq7e86x8gldB3eL2P5UhadSec48gHw2VYao9w8u+79Ij3aoQAA0Gmc998+uvDNrGiH0SoW7zJ/erW6MD7KkQQ37c0sPbC6u74tiY12KADQpVE0AjqZVQfNnz4s2ZcUlfm7OF8HAHRIS/cnKDfPLqc7dLt1h+OUm2dX3o7oHGc6i4o6i679sKcOVtuiHUq7xvIBgOiiaASg1dz/ZbrGv2bX6kMMyQWAjuZ3KzMkSR/uC/2ToLd3m8WiBd+mRDymzuwvG1O1tSROd6/sHOcBipY1hWYR86N9nC8MACKBohGAVvPxfvODxupD7Xe4OwAgtPoWRhpFk8uQdpbFRDuMVlFVb3bDK+tb73xAz21N0eNfp7ba9DqCvO3mT+2e38qJhwEgEigaAQAAoEO4YHGWrv6gl77hPDfNenpTqv6znRFgAIDWQ9EIAAAAHUKlZ3TOrk4y2ggAgPaOohEAAEAHYxhSbp5d/7sqPdqhoBPbUBSr3Dy7PtnP+YKA1lRRZ1Funl03Lu0R7VCAFlE0AoAO7OvDcVyxDuiCDjvMLty7e7iCWXP2VNiUm2fXKi7M8L28ss38qds/N3O+IHRODqdFDlfbz/fbUvMntl8XcR5QtH8UjQB0KU+uT1Vunr3F82HsKItRbp5dT65vvycU/XBfgm78pKd+tiQz2qEAaGsUi0N6znNS5MfWpUc3EADt2qRFfTTpdXu0wwDaNYpGALqU/3iusvLpgdBD7b2vv7yt/Z5QdFeZWfjqLFcSAoDWYniKam6Ka/Bwe37S+UQrXl3O6ZZ2lLbuMbigyiZnO76CIYCuh6IRAAAAgE5tu6e480orXl1uwkK7frKkl/ZU2FplesUOqy57p7cmLGTkC4D2g6IRAHxPuXl2TX2jd7TDANAJFFSZ5+JZzbl4gFZmidiU91W0zmijgurWKT5BuvbDnvosn/MFAa2BolEXUeywKjfPrvmcyBCIiJLa1u3oHapm9wx0Rc9/Y46CeHBNenQDAYAO6puSWG0tidMdn3NlMqA18Kmki/jEc36WZ7ZQNGpvDENRuWoD2q/rP+6hS97O0ooCviEDuhrvOXhcRuRGRQBAZ1bjZP8JtCaKRkCUjXvNrkmv21s86WGxw6rHv07l8updwIYjZrFoSzE/TwEAAIEcLoojANoGl9wB2olal0Ux1uAVoes+7qkDVTHqnejSlUOr2jAyAAAAtCfey8SvnJEf5UgAdHaMNAI6iGKHubkWOThJIgAAAFr2lw3dlJtnVx2nQgBwjCgaAQAAAECErC2MU26ePSpX83rxW/N8pusOc55EAMeGohEAAADQSoodVv13V1K0w0A7smCbeVXEf0XxgjScEhPAseKcRgAAAOiybl+eoWkDqzXpOEerTG/am1mSpONTnRrRs65VpgkAQLQw0ggAAABdUmGNVZ8XJOh3KzNafdoHqzkHIQCg46NoBAAAgC6p1sUlywEACIWiEQAAAAAAAAJQNMIxm7M8Q7l5dhnt+Mx6D69JU26ePdphAAAAAADQ4VA0wjFbUZAgSSqpbb9ptHh3siSpoo7h5wAAAAAAHI32+2kfaEXuaAcAAAAAAEAHQ9EIAAAAAAAAASgaAQAAAAAAIABFIwBRcbiG3Q8AAAAAtGd8agPQ5lYditPFb2Xp5x/1jHYoAAAAAIAgKBoBaHNbiuMkSZs9twAAAACA9oeiEQAAAAAAAAJQNAIAAAAAAEAAikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAOi0al3SpiOx0Q4DADqkmEhN2O12a/78+dqzZ49iY2N1ww03KCsry/f6mjVrtHDhQlmtVk2aNEmTJ0+OVCiIMrdhkSQVVNvkdEsxlCoBAECEGIZU7bREOwxEiduQ9lbEaHNxrLYUx2lLcay2l8bKZZATAHAsIlY0Wr16terr6zVv3jxt27ZNL7zwgu644w5JktPp1PPPP6+HHnpICQkJuueeezR69Gilp6dHKpx2p6zWIpdhkSHz4Gb+mY9dRkO7zwsS1CfJpViboViroTirFGM1FGc1FGOVKuvNCszmI3HaUBQrQxYZhuSW2WlyG5Ihi748GN/svF2Gt53Fd9/ru/Lw0qOszozB3WS+De+twhPjioIETVzYRz0T3cpKcikryaneSS7f347Shm+AquotsniO7d5DvO9Qb2kI8u6V3ZUW51Zqo7+0eLdS4wylxrl97ZbnJygpxlC926J6t+Ty3Na7LXK6Lb7lWOKwqqjGvO+dS6NFopLahopXaa21Yd01et/ex42Xo81iyGqR56/x/YZ2y/ITlB7nls1qKNYqxXrWcYzVXPc1LnPemxqtay/DMOM0JK073HAZ+8Jqq9yy+OI0DDXJO6/yOosskiyWRsu5mcf7K2OUYDN878NikWyeNjaLoTq32fqdPUka0r1e8TZD8TYp3mbmrPnYUFmj5biv0iZro3mZt0bAvCvrzRz1LmP/+15ldVZZPMvCf9tye96/JFXUWVVSa5XTLTndFjkNMy+cbslpWLT5SMNyLK8z/8eXi3656VVUY212GzD8cmJnWYwvfpcnRpc78L2U1lp1uKZplbXxPL3bniFLyO218bouqTWXj8Wb2ZZmtjFJeypsQafX2BGHTQerbbJajCa54M2NWpc5VadhUWGN1VzWvm3PfN7ptqi6vmHuZXUWc/n51nOjbctv+Rhq2G9573u3Ba9d5THaURojt5ouc+801xWa67rWZW7/Zkzyxep9XFHXKG8rbJ71a/HN222oSTyStOpQnLkdWxq25xiL57bRqj1YbdPmw9Leojg5nBbVuCzmrdMih8uiV7anSJKqnVZV1Vt883F7Zm541mhlXcNy3Fwcq2KHVUU1Nh1x2FTksOpIjU1HHFYVORrWr3cbDLZdexXVWFVYY/UsY0ujY4wZy+Eac5oV9VZtKIpVWZ1VpbVWldbaVFprVZlnm9vTKFcPVNqa3S9aZTTZP+ZX2VTnsqjOLc+tRXUucz9e52poWFlvDbpvNjzzk6SSWpv2Vdh8+W9Rw/7YYpGKHQ0r55uSWNm8689iyOZ32/i9uDz7GKfbvHV58sfVaAdwuMamvRW2gNe9t95j4eEam3aUxagkVjpUEut7Ty5P3h6qbliHqw7FeZab+T4s3mWqhv2VN0bvcml83PduC15ltTYVO6xBj29FnuVT47SoqtG26ztueu6UN8rHw77caVgfjXPYa2dZjGwWyWY19yk2z77FZm2aj29/l6Rih03FteY6L/HeOqwqqbX5jkcHqmKUX2UL2Dd5l1FlXdN17e0b1Hvyy+k2862+0Tr032b8c9fri4J4pcY23vs3tbLA7JvVepZj4+NC42Pc/sqGdb35SKxirFJ5nFRcHuPbl3hz0muvZx/lWzffs2CypyJGXx+O8/RNzHnGevorMVZDpY2Wo/e45d+v8D+u++/rG/dRGh8L91XafPuKxuvQu/y9/cztZbG69dMe2locqypnQzyxVkMnda9XrcuiHWXm9tU4b/1ja/zKvkpbk3n53/d6Zks37SyLVZynvxNrk+Kthq//vsrTDy922LTfM01Lo+l487NxPn5yIMGzjBv6hQ23DQtor+d47SiRCv3We2OLdyWprNaqBJuh+BhDCTbPn+e+dzluLo7TykafG/xtLGroH/34vUz1THCrR4JLGQlu9UxwKyPBpR4JbvVIdPnavbcnUfGe+Xn7gvExDfe9DlTGaH+yy3wPjY/tntf3VMR41ktMwHJs2CabHq8fXZemxBhDiTFuJcUYSowxPLfmY/mmbZPLbfHtx12G5HI33PfKr7IpM0QfaV+lGWNJrXnM9E7T6bs1p7mpUT/Tm2fB9lNe35TENnscivHbP5Y4rCqsNvsz9W6pokjK9+zfnO6GPuO6wnh9fTjOM7/Azyr7Gu17wv1cuK4wzvPZRX63Tfs9j65L09isWqXEGkqJdZt/cYa6xbqVEtuQjyW11ibHZH+NP5t95dtHNfS3vPus2EaTqPTb/oN5bmuKTsusM/PHs60kxrh9j4s9falg21xnYjEMIyLv8/nnn9fgwYN15plnSpKuv/56Pf3005KkPXv26MUXX9Tdd98tSXruuec0dOhQ5ebmhpxmfn5+JEJtVXa7PWScuXn2Noym/TmtZ60OVdtUWGPjGx8AiII4q6EeCS4VVEfseyMgKuJtbnWPN/+2lsS1/A+QJJ3cvU5ZyS7Zk13qk+Q0b5Ndykp26uE16Xp/b1K0QzwqA7rV65SMep2aUadTMuo1OL1esVZpRUG85izvEe3wOpX0OJdK68L7kgnorBJsbi297GC0wzhq/nULuz14nSJiPcaamholJTUcZKxWq1wul2w2W8BriYmJqq6ubnGaod5IexJOnBecYH5rZvVWla1q8k3Vq5vNdtePkrrFSXUuqd5l3prftJqPX/+mYZo3jfZWpP2/bZTe2SFtOWy2O/+Ext/QBJ/3VcNCv4eXNpm3Z/aT0hMaV8QbYrBYpP9sMdtNGST98yLzmwuXWyqskg5USPmev4c+b5j2ucc3HT0gNX386R7z/uqfS6UOqcwhldZKJTXmrfe5Fzea7X41RuqeKMXZzJ/HxdqkOM9tjFW69o2GeV80JHAEifeb2rX50v4K8/4PBjddbv5/3uU4c5jnG2+3+Y2qy61G3xhL7+4w2911pvne6lzmtxD1nnXtvb9gk9+6lpqOEvHcf2p1w2iMS4aGjvGFDQ3rxn/EhneZG5KWftcwvVhbo/jd5uve9/TeTrPd4Azpp8PNcwg4nE3/al3m+iusMtv+6JSmI0R8I3M8j9/c1pATDd82N+Su9743z84/wVyn3m3Ll+Nqmo/xNumc4+X5BsSTF1YpxpMTeVuk8tqG5eO/XBo//mi3eXvxkOa3Ae9j7zq8ZnjDdmezNH1fNqv0py8aYjz/BAX1xraG+/7ba+PRBW6jYd4/GNywrL0av58lu8z7V7aw/TfOx0tPCswF79+Huxva/XCouYy9213j+zKkv6wx251/QsN+scm+yiJZrQ3b1gUn+I9Qa/ptsXf5jOgtnZbV/LRsFmn+V1J1vdn2oiEN+RDXKB9irea2OP8rs92PT22aY95l7n3uufXmc7eNlWfUkjzf8Jnbs/e517Y2LJ9Zp0lJMVJirJTk+UuMkZLjpD+vktYfMtude3zDfBuPevPe9+5TZo+UeiV7/pLM297JUmq8RRZLjAY80fBevPunUNu1Nx+9y9DiyXH57fMk6cZRUkaSlJFg7nszEqUeiVL3BPP9nfBns92MkwP3i43/PtjV0C7OJsXHmLdxNjOeOM/j+z5pmHfQfbOkvEbL+4pTG/Y5arz/kXkM8e73Zo8043M281fvlt7f2RBjjM3MqVjPbUyj/cv/+7LpvL3P2zz55b39YKe0pchs57+vaJy7VklPrDLbzclt2G96R9IZjZbjP9Z5Yjyl6Xbg3wf457qGGKed2PxxvfE2KEnnDAwcTeLNyVKHtMrTH714SNN+SePcsVqklxvtH81v9z3L3WhY/i6jYXmff4KZuz0SpR5J5m1SrFXe03X+/M2G/dmMkxuPWmy6nA5XS+sKGtZ1nNXMqVhbQ67F2cx185sPzXaNtxlv7ja3zYztK509UEE93KjfM/n4Zta11Ttis+FYeP0oyelqtD/xy0nv9j+z0T7c4n9raegfSdKu8jhtLWk+Ru/IgMwk6Yph5v6r3jP/endD33RTobSrtGFdS36jPxvdvtdoHTZ+v/5/3uN1/zTpDHvTdejND0MNOSFJG2+QUuNjJcVKalrsOj1J0nLz/rnHe2IM0tf8ZI95+6NTms6vce643A3HuLvOlE7qaS6LWm9/3dMHqnNJDy5viGPGKU37UY3f0/YjDcvx3okNfUHvcm78+JVG/Ux/jboAvuP1zGHm8bCmXqpxmn8Op/nY4Wx6PPrtuMBpeh2oaMif9TfaVO+SiqrNbelwlVRYbfbxDldL//b0Mx8+t2lfsKbx/fqG4/UpmdKpmU2PaY2P7Y37HjNOkW+Umv/yXLlfKvP04ZZcLVXVS1V15rG+sl6qrjOfq65v2DdfOczc5rx9SHMEX8Nz3r7ZDwZLacEHYvnWi2RuC42PA433+98WScv2mu1+1Mx7aZxr3hxv7nhk/oKi6fGod7I09riGfoy3v+W9/fOqhhhvHePZn3nz3GiI5bM9DfkY7ufCX5/RNE+d3s+tnsdvbTfbPXaedHy62dcur5Uq6hrdr22YnmQej4L5cJe5zXnfi9Pv81N9o9u3PfM+b1Do9+I9djx0jtl/qfbkabXnr6befO55T1/vnonWDlOn8Bdu3BErGiUmJqqmpsb32DAM2Ww232sOh8P3Wk1NjZKTk1ucZmcYafThJRbF2ZoOkWvOq5vNFTitz0FlJgYf2nxJvxjd/ElP5U09pLS44IPGLLVJ2nI4XZI0Nyf0cnx1s11JMW7dcnLoiunxiYn6aF+iHhtbHLJdZkyy/rIhTTMGHlZ+fn2T1+yS7N0kdZNqRybpT1+ZMT4wOnSMuXvsGtGzVs6yI0qRlGKR+iZISmja7sWN5nK89Lh8xYf4IuRHg1P1nx0pemJikcb0rgvecLg57DrUOvHyrsNfnhz6vfxuhPmTivT40NMc3T1et33WQ29fdFAZCcHb9ouN128+76GsJKd+O7ww5DRf2GDGeP+oFmJ0dtfS/Yn67fDQ7X49zKJFO5N1zUmVTX5a4u+2U82h4cmxLQ90fHObGWNLOXHVIKsKqmI0omeI9Sfpf05VWOfWOjMjVtd+lKmLj6/SXaPKQra9a4RFCTFNh6o3Z8nO3jpcY9ONQ0O/l8uPk7aXxmpo9/qQ7X6TLd21IkO/Oq1Mx6W4grYzDGnBJnM53jsy9LyX7DLb3dpC3n66u5cOVMVoXm6xzjnOEbTdpf3jdPOnPTV1QLXuHF4atF2tS/rLGnPeLe2jfjTApkPVNo3MDL2u7xoR8mUfR1WK/rE5VRnxLv1uxKGg7aqdFs3/qo8k6denhI5x26EMrTiYoBn9Qrd7batnPzGiTHPOSgt6/HjgdKsueitLf5pwRLlZtSGnee/IIC/USlW1kqdeq88ulxwui1Ja2A7f22nGeFN2mX50YlXQdu7aVOXtSFG3WLeuGeR3/HBLqpIqqqQKSStnhJylzweefLxtWOjleJ/MdneNLtXFxwf/EspVl6bXdyare7xLvzol+LqWpDvru+vc42p0Xv/g+S1JMwbG6kiNTRP7hm73wfae2lIcp3+fV6jB6c6g7X7cv+k+KlS/4ooBIWfp8491nuV4aujl2DcmUXNXddenl+UrLsQxc0LPON3yaU/9+rQy/ThETkjSK9uSNapXrU4M8Z4l6WXPPqql/WO/+BTN35Kq32QXmMcQt6RKqbRSKm3UzupMl5SkvslO3TYs9LHw5W3JOr1Xbcj1YjJjbGn7924zFxxXovPtNUHbpeYm6HcrM3TDsHL99OTKkNO8I7vpcStYXry7I7y+x+nd4/XE16l6ccphGTJ/kplfZVNBdYwKqmwqqLIpv8q8X1Vv0QNnFGt4z+DHpB2lMfrJkl6SpLtGhJ73vSPN1dbSMXNSrzjN39JNT511JGS7mpruWpafqBPT61V55LCCLclYSZedkKYp/Wta7Ct82T9etS5Li9v19IFxemFrii62h+4LDzs/Rle+30v/OvewTs4IfWy/4/PuuuyEao3tHXpf/4pfPzNYTniP/5N6HVZ2iHm7atO0aFeyzutXrUv6loac95jucTqpe73y8xuOHz0l9UyQTk6QlGE+d9PQkJPxecPT1/u/0w/Jnhy8PzMlK1Y/+zCzxeX4Vb843fRJT0lSSm2+UiTzU2+MpMSmbX/Uz7y1tJCPM/qFft3rlydLawrjNLpXXchp7utt07K9vSVJ/9PCvnnF3izFWg39fHDo41afuG56bms3vf6D/Cb9cP/cyEmN1awPM/XvKYUanBZ8v/eLE6Xxr9n1yxFlmjkk9L6+d0yyYm2GLukfeiDIW9vNdT047qB6yy17vKRminBf5ZvHzHFZDv3+tODb1zm9G0YQXjkg9HJ82zPv/23hc8/PBsdoRUGCzu4Rer98w5CG+x2gTBGgXYw0Gjp0qNauXatx48Zp27Zt6t+/v++1vn37qqCgQJWVlUpISNDWrVt18cUXRyqUdiWcD8lH48R0pz64pHWHw62cEV7WTxtYo2kDg3eGvK4eWqWrh4be0RytcGN866KD2lcRE7JgJEn/M7Jcvz6tvMUDhqSwCkZHI8aqFgtGkpSbVRvW+x5vr9WTE4t0WgsfqI/Gg7klkoJ8DdlIWpyhn7XQ8fUKd1u4b0yJ+ndrqSMv9Up0q1dieO85nJOxn5xRH3aehfte3rjwkGcHHbqd1aIWC0aS+T4eHR+6oyqZHaF/nHNYWUnBO2Je15xUoS9CnMvA66XzC7XqULwm2EN3anN61enz6fkhi4jS0Z0g3+75GUVrmTm0Up/lJ+jeMaWtNs0/Tmh5vRyNnonusPMxXDFWKcXausekaHn0zCP6zec99IMBLY9aDtfD41re50nSqRn1klreXp85t0i1LrV4PJJa/4IRyTHuJud4Ceb8ATU6f0DLx/VRverCzscrWvigcbRmn1qp2aeGd5wJV0sfhrw++GGB7zxtoVx0fJXe3J2sM1r40D/pOEfYyzHcnJh/7uGA8/U0Z0zvWr10vjkE3SJzH9Mz0a3hYeTy92WxSOH8oOm0zLoWC0aS9LOTK7UsP1G3DC9vse1vckJ/CeR1RgvFea8RPevC2t8fn+oMe10/cmZ4+54V0/PDOpfKX84u0r+/SVF2j9Dr9raRZRqcXq+LQhTevU4P9QXrMfjs8nwdqLK1eGwf2j28vll2DzO+GYNb3leE0/c/GhZLeMunX4pLT04s0iktFBElhf1Z7/phFbp+WEWL7U4KcznaLOF/5prRwhcIXksuKdC20lj1Tgr92eem7HLd8mlPXXtKy+8nXMMy6tQtruXPXIPSnBqU1rrHmY4uYkWjMWPGaMOGDfr9738vwzB00003afny5XI4HJo8ebKuueYazZs3T263W5MmTVJGRkakQkEH0d1TOLG04unEeiS41SMhvANbax80oqm1D+bRdEEYH2DQspY6i143ZlfoxuyWD9DxNrVYMPJqqWAkmR2Tdy8+qJQQJ42NlASb9K/JRW0+X7Qs3M7qeHt4RfVoC6dgFAkfXtrxzrXQHnWLM9QtjD7K70aX6XejwytOtLZTw/gAGgnHeb7cGZTa9vM/mi95OhP/E4sHk5NZp5zMlgtbMVbpshNar/B+NGKs0oBurfdlUIw1/ONHNHWm/nq4UmIN5YTxxfbRfDkRrn+eS1/vWEWsaGS1WnXdddc1ea5v376++6NHj9bo0aMjNXt0QOce59CXA6taHKLdUSyfnq/j7HYVFEQ7kuCm9K/WsCh1MAF/4Yy4AwC0Pwm2jvEhHQBw9Lh0CtoNi0W6+/TofDMXCd4TiLZn959RGu0QAADQoNR67SqPjXYYAADATyv/ah7tlfc3wgk2vskHgPbilyPMQvn5/fkZJrq2l84/zEgVAADaIUYatXNxrXSS0rFZtbrn9BJNsIe+CgQAoO3MHFIV9kl4AQAA0OBUz0nPx2bxGTeSKBq1U/83tlgf70tUWnzrnRR6ahhXOgMAAAAAoL1LizMYpdoG+HlaOzW5n0MPhnm5XwBA5MVYOsfl6Y9W93jz5839PVdHCmaK5yd2V5/UOS5mAAAAAEYaAQAQljib9PvTS3Riete64uDr0w7pq8J4jc2qDdluWI/2f9nrGM9PvmP4ygwAACAsdJsAAAjTtIE1GpIeesRNZ5Ngk3L7hC4YdRQ/9YyCemBscZQjQaRN7meOfLt4UHWUIwEAoGNjpBEAAOgSMhLc7X40FFrHeHst6xoAgFbASCMAAAAAAAAEoGgEAAAAAACAABSNAAAAAAAAEICiEQAAAAAAAAJQNAIAAAAAAEAAikYAAAAAAAAIQNEIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAAIAAFI0AAAAAAAAQwGIYhhHtIAAAAAAAANC+MNIIAAAAAAAAASgaAQAAAAAAIABFIwAAAAAAAASgaAQAAAAAAIAAFI0AAAAAAAAQgKIRAAAAAAAAAlA0AgAAAAAAQACKRgAAAAAAAAhA0egoGYYhp9MZ7TDQTrjdbpWWlvruAy6XSx988IH27t0b7VDQzrjdbtXV1UU7DLRD9C3gj/4F/NG/QDD0L9Cc1uxbUDQKk2EYqqio0DPPPMPOGpKk2tpaPf/888rLy5MkWa1sTl3dihUrdO+99+rFF19UZmZmtMNBO/Lhhx/q8ccf14IFC1RYWCjDMKIdEtoB+hZoDv0L+KN/gWDoX8BfJPoWHIVa4N3wLBaLCgsLtXLlSm3ZskWVlZVRjgzR0HhHbLPZdOjQIRUWFmrNmjWS+DawK3K73XI4HHr44Ye1evVq3XjjjcrNzVVVVVW0Q0M7sX//fq1evVpXXXWVUlJStGTJEq1fv16S6Nx1UfQt4I/+BfzRv0BL6F+gsUj2LSgahVBRUaHa2lrf42+++UZnnnmmDhw4wDeCXZB/PhQVFalbt2666KKLtHbtWpWVlfHzgi6moqJCDodDCQkJuvrqq/WrX/1K3bt315EjR5SRkRHt8BBF1dXVcjgckqQtW7aoR48eysrK0pQpU9S7d29t2bJFFRUVslgsUY4UbY2+BfzRv4A/+hcIhv4FmhPpvgVFoyDeeustPfTQQ3r11Vf1xhtvSJKys7N17bXXKjMzUxs3btSRI0eiHCXaSuN8WLx4sSQpJiZGJ510kvr166fvvvtOjz32mIqLi6nsdxHenPjPf/6jxYsX67jjjpMkJScnKyEhQdu2bYtyhIimV155Re+9954kadSoUdq6dasKCwuVmpqqgQMHSpIOHToUxQgRDfQt4I/+BfzRv0Ao9C/gry36FhSNmlFQUKD169frjjvu0LRp07R+/XotXbpU/fv3lySdddZZOnLkiHbv3s03P12Afz5s3LhRy5cv18GDB7V06VL985//VPfu3ZWamqqUlBQq+11A45y48MILtXHjRn300UeSzEp/nz59lJCQEOUoES1btmzRpk2btH37du3du1c9evTQmDFjtHDhQknS4MGDdfDgQd/xgw+CXQN9C/ijfwF/9C8QCv0L+GurvgVFo2aUlZWpX79+io+PV8+ePTVjxgy9/vrrcrlckqQePXpo8ODBWrVqlUpKSqIcLSLNPx+mT5+uvLw81dXV6fjjj9dll12mOXPmqG/fvlqxYkW0w0UbaC4n/vvf/8rlcqlbt26qqqrS119/LYnzUHRFRUVFOuecc5STk6OPP/5YknTJJZdox44d+uKLL1RYWKi6ujpfbvBBsGugbwF/9C/gj/4FQqF/AX9t1begaNSIdwNLSUnRoUOHVFJSIsMwdNJJJ2no0KF6//33fW0nTZqkc889lysYdGKh8uHkk0/W7t27NXv2bA0ePFgWi0VTp07VlClTohw1IqmlfcS7774rSTr33HP1+eefy+12c9WbLsSbH2PHjtWZZ56pQYMGqby8XF9//bUSExN19dVXa+fOnXriiSc0duxYnXLKKVGOGG2BvgX80b+AP/oXCIX+BRprPIKsrfoWFqMLj1t7//33ZbFYNGTIEA0cONC3QVqtVr344ouKi4vTBRdcoNTUVC1dulQxMTGaMGECO+pO6ljzweVyyWazRTl6RMKx5oQk9hOdXHO54b++HQ6HVq5cqa1bt+qGG27wvU5udG7ec00MGzZMxx13HH0LHHNO0L/ovI41JySOIZ1dc7lB/wKbN29WYWGhJk2aJMMwZBiGLBaLLBZLm/QtumRWVVdX65FHHtHu3buVkpKiV155RevWrZPVapXVatWuXbtkt9t1+PBhffDBB/r888+1ZMkSJScnSxIbYyfzffOBDl3n831zQmI/0VmFyg3JPN/A2rVrJUkJCQk66aST5Ha7tWnTJt80yI3OxzAM1dTU6PHHH9d3330nq9Wql19+WV9//TV9iy6qNXKC/kXn0ho5IbGv6Ixayg2J/kVX98UXX+jLL79UaWmpLBaLrFarLBZLm/UtYlplKh2M0+lUcnKyrr76aqWkpMjpdOrVV1/VyJEj9dxzz+m7777TrbfeqlNOOUXbtm3T2rVrdeWVV2rYsGHRDh0RQD7AHzmBYFrKjb1792rWrFm+9r169dI111yj1NTUKEaNSKqpqVFiYqJiY2OVnJysH//4x0pLS1Nqaqr+/e9/67TTTtNzzz2n3bt3s9/oIsgJ+CMnEEy4ubFnzx76F12INy8kaf369dq7d68GDBig9957T1dccYXq6ur0wgsv6MCBA7r55psjvs/oMkWjJUuWSJLOO+88FRUVqbq6WuXl5UpJSVGvXr1ksVi0dOlSXXTRRerZs6fv/7KysjRx4sRohY0IIR/gj5xAMMeaG5I5UoAOXedUV1enBQsWqLi4WCeffLJOPvlkOZ1OlZeXq1u3bho7dqw++eQTvfXWW7r44ouVkZHh+1/2G50TOQF/5ASC+T65IdG/6Ky8eVFSUqLBgwfrwgsv1PHHH68LL7xQffr00WuvvaYdO3Zo8ODBOvvsszV48GDf/0Zyn9FlxrBt2bJF//3vf1VbW6tBgwapd+/eeuONN/TCCy/o448/1llnnaX9+/f7OvxckaBzIx/gj5xAMOQG/NXW1urFF19UUlKSrrzySi1btsw3Cm316tW+y9r+4Ac/0IEDB3ydfXKj8yIn4I+cQDDkBprTOC9mzpypFStWaOPGjUpNTdXpp5+uzMxMDRkyRMuWLZMkX8GoLfKi0xaNSktLfff37dunpKQk2e12vfTSS5Kk6dOn67LLLlNqaqquuuoqpaenq1+/fr7/4TehnQv5AH/kBIIhNxCMNzcMw9COHTt09tlnKysrS6eeeqp27typiy66SNu2bdOGDRskSYcOHVKfPn18/09udD7kBPyREwiG3EBzguXF8OHDtWPHDl+7+Ph4DR8+XOXl5Vq+fLnv+bbIi07387QjR44oLy9PZWVlGjVqlEaMGKEePXpo2rRpysjI0O23367zzz9fffv2VU1NjTIyMvTss8+qoqJCP/7xj6MdPloZ+QB/5ASCITcQjH9uZGdn65e//KV69OghSaqsrNSwYcOUkZGhiRMn6ptvvtEHH3wgl8ulyy+/PMrRIxLICfgjJxAMuYHmtJQXZWVlGjduXJP/6dWrl8aPHx/wc8VIsxiGYbTpHCNs4cKFcjqdmjRpkpYtW6by8nJdeeWVSkhIkCS99tpr+u6773T77bfL7XartLRUW7Zs0fjx46McOSKBfIA/cgLBkBsIxj83ysrKNHPmTCUlJWnv3r16/vnndeeddyo2NlZFRUXKyMjQ1q1bdeqpp0Y7dEQIOQF/5ASCITfQnHDy4q677pJkjkbyP29mW+oURaOlS5dq8+bNysrKUmFhoS6//HL17t1bBw8e1IcffqiMjAxNnTrV1/7666/X7NmzNWbMmChGjUghH+CPnEAw5AaCaSk30tPTdeGFF2rVqlU6cOCABgwYoNdff11Tp04N+GYQnQM5AX/kBIIhN9CcY82LCy+8UGPHjo1a3B3+h5EvvfSSvvrqK02dOlXfffedPv30U9+VbjIyMpSdna3Dhw+rsrLS9z+33HKL7HZ7tEJGBJEP8EdOIBhyA8GEkxtFRUWSpDVr1ug///mP1qxZo1mzZtHZ76TICfgjJxAMuYHmfJ+8iGbBSOoE5zSqrq7W5MmTNWjQIF1wwQXKyMjQ559/rvHjx2vgwIFKS0tTfX29EhISZBiGLBaLsrOzox02IoR8gD9yAsGQGwgmnNyoq6tTXV2dTj75ZI0YMUJnnnlmtMNGBJET8EdOIBhyA83pyHnRoYtGbrdbZ5xxhk488URJ0ooVKzR69Gj1799fzz77rK6//npt2LBBFRUVcrvdionp0G8XLSAf4I+cQDDkBoIJNzcqKytltVo1adKkKEeMSCMn4I+cQDDkBprT0fOiQ/eCrVarhg8fLsms3O3evVs/+tGPlJOTo/Lycn344YcqLS3VrFmzFBcXF+VoEWnkA/yREwiG3EAw4ebGtddeSzGxiyAn4I+cQDDkBprT0fOi/UV0jIqLi5Wdna3q6mr961//Uv/+/XXllVe2y4WOyCMf4I+cQDDkBoIhN+CPnIA/cgLBkBtoTkfMi/Yb2VHaunWrFi9erN27d2vixImaMGFCtENCFJEP8EdOIBhyA8GQG/BHTsAfOYFgyA00pyPmhcUwDCPaQbSGpUuXqqSkRBdffHG7rtKhbZAP8EdOIBhyA8GQG/BHTsAfOYFgyA00pyPmRacpGnmvbANI5AMCkRMIhtxAMOQG/JET8EdOIBhyA83piHnRaYpGAAAAAAAAaD3WaAcAAAAAAACA9oeiEQAAAAAAAAJQNAIAAAAAAEAAikYAAADH4IsvvtDcuXNDtnnttde0evXqtgkIAACglVE0AgAAiJBNmzbJ5XJFOwwAAIBjEhPtAAAAADqKV199VcuXL1dKSor69OkjScrPz9czzzwjh8OhkpISDRw4UL/+9a/18ccfa+fOnfr3v/8tq9WqnJwcvfjii9q6davcbrcGDhyoWbNmKSkpKcrvCgAAoHkWwzCMaAcBAADQ3q1evVovv/yy5s2bp7i4OD366KNyOBw64YQTNGDAAE2cOFFOp1N33nmnpk+frrFjx2ru3Lm64IILNHbsWL322muqqanR1VdfLYvFogULFqi6ulo///nPo/3WAAAAmsVIIwAAgDBs3LhRY8aMUWJioiRp0qRJevfdd3XVVVdpw4YNWrx4sQoKClRSUiKHwxHw/2vXrlV1dbU2bNggSXI6nUpLS2vT9wAAAHA0KBoBAAAcA5vNJkl64okn5HK5NG7cOOXk5KioqKjZ9m63Wz/72c80cuRISZLD4VBdXV2bxQsAAHC0OBE2AABAGE477TStXLlSVVVVcrvdWrZsmSRp/fr1mj59usaNGydJ2r59u9xutySzsOR0OiVJI0aM0HvvvSen0ym3262///3vWrBgQXTeDAAAQBg4pxEAAECY/vvf/+qjjz5SSkqKBgwYoIMHDyo3N1dvvvmm4uPjlZSUpJSUFPXr109XXnml3nnnHb399tuaMWOGxo0bpxdeeEFbtmzxnQj7uuuu40TYAACg3aJoBAAAAAAAgAD8PA0AAAAAAAABKBoBAAAAAAAgAEUjAAAAAAAABKBoBAAAAAAAgAAUjQAAAAAAABCAohEAAAAAAAACUDQCAAAAAABAAIpGAAAAAAAACPD/ATo1R+goHnhNAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<Figure size 1440x432 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.style.use('ggplot')\n",
    "plt.title('Revenue per week')\n",
    "\n",
    "plt.ylabel('units')\n",
    "plt.xlabel('date');\n",
    "\n",
    "df2b['monetary'].plot(figsize=(20,6), c='dodgerblue');"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "metadata": {
    "id": "3tOL1QQc8MjN"
   },
   "outputs": [],
   "source": [
    "# For greater visibility in the plots we convert the dates to monthly periods\n",
    "# and we aggregate the units and revenue of the same period\n",
    "\n",
    "df2c = df2b.to_period(\"M\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 235
    },
    "id": "0iusXD4l89aJ",
    "outputId": "2d0a834f-9661-4bdc-e133-7068cfeeac1d"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>date</th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "      <th></th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>2019-01</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>808.08</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-02</th>\n",
       "      <td>KR</td>\n",
       "      <td>702234</td>\n",
       "      <td>1606.80</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-02</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-03</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2019-03</th>\n",
       "      <td>KR</td>\n",
       "      <td>3618438</td>\n",
       "      <td>803.40</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "        country       id  monetary  units\n",
       "date                                     \n",
       "2019-01      KR   702234    808.08      1\n",
       "2019-02      KR   702234   1606.80      2\n",
       "2019-02      KR  3618438    803.40      1\n",
       "2019-03      KR  3618438    803.40      1\n",
       "2019-03      KR  3618438    803.40      1"
      ]
     },
     "execution_count": 25,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df2c.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 26,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 364
    },
    "id": "dF4zRcSqBLYR",
    "outputId": "43177a46-74fa-4fc7-b39a-a377054d9bc8"
   },
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAABKEAAAGNCAYAAADJkWLNAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMSwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy/YYfK9AAAACXBIWXMAAAsTAAALEwEAmpwYAACZT0lEQVR4nOzdeXicdbn/8ffsW/akTZombZPuW9qyU7YuiKxFkSJ49LBUPGpV+Ikiq4DIpoIeEFHwAB5Fj9SiLSBbNwplp6VturfplqRpmn2Zfeb5/ZGFFrqkbSaz5PO6Lq6UyWTmO0lm8jyfue/7azIMw0BERERERERERCSGzPFegIiIiIiIiIiIpD6FUCIiIiIiIiIiEnMKoUREREREREREJOYUQomIiIiIiIiISMwphBIRERERERERkZhTCCUiIiIiIiIiIjGnEEpEREQS2owZM/jLX/7yucsrKysZPXo0mzdv7tHt3HLLLfzgBz8AwDAMnn/+eQKBQK+u9Ujef/99Ro8eTXt7+0E/v3nzZkaPHk1lZWWfriueKisrWbRoUff/H+rnLSIiIslPIZSIiIj0C7fffjs///nPAfjwww+58847CYfDcV6V3HrrrXz88cfxXoaIiIj0AWu8FyAiIiLSF9LT07v/bRhGHFciIiIi0j+pEkpERERSwi233MLdd9/NrbfeypQpU5gxYwa/+93vDvj8D37wAyorK/nP//xPAE444QReeOEF2trauOmmmzj11FOZPHkyc+bMYceOHQe9n3A4zL333ssZZ5xBWVkZV111FWvWrOn+/I4dO/jOd77DySefzKmnnsodd9xBW1vbQW+roaGB733ve0yZMoXzzjuPDz/88LCPccaMGTzzzDN89atfpaysjK9+9ausW7eu+/OhUIhf/epXnHHGGZx44onMmTOHioqKA77+F7/4BdOmTeOcc86hubn5c/cxevRoXn75ZWbNmsXEiRO56qqrqKys5J577uGEE07g7LPP5l//+lf39VtbW7n33ns566yzmDRp0kHv809/+hPf+MY3mDRpEpdccglLlizp/pl88MEHPP3008yYMaP7a3bt2sXVV1/NxIkTOffcc3nllVcO+30RERGR5KAQSkRERFLGP/7xD/Lz85k/fz6XX345//3f/015efkB1xk0aBCPPfYYAIsWLeLCCy/kN7/5DZWVlfzv//4vL7zwAmazmdtuu+2g9/GXv/yFt956iyeeeIKXX36ZYcOG8YMf/ADDMGhqauJrX/saNpuN5557jscee4yPP/74kLd1ww03UFdXx1//+lfuvvtu/vjHPx7xMf73f/83s2bN4p///CclJSVcd911NDU1AfDoo4/y5ptv8utf/5rnn3+ekpISvvGNb9Da2tr99fPmzePRRx/lt7/9LZmZmQe9j4cffpjbbruN559/nj179nDZZZeRlpbGP/7xD8477zzuuuuu7rlWP/jBD3j//fd55JFHeP7553E4HMyZMwefz9d9e48++ihXXnkl8+fPZ9iwYdx6660Eg0Fuv/12pkyZwlVXXcU//vGP7us///zzXH755bz88stMnTqVm2+++ZBBnoiIiCQPhVAiIiKSMoqLi7nxxhspLS3lu9/9LllZWQdUCgFYLJbu8CUnJwen00lVVRUej4eioiJKS0v5+c9/zo9+9KOD3kdlZSVOp5OioiKKi4u59dZbefDBB4lGo7z00ktEo1F+8YtfMGrUKE455RQefPBBXnvtNbZv337A7Wzbto0PPviAe++9l7FjxzJ16tRD3uf+LrzwQv7jP/6D4cOH87Of/Qyr1cq///1v/H4/zz77LHfffTennHIKw4cP54477iAtLY0FCxZ0f/0FF1xAWVkZEydOPOR9fO1rX+O0005j7NixTJs2DbfbzQ9/+ENKS0u55ppr8Pv9VFZWsnnzZt555x0eeOABTj75ZEaPHs2vfvUrvF4vL774YvftXXTRRVx00UWMGDGCuXPn0tTURFVVFenp6dhsNlwuFzk5Od3Xv/zyy7nkkksYMmQI3/3udwkGgwdUV4mIiEhy0kwoERERSWhWq5VoNPq5y7vmOlmtnx7ODB069IDreDyeHg0f/6//+i/+67/+i9NPP52TTz6Zc889l0svvfSg1/3617/OkiVLOOuss7rb/r785S9jsVjYsmULY8eOxel0dl9/4sSJ2Gw2tm3bdsBcqs2bN2O32xk5cmT3ZWVlZUdc60knndT9b7vdzujRo9myZQu7du0iGAwyZ84cTCZT93UCgcABAdiQIUOOeB/7fx9dLheDBw/uvk2HwwFAMBhk9+7d2Gw2JkyY0H19t9vNuHHj2LJlS/dlJSUl3f9OS0sDOOzPpbi4uPvfXd8zv99/xHWLiIhIYlMIJSIiIgktIyPjgHayLl3zjDIyMrovs9vtn7teT4aQT548mcWLF7N06VKWL1/Or3/9a/7617/yj3/8ozt06TJs2DBeffVVli9fzptvvsnTTz/N//7v/zJv3rwDwqfPOliQ1rW+roDHZrMdca0Wi+Vzt2uxWIhEIgA8/fTT5ObmHnCdruAHOOwau+wf7AGYzQcvnv/s96aLYRgHfN8P9rgO93P57GM80vVFREQkOagdT0RERBLauHHjWLVq1ecuX7VqFQMGDCAvL++ob3P/SiGAP/zhD6xZs4ZLLrmEX/7yl/z9739n8+bNbNq06XNf+/zzz7No0SLOPfdc7r33Xl577TXq6ur48MMPGT58OBs3bjygaqe8vJxQKERpaekBtzN69GiCwSAbNmzovuyzrYMHs379+u5/BwIBNm3axOjRoxkyZAhWq5WGhgaGDh3K0KFDGTJkCI899tgBg9N70/DhwwmFQgfM3fL5fGzcuPGA6icRERERUAglIiIiCe5rX/sa7733Hr/4xS/Ytm0bFRUVzJs3j8cee4zrr7/+mG7T7XYDHaFPe3s7NTU1/PznP2flypXs3r2bf/7zn6SlpTFs2LDPfW1LSwv33XcfK1asoLKykn/9619Eo1HGjh3LJZdcgsPh4Oabb2bz5s189NFH3H777UydOpURI0YccDulpaWcc8453H777axZs4aPPvqIX/7yl0dc+9///ndefPFFtm3bxp133onVauWCCy7A4/Fw1VVXcd999/Hmm2+yc+dOfvazn7F48WKGDx9+TN+nIxk2bBjnnXcet912Gx999BGbN2/mJz/5CRaLhYsuuqhHt+HxeNi5cyd79+6NyRpFREQkcagdT0RERBLamDFjePbZZ/ntb3/LvHnzCAaDDB06lB//+MfMnj37mG5z1KhRTJ8+neuuu46bbrqJH//4x9x///1873vfo7W1lbFjx/Lkk08e0OrX5dprr6WhoYFbb72VhoYGSkpKePTRR7srf/74xz9y//33c/nll+N2u/niF7/Ij3/844Ou45FHHuHuu+/m6quvJiMjg29961v87Gc/O+zaL7/8cp555hm2bdvG5MmTefbZZ7vb7W6++WasViu33XYbbW1tjBkzhqeeeqpHc6CO1f33388DDzzAd77zHcLhMCeffDJ/+ctfyMrK6tHXX3XVVfzkJz9h1qxZvPvuuzFbp4iIiMSfyVCDvYiIiEhSmDFjBtdddx1f//rX470UERERkaOmdjwREREREREREYk5hVAiIiIiIiIiIhJzascTEREREREREZGYUyWUiIiIiIiIiIjEnEIoERERERERERGJOWu8FxBP1dXV8V6CiIiISL9SWFioYzAREZEUVlhYeMjPqRJKRERERERERERiTiGUiIiIiIiIiIjEXEza8cLhME888QT79u0jFArxla98hby8PJ5++mnMZjM2m425c+eSlZXF008/zaZNm3C5XADcfPPNWK1WHn30UVpaWnC5XMydO5eMjAw2b97Ms88+i8VioaysjNmzZwMwb948Vq5cicVi4ZprrmHEiBGxeFgiIiIiIiIiInKMYhJCvfXWW6Snp/P973+f1tZWbr75ZgYOHMh1113HsGHDeOONN1iwYAFXX30127dv5/bbbycjI6P761966SWGDBnCFVdcwYoVK5g/fz7XXnstTz31FDfddBP5+fk8+OCDVFRUALB+/Xruv/9+6uvrefjhh3nggQdi8bBEREREREREROQYxSSEOv300znttNO6/99isXDjjTeSnZ0NQCQSwWazEY1Gqamp4cknn6S5uZnp06czY8YMNm7cyKxZswCYMmUK8+fPx+v1Eg6HKSgoAGDSpEmUl5djtVqZNGkSJpOJvLw8IpEILS0tB4RaIiIiIiIiIiISXzEJoZxOJwA+n49HHnmEK6+8sjuA2rRpE6+99hr33HMPgUCA888/n4svvphoNMo999zD8OHD8fl8uN3u7tvyer34fL7ulr2uy2tra7HZbKSnp3df7nK58Hq9PQqhDjexXURERERiQ8dgIiIi/VNMQiiAuro6fvWrX3Heeedx5plnAvDOO+/wwgsvcMstt5CRkUE0GuXCCy/E4XAAMGHCBHbu3InL5cLv9wPg9/vxeDy4XC58Pl/37fv9ftxuN1ar9YDL9w+wjkTbA4uIiIj0rcLCQh2DiYiIpLDDvdkUk93xmpqauO+++/iP//gPZsyYAcDy5ct59dVXufvuu8nPzwc6QqCf/vSnRKNRwuEwGzdupKSkhNGjR7Ny5UoAVq1axZgxY7oDp5qaGgzDYPXq1YwdO5YxY8awevVqotEodXV1GIahVjwRERERERERkQRjMgzD6O0bfeaZZ3jnnXcYPHgwANFolN27d5OXl4fH4wFg3LhxXHHFFSxYsID33nsPi8XC2WefzXnnnUcgEODxxx+nsbERq9XKDTfcQFZWFps3b+ZPf/oT0WiUsrIyrrrqKgCef/55PvnkEwzD4Oqrr2bMmDE9WqfehRMRERHpW6qEEhERSW2Hq4SKSQiVLHQAJCIiItK3FEKJiIiktj5vxxMREREREREREdmfQigREREREREREYk5hVAiIiIiIiIiInGytNLJPR9kEYrGeyWxpxBKRERERERERCRO/ro5jVd3uvlgryPeS4k5hVAiIiIiIiIiInEQjMCmRhsAi3a74rya2FMIJSIiIiIiIiISB5ubbISiJgCWVzkJROK8oBhTCCUiIiIiIiIiEgdr6+0AFHrCeMNm3qtxxnlFsaUQSkREREREREQkDso7Q6jvTmwBYPFuhVAiIiIiIiIiItLLyuvtZDsizCjyM9gT5u1qJ/6wKd7LihmFUCIiIiIiIiIifazWa6bWZ2FibhCTCWYW+/BFzLxTk7q75CmEEhERERERERHpY+UNHa1443NDAJxb7ANSe5c8hVAiIiIiIiIiIn2sax7UhNwgACMywwxJD/HOHgfeFG3JUwglIiIiIiIiItLH1tbbsZgMxmZ3VEKZTHBusZ9AxMzb1ak5oFwhlIiIiIiIiIhIHwpGYFOjjRGZIVxWo/vyrpa8VN0lTyGUiIiIiIiIiEgf2txkIxQ1MaFzHlSXkowwpRkh3q1x0hZKvZY8hVAiIiIiIiIiIn1obec8qImd86D2d26xj1DUxPKq1KuGUgglIiIiIiIiItKHuoaSjz9ICDWzuyUv9XbJUwglIiIiIiIiItKH1tXbyHZEGOyJfO5zQ9IjjMwK8f5eBy3B1GrJUwglIiIiIiIiItJHan1m9vqsTMgNYjpExnRusY+IYeLNFGvJUwglIiIiIiIiItJHulrxPjuUfH8zi1KzJU8hlIiIiIiIiIhIH/k0hPr8PKgug9MijM0O8lGtg8ZA6kQ3qfNIREREREREREQS3Np6OxaTwdjsQ1dCwactecsqU6clTyGUiIiIiIiIiEgfCEZgU6ONEZkhXFbjsNdNxV3yFEKJiIiIiIiIiPSBzU02QlET4w8zD6pLvjvKxNwgq/bZqfenRnyTGo9CRERERERERCTBdc2DmniYeVD7O7fYRxQTS1KkJU8hlIiIiIiIiIhIH+jJUPL9TS/yYcJgSYq05CmEEhERERERERHpA+X1NrIdEQZ7Ij26/gBXlEl5QVbX2an1JX+Ek/yPQEREREREREQkwdX6zOz1WZmQG8Rk6vnXnVvsw8CUEtVQCqFERERERERERGLs01a8Iw8l39/0Ij9mjJTYJU8hlIiIiIiIiIhIjB3tPKguOc4oJwwMUt5gZ0+7JRZL6zMKoUREREREREREYqy83o7FZDA2++gqoaCjJQ9gcZLvkmeNxY2Gw2GeeOIJ9u3bRygU4itf+QpFRUU8/vjjmEwmiouLmTNnDmazmUWLFrFo0SIsFguXXXYZJ554IsFgkEcffZSWlhZcLhdz584lIyODzZs38+yzz2KxWCgrK2P27NkAzJs3j5UrV2KxWLjmmmsYMWJELB6WiIiIiIiIiMhRC0VhU6ON4ZkhXFbjqL9+2mAfv1yZyeLdLr4+uj0GK+wbMQmh3nrrLdLT0/n+979Pa2srN998M8OGDePKK69k/PjxPPnkk3z00UeMGjWKV155hQcffJBQKMSdd95JWVkZr7/+OkOGDOGKK65gxYoVzJ8/n2uvvZannnqKm266ifz8fB588EEqKioAWL9+Pffffz/19fU8/PDDPPDAA7F4WCIiIiIiIiIiR21zo41g1HTU86C6ZDoMTs4P8F6Nk91tForTera7XqKJSTve6aefzle/+tXu/7dYLFRUVDBu3DgApkyZwpo1a9i6dSujR4/GZrPhdrspKChg586dbNy4kcmTJ3dfd+3atXi9XsLhMAUFBZhMJiZNmkR5eTkbN25k0qRJmEwm8vLyiEQitLS0xOJhiYiIiIiIiIgctbWd86AmHuU8qP11t+Ql8YDymFRCOZ0dPYo+n49HHnmEK6+8kj//+c+YOvcgdLlceL1evF4vbre7++u6Lvf5fN2XO53O7stcLtcB91FbW4vNZiM9Pf1zt5GRkXHEdRYWFvbK4xURERGRntMxmIiI9DfbPun4OHNsNoVZ2cd0G1fkwEMfw1s1Gdw288iZRyKKSQgFUFdXx69+9SvOO+88zjzzTP7yl790f87n8+HxeHC73fj9/s9d7nK5ui/3+/3dl/l8vu7r+v1+3G43Vqv1gMv3D7COpLq6+ngfpoiIiIgchcLCQh2DiYhIv/Nh5UCyHSas7Xup9h777ZySn8OKPU7e3bSXoemJ2ZJ3uDebYtKO19TUxH333cd//Md/MGPGDACGDRvGunXrAFi1ahVjx45lxIgRbNiwgWAwiNfrpaqqiuLiYkaPHs3KlSu7rztmzJjuwKmmpgbDMFi9ejVjx45lzJgxrF69mmg0Sl1dHYZh9KgKSkREREREREQk1mp9Zvb6rEzIDdLZIHbMulryFiVpS15MKqH++c9/0tbWxvz585k/fz4A11xzDc888wzhcJjBgwdz2mmnYTabueCCC7jrrruIRqNceeWV2O12zjvvPB5//HHuvPNOrFYrN9xwAwDXX389jz32GNFolLKyMkaOHAnAmDFjuOOOOzAMgzlz5sTiIYmIiIiIiIiIHLV1nfOgxucc21Dy/Z1V6MduNli828WccW3HfXt9zWQYxtHvDZgiVAouIiIi0rfUjiciIv3No6sz+NvmNB4/p44TBh77YPIut7yTzZtVLv5yXi3DM8O9sMLe1efteCIiIiIiIiIiAuX1diwmg7G9UAkFyd2SpxBKRERERERERCQGQlHY1GhjeGYIl7V3GtHOGBTAaYmyeLeLZOttUwglIiIiIiIiIhIDmxttBKMmJuT2ThUUgMtqcMagALvbrGxuismo75hRCCUiIiIiIiIiEgNrO4eST8w9/llQ+5vZ2ZK3uDK5WvIUQomIiIiIiIiIxEB51854vRxCnT7Ij9uafC15CqFERERERERERGJgXYONLHuEIk+kV2/XaYEzC/1Ut1vZ0Gjr1duOJYVQIiIiIiIiIiK9bJ/PTI3XyoTcECZT799+Mu6SpxBKRERERERERKSXdbXiTejlVrwup+YHSLNFWbLbSTRJWvIUQomIiIiIiIiI9LJYDSXvYrfA2YV+9vqslNcnR0ueQigRERERERERkV5WXm/HYjIYmxOK2X10teQtTpKWPIVQIiIiIiIiIiK9KBSFTY02hmeGcFlj1yt3cn6ADHuUJZUuIknQkqcQSkRERERERESkF21utBGMmpiQG7sqKACrGaYN9lHnt7C6zh7T++oNCqFERERERERERHpReUNsh5Lvb2axH0iOljyFUCIiIiIiIiIivSjWO+Pt74QBAbIdEZZWOglHY353x0UhlIiIiIiIiIhILyqvt5Flj1DkicT8vjpa8vw0Biys2pfYLXkKoUREREREREREesk+n5kar5UJuSFMpr65z2TZJU8hlIiIiIiIiIhIL+nLVrwukwYEyXVGWFrlSuiWPIVQIiIiIiIiIiK9ZG1nCDWxD0MoiwlmFPloCZr5sNbRZ/d7tBRCiYiIiIiIiIj0knX1NswYjMkJ9en9JsMueQqhRERERERERER6QSgKGxvtDM8K47YafXrfE3ODDHRFeLPKSTD289CPiUIoEREREREREZFesLnJRjBq6tNWvC7mzpa8tpCZD/YmZkueQigRERERERERkV4Qj6Hk+0v0XfIUQomIiIiIiIiI9IJ4h1DjckIMcodZXu0kkIAteQqhRERERERERER6QXm9jSx7hCJPfBIgkwlmFvvwhs28W+OMyxoORyGUiIiIiIiIiMhx2uczU+O1MiE3hMkUv3Wcm8C75CmEEhERERERERE5Tus6W/HGx6kVr8uorBBFaWHernbgC8cxDTsIhVAiIiIiIiIiIsdpbWcIFY+d8fZnMnUMKPdHzKzYk1i75CmEEhERERERERE5TuX1NswYjM0JxXspzEzQXfIUQomIiIiIiIiIHIdQFDY22hmeFcZtNeK9HIZnhBmWHuKdPU7aQ4nTkqcQSkRERERERETkOGxushGMmuLeitelY5c8P8Goibf3JM4ueQqhRERERERERESOQ3nnPKgJCRJCQcdcKIDFuxMnhLLG8sa3bNnCc889x913381vfvMbmpqaANi3bx8jR47kxhtv5Omnn2bTpk24XB19ijfffDNWq5VHH32UlpYWXC4Xc+fOJSMjg82bN/Pss89isVgoKytj9uzZAMybN4+VK1disVi45pprGDFiRCwfloiIiIiIiIhIt0QMoYZlhBmeGeK9GietQRPp9vi3CcYshFqwYAHLly/H6exI3G688UYA2trauOeee7j66qsB2L59O7fffjsZGRndX/vSSy8xZMgQrrjiClasWMH8+fO59tpreeqpp7jpppvIz8/nwQcfpKKiAoD169dz//33U19fz8MPP8wDDzwQq4clIiIiIiIiInKA8nobWfYIRZ5IvJdygHOLffyhPIPl1U4uGuaL93Ji146Xn5/Pj370o89d/vzzz3PBBReQnZ1NNBqlpqaGJ598kjvvvJMlS5YAsHHjRiZPngzAlClTWLt2LV6vl3A4TEFBASaTiUmTJlFeXs7GjRuZNGkSJpOJvLw8IpEILS0tsXpYIiIiIiIiIiLd6nxmarxWxueGMCXODHAg8XbJi1kl1GmnnUZtbe0BlzU3N1NeXs4111wDQCAQ4Pzzz+fiiy8mGo1yzz33MHz4cHw+H263GwCn04nX68Xn83W37HVdXltbi81mIz09vftyl8uF1+s9oLLqUAoLC3vhkYqIiIjI0dAxmIiIpJLVWzs+Th3mTLi/cYXAhI/hw1onruxCsuOcRcV0JtRnvffee5x55pmYzR0FWA6HgwsvvBCHwwHAhAkT2LlzJy6XC7/fD4Df78fj8eByufD5Pi0d8/v9uN1urFbrAZfvH2AdSXV1dW89NBERERHpgcLCQh2DiYhISlm+JQNIY6i9jurqxJkJ1eWc/DTKazP4+8dNzCr1xvz+DhfE9enueGvXru1us4OOEOinP/0p0WiUcDjMxo0bKSkpYfTo0axcuRKAVatWMWbMmO7AqaamBsMwWL16NWPHjmXMmDGsXr2aaDRKXV0dhmH0qApKREREREREROR4ldfbMGMwNicU76UcVFdL3qIEaMnr00qo6upq8vPzu/+/qKiIM888k9tvvx2LxcLZZ59NcXExAwcO5PHHH+fOO+/EarVyww03AHD99dfz2GOPEY1GKSsrY+TIkQCMGTOGO+64A8MwmDNnTl8+JBERERERERHpp0JR2NhoZ3hWGLc1/rvPHcwgT4RxOUE+rrXTGDCT7YjGbS0mwzAS87vUB1QKLiIiItK31I4nIiKpZF2DjW8uHsCXS9u5+cTmeC/nkP622cOjqzP58QlNXDY8ti15CdOOJyIiIiIiIiKSKtbV2wGYkJt4s6D2N6MoMXbJUwglIiIiIiIiInIMyuttAExM8BAq3x2lLDfAqn126nzxi4IUQomIiIiIiIiIHIO19Xay7BGK0iLxXsoRnVvsx8DE0sr4VUMphBIREREREREROUp1PjM1Xivjc0OYTPFezZFNL/JhwmDRbmfc1qAQSkRERERERETkKJUnyTyoLnmuKFMGBFlT72CvNz5xkEIoEREREREREZGjtLYzhEr0eVD7m1ncMaB8SZxa8hRCiYiIiIiIiIgcpXUNNswYjM0JxXspPTa9yI8Zg0Vx2iVPIZSIiIiIiIiIyFEIRWFDg53hmWHcViPey+mxbEeUEwcGWd9gZ0+7pc/vXyGUiIiIiIiIiMhR2NJkIxg1Jc08qP2d29mStzgO1VAKoUREREREREREjkKyDSXf3zlFPiym+OySpxBKREREREREROQolNfbgOQaSt4l025wSn6ATU12drf1bUueQigRERERERERkaOwtt5Olj1CUVok3ks5JjPj1JKnEEpEREREREREpIfqfGZqvFbG54YwmeK9mmNzzmA/NnPf75KnEEpEREREREREpIfKG5J3HlSXNJvBaQV+tjXb2NFi7bP7VQglIiIiIiIiItJDyTyUfH8zi/0AfVoNpRBKRERERERERKSHyuttmDEYlxOK91KOy5mD/NjNBot3OzGMvrlPhVAiIiIiIiIiIj0QisKGBjvDM8O4rX2U3MSIx2YwdZCfHa02tvVRS55CKBERERERERGRHtjSZCMYNSV9K16Xvt4lTyGUiIiIiIiIiEgPpMo8qC5nDArgtERZtNvVJy15CqFERERERERERHqgvN4GwMQUCaFcVoMzCwNUtlnZ3GSL+f0phBIRERERERER6YHyejuZ9ghFaZF4L6XXdLXkLdrtjPl9KYQSERERERERETmCer+ZPV4r43NDmEzxXk3vOb3Aj9saZXEftOQphBIREREREREROYK1nfOgUqUVr4vDAmcX+tnjtbK+IbYteQqhRERERERERESOINWGku/v05a82O6SpxBKREREREREROQIyuttmDEYlxOK91J63Sn5AdJsUZZUuojGsCVPIZSIiIiIiIjIYdzzQRY/fCunT7awl8QUisKGBjvDM8O4ran3i2C3wDmD/dT6LN1th7GgEEpERERERETkEOp8Zl7b6eLdGifbWqzxXo7EyZYmG8GoifEp2IrXpaslb3EMd8lTCCUiIiIiIiJyCG9WOTHo2AptcYzn5UjiWpfC86C6nDwwQKY9wpJKF5EYFXsphBIRERERERE5hKVVHcGT3WywqA+2sJfEtLa+Y9e4VNsZb39WM0wb7Kfeb2H1vti05CmEEhERERERETmIxoCZVbV2xucEOXuwn8o2K5ub1JLXH5XX28m0RyhOi8R7KTEV613yFEKJiIiIiIiIHMRbVU6imJhW5GNmUde8HLXk9Tf1fjN7vFbG54YwmeK9mtiaMiBItiPCsion4Wjv335MI9wtW7bw3HPPcffdd1NRUcFDDz3EoEGDADjvvPOYOnUqixYtYtGiRVgsFi677DJOPPFEgsEgjz76KC0tLbhcLubOnUtGRgabN2/m2WefxWKxUFZWxuzZswGYN28eK1euxGKxcM011zBixIhYPiwRERERERHpB5ZWdQxonj7YT64rgtsaZdFuF9+Z2JryYYR8qmu3uFRuxetiNcP0Ij8vbPOwcp+DU/IDvXv7vXpr+1mwYAHLly/H6ex40m7fvp2LL76YSy65pPs6TU1NvPLKKzz44IOEQiHuvPNOysrKeP311xkyZAhXXHEFK1asYP78+Vx77bU89dRT3HTTTeTn5/Pggw9SUVEBwPr167n//vupr6/n4Ycf5oEHHojVwxIREREREZF+oCVo4sO9DkZlBRnc2YJ1VqGf13a5Wd9oY3xOKM4rlL5S3g+Gku9vZrGPF7Z5WLzb2eshVMza8fLz8/nRj37U/f8VFRWsXLmSu+66iyeeeAKfz8fWrVsZPXo0NpsNt9tNQUEBO3fuZOPGjUyePBmAKVOmsHbtWrxeL+FwmIKCAkwmE5MmTaK8vJyNGzcyadIkTCYTeXl5RCIRWlpaYvWwREREROQYxaKsX0QkVt6udhIxTEwv8ndf9ukW9mrJ60/K622YMRib3T+Cx0l5QfKcEZZVuXr9b3fMKqFOO+00amtru/9/xIgRzJw5k9LSUl544QXmzZvHsGHDcLvd3ddxuVx4vV58Pl/35U6ns/syl+vTJ7rT6aS2thabzUZ6evrnbiMjI+OIaywsLOyNhyoiIiIiR/DCBrh1CfxkKlw3RcdgIpL43v2o4+NXT8igMLvj/PJLA+HnH8Kb1Wncf34aZrXkpbxQBDY2wug8GDl0ULyX02cuGQPPfALbwoVMH9Z7t9tnY/1POeUUPB5P97+ffvppxo0bh9//aars8/nweDy4XK7uy/1+f/dlPp+v+7p+vx+3243Vaj3g8v0DrCOprq7ujYcmIiIiIodgGPCXTWn8bm3HCdwfVsIXBlZj0YlbQvjrJg8bG23cfWqTTqZF9tMeMrF8ZwGlGWFcvn1Uf3rKyZmDsvj3Tjevr91HWV7/qIzpzzY02AhEBjA6o53q6uZ4L6fPnJZt4xkG8PwnXkbbm47qaw9X8NNnu+Pdd999bN26FYC1a9dSWlrKiBEj2LBhA8FgEK/XS1VVFcXFxYwePZqVK1cCsGrVKsaMGdMdONXU1GAYBqtXr2bs2LGMGTOG1atXE41GqaurwzCMHlVBiYiIiEhsRQz49ScZ/G5tBgNdEaYW+Klpg/drHPFemtBxkv3UunTe2O3mXf1MRA7wzh4HweiBrXhdzu1qyatUS15/0N/mQXWZkBsi3xVmebWTYKT3brfPKqG++c1v8vTTT2O1WsnKyuJb3/oWbrebCy64gLvuuotoNMqVV16J3W7nvPPO4/HHH+fOO+/EarVyww03AHD99dfz2GOPEY1GKSsrY+TIkQCMGTOGO+64A8MwmDNnTl89JBERERE5hEAE7vkgm6WVLkozQvz6rHoaAhbeqXGycLubqYN6d9CpHL3Xd7nwRzrek563xcMZ+pmIdFvaGTBNK/J97nMn5wdIt0VZstvFDZNaVEWY4tbW24D+sTPe/swmmFHs52+b03h/r4OzCnvnb4TJMAyjV24pCakdT0RERKT3tQRN/GRFDp/UOZgyIMBDUxtItxsYBnzzzUI21RksuHgvuU5NKo+naxflsbnRRklmmG3NNv72xVqGZYTjvSyRuPOHTVywMJ+Brij/d34tpoOETPd/lMmL2z38blodUwb0r3Civ7ns5YF4wyZembX3oL8LqWx9g405iwdw3hAv95za1OOvS4h2PBERERFJfXu9Zr6zNI9P6hzMKPLx67PqSbd3vOdpMsGV4yFimHhlR89meEpsbGq0srHRzumDAswZ1wrAvK2eOK9KJDG8V+PAHzEzrch3yNDh3OKONr1F2iUvpdX7zezxWhmfG+p3ARTA2OwQgz1h3q524u+lljyFUCIiIiLSK7Y1W7l+yQAqWmxcMaKNe09rxGE58DpfGg12s8HC7W76bz1+/C3c3hE4XVrazlmFfvJdYV7Z4aI12A/PskQ+Y0mlE+Cg86C6nDAgQJY9wtJKJxG9lqWs7nlQOf2z2s1kghnFPrxhM+/ucfbKbSqEEhEREZHjtnKfnW8vzWOfz8LcsmZunHzwOSmZTphR5GN3m5VP6ux9v1DBHzbx+i4Xec4IpxcEsJrhKyO8+CJmXlKFmvRzgQis2ONkkDvM6KxD73xnNcO0Ij+NAQur9um1LFWVd86D6m9Dyfc3s3Mu2uJeqvpTCCUiIiIix2VJpZMbl+fiC5u4+5RGvj66/bBtC5eUegFYuF2BRzwsrnTSFjJzcYkXa+fZwKySduxmg/lbParqkH7tg70OvGEz04r8R2y/6tolTy15qau83o4Zg3E5hw4kU92orDDFaWFW7HHgCx9/taxCKBERERE5ZvO2eLjj3WxsZoNHzmrgi0M/v5PUZ03JC1KUFmbJbrV/xcPCio7w75ISb/dlmQ6D84d6qWq38s4eR7yWJhJ3yzp3xZtxkF3xPmvygCC5zgjLKp2Etc9CyglHYUOjjdLMMB5b/03nTSaYWezDHzGzohf+PiiEEhEREZGjFjXg8TXpPPJJJjnOKL+bVscp+T3bvtlkglklXoLRjrYw6TvbW6ysqXdwSr6fQs+BU2Znj2gHYN6WtHgsTSTuQlF4q9rJAFekR5UvFhNML/LRHLTwca3C21SzpclGIGLu1614XXqz6k8hlIiIiIgclVAUfvZBFn/ZlM6QtDBPzqhjdHb4qG7jwmFeLCZDLXl9rKsKatZ+VVBdRmSFOWFAgA9rHWxvsfb10kTi7uNaB60hM9MG+w460+5gZhZ17ZLXO0ObJXF0DyVXCMXwzDAlGSHe3eOkPXR8FcwKoURERESkx9pDJn70dg6v7XIzISfIH2bUfa6ipidynVHOGORnc5OdTY22GKxUPisYgVd2ush2RDh78MF3/Zo9sqsaytOXSxNJCMt6sCveZ5XlBRngivBmlYuQWvJSytrOoeQTFUIBHS15waiJt6qPL3BVCCUiIiIpZ2erhYXb3QSPPhuRw6j3m/nuslw+2OvkzEF+HjunnizHsZ91zdKA8j71ZpWT5qCFC4b6sB3iLODMQX4K3GFe2emiRfO6pB8JRzueI9mOCGV5PQ8dzKaO+VGtITMf7FVLXipZ12Anwx6lOE0HE9B7LXkKoURERCSleMMm/t/yXB74KItvvDGAldo6u1fsarVw/eI8NjfZubSknQemNuC0Ht+g1lPzAwxwRXhtpwt/L+y4I4e3YHtHddOs0vZDXsdqhq+MaMcfMfOSwkHpR1bX2WkKWpg22I/lKF+Ouk7Oe2sLe4m/Br+Z6nYrE3KCR9wlsb8Ymh5hZGaI92scx/UmhUIoERERSSm/W5PBHq+VsdlBdrdambssj59/mEVzQEeRx6q83sa3luSxx2vlm+Nb+MmJzVh74SjSaoaLhnlpD5tZUql5KrFU2dYxOHlyXoCh6Yd/V/+SEi8OS5R/bPUQ6b8bQkk/s7RzV7xpPdgV77PG54QocIdZXuUkoKKZlLBW86AOakaxj7BxfC15CqFEREQkZazcZ2f+Ng8lGSF+P72Op2bWMTIzxMs73Fz56kD+vcOFoZPqo/JWtYPvvZlLW8jMrSc2MWdcW6++K3xJ54DsF1V1E1NdLY+Xln5+IPlnZdoNzh/qY4/XyorjnP0hkgyiRkcrXoY9ygkDjj50MJlgRpGf9rCZ92v0nEkF5Z3zoBRCHag3WvIUQomIiEhK8IVN3P9hFmYMbj+5Cbul493pp8/dx/fLmvFHTNz7YTbffzOXXa2WeC83KSyscHPLihwAHpza0D3DqTcVeiKcPDDAJ3UOdurnEhPhKLy83U26LdrjKo/ZIzpa9p7fqgHlkvrW1tup81s4u9B3zFWen56cK4RKBeX1dswYjMsJxXspCaUoLcKY7CAf7nUcc4W5QigRERFJCb8vT6eq3crXRrcxfr+DRqsZvja6nb9+cR9TB/n5eJ+Dr78+kP9Zn6bB5YdgGPA/69J44OMs0u1RHj+nnjMLAzG7v64ZRS9uV+ARC2/vcdIQsHD+UC/OHuZ8wzPDnDgwwMe1DrY1W2O7QJE4W3oMu+J91pjsEIM9Yd6uduLX35akFo7ChkYbpZlhPDaVT3/WzGIfEcPEsqpjq4ZSCCUiIiJJb3WdnXlbPAxJD/HN8a0Hvc4gT4RfndHA/ac3kGmP8sd1GRpcfhDhKDz4cSZ/XJ9BoSfMkzPqGJ8b23eCzy70k2GP8u8d2uI8FhZWdLTiHW0l2xWd1VDzVA0lKczobMVLs0U5aeCxh+0mU8e8HF/EzLt7VA2VzLY02QhEzGrFO4SZnWHtsbbkKYQSERGRpOYPm7jvwywAbj+pCcdhKj1Mpo53uv92fi2Xj2g7YHB5U0CHRb6wiVveyWHhdg+js4I8OaOOIUcYYt0b7Ba4YKiXxoBFM4h6WY3Xwns1DsbnBBmRGT6qrz2j0M8gd5hXd7poPo6dkEQS2YZGGzVeK2cO8mM/zo7g3trCXuKrvEHzoA5nkCfChJwgK2vtNPiP/thJR1siIiKS1J5cl87uNitfHdlOWV7PKnbSbAY3TWn5zODyAbzcjweXNwXMfP/NXFbscXJqvp/Hp9WT6+y7sqSuAeULNaC8V7203Y2B6ZjmeVlMcPmIdgIRswbHS8rqasWbdhyteF1GZoYZkhZmxR4HvrCC22RVrp3xjmhmsY8opu7nz9FQCCUiIiJJa229jb9v9lCUFua/Jhy8De9wugaX/2BSM4GIiZ/308Hl1e0WvrUkj3UNds4f6uWXZzb0+RyM4ZlhJuQEea/GwV6vDlF7Q8SAl7a7cFuj3RUaR+viEi9OS5T5Wz2E1SopKcYwYGmlC5clyqkFxx9CmUwdJ+eBiJkVexy9sEKJh/J6Oxn2KEPSNNzrUGYU+zBhHFPVn/7Ci4iISFIKROC+D7Mw6GjDc1qPLTSxmuGqUR2Dy8/Yf3D5uv4xuHxTo43rF+exu83KN8a08tOTm7DF6QjxklIvBiZe2qGqm97wfo2DvT4rXxjiw32Mz48Mu8EFQ33UeK28rTk3kmK2NluparcydVCgx0P7j2SmWvKSWoPfTHW7lQk5QUwqZjukga4ok/KCrK6zs893dAcNCqFEREQkKf3PunR2ttq4fEQ7kwccf8n8IE+EX+4/uHx95+Dy2tQdXP7BXgffXZZLY8DMD6c08d2JrXE96D632IfbGuWl7W4i/bQtsjct6BxIfmnJ0bfi7W/2yM4B5Vs0oFxSy5LKjqBoetGxVQoezPDMMCUZId7d46Q9pBQj2axVK16PzSj2YWBiaeXRBa4KoURERCTprG+w8dymNAZ7wnxn4tG34R1K1+Dy/zu/ltldg8vfTM3B5a/udPHDt3IIR038/PRGZo84vqCiN7itBl8o7qi6+XCvWlmOR53PzIo9TkZmhRiTfXy7G5ZkhDl5YICV+xxsbbL20gpF4m9ZpRO72eD0Qce+K97BzCz2EYyaeFsbLSSd8noNJe+pGUV+zMfQkpdaR1MiIiKS8oIR+PmHWUQxcdtJTbiOsc3ocDw2gx92DS7PSq3B5YYBf9mYxj0fZOO2Gvzm7Hpm9MJA3t5ySakGlPeGl3e4iRgmLi1p75Xqttkj2wCYt1XVUJIatrdY2dFq47QC/zG3qx7K8W5hL/FTXm/HhMG4nOML7/uDXGeUKQOCrK23H9UsR4VQIiIiklSe2ZDO9hYblw1v54SBsX2ncnxOiKdnps7g8ogBv/4kg8fXZjDQFeH30+uY0gutjL1pXHaI4Zkh3qpyHtPWzwJRA17c7sZhiXLekN5pM5o6KMBgT5hXd7ppDqjFSJJf165esQjhh2WEGZEZ4r0aB61BPV+SRTgKGxptlGaG+3xzjmTVNQNt8VEErvrLLiIiIkljU6ONP29Mo8Ad5rsTW/rkPlNlcHkgAne+l828rWmUZoR4asY+SjPD8V7W55hMMKvES9gw8epOVREci49r7VS1W5lR5Cfd3jsnUhYTfGVEO8GoiYXbVQ0lyW9ZpQuryeCMwthUgs4s9hE2TCxXS17S2NpsIxAxqxXvKEwv8mMxHV1LnkIoERERSQqhaEcbXsQwcetJTX3+LmXX4PIHknBweUvQxI3Lc1la6WJyXoDfT69joDsa72Ud0heHerGbDRZudyd9+2M8dIVEl5b27pyvi4d5cVmizN/qJpy4vz4iR7S7zcKWZhunFARIi9HfkmOpEJH4Wts5D2qiQqgey3JEOWlggA2NdqraelYl3qMQqqqqisWLF2MYBr/+9a/5/ve/T3l5+XEtVkRERORo/GlDOlubbVxa0s4p+fE5QDSZYFqSDS6v9Zr5ztI8PqlzMKPIx2/Oru+16phYybQbnDPYx85WG2vqEz/kSyRNATNvVjkZlh6irJdPpNLtBhcM87HXZ+UtVXdIElvWtSve4N7bFe+zitMijM4K8sFeh1pYk0S5dsY7Jt2Baw93yevR0dKTTz6J3W5n5cqVNDQ08O1vf5u//e1vx75KERERkaOwpcnKsxvSyHeF+f6kvmnDO5xkGVy+rdnK9UsGUNFi44oRbdx7WiOOJBlnNauziudFDSg/Kq/sdBGKmphV6u2VgeSfNXtEOwDPb1FLniSvpZVOLCaDs2LUitfl3GI/EcPEm1WqhkoG5fV2MuxRhqQlUa99AjhnsB/rUbTk9SiECoVCnHXWWaxevZrTTz+d8ePHE4noByMiIiKxF96vDe+Wk5oTaljowQaXf+/NXHYmwODyVfvsfGdpHrU+C3PLmrlxcgvmJHoz/oQBQQZ7wize7aQtlEQLjyPDgAUVbmxmgwuGxqbCY1hGmFPz/XxS52BzkzUm9yESS3vaLWxotHPiwACZjtj+PemqENEueYmvwW+mut3KhJxgTAL8VJZhNzilIMCWJluPNm7pcQjV1NTEypUrKSsro6mpiWBQJWoiIiISe3/emMbmJjsXDfNyWkEg3sv5nM8OLl+5z8E34jy4fEmlkxuW5+INm7jrlEa+Pro96Q6qzSa4uMSLP2LmjV06geuJNfV2drbaOGewnyxH7IY2zR7ZUQ01T9VQkoSWVXW0kk4bHNsqKOiYJTg+J8jHtXYaE7RlWzp0teKNVyveMZlZ1PMZaD16JnzhC19g7ty5jBkzhqKiIm699VYuvPDC41uliIiIyBFsa7by9Pp08pwRbpjUHO/lHFaiDC6ft8XDHe9mYzMbPHJWA+fHqCKmL1w0zIsZQy15PbSgouP7NKukPab3c3pBgMGeMK/vcifsLDSRQ1la6cKMwTl9EEJBRzVUFBNLKzVHLZGVdw4l1zyoY3P2YD82c89a8nr0V+Okk07iz3/+M9/73vcA+MUvfsGYMWOOb5UiIiIihxGOwn0fZhE2TNxyUlPCD9OG+A4ujxrwuzXpPPJJJtmOKL+bVscp+YlXOXY0BriiTB3UseuOWr8OrzVoYkmlk8GeMCcOjO1JlNnUUQ0VjJq6gy+RZFDrM7O23s6kAUFynH2zxeOMo6gQkfhZW2/HhMH4nFC8l5KU0mwGpxf4qWixsb3l8H+vD/vZtrY2AB544AHuuuuu7ssjkQi/+tWv+M1vfnPYG9+yZQvPPfccd999Nzt27ODpp5/GbDZjs9mYO3cuWVlZPP3002zatAmXq+NJefPNN2O1Wnn00UdpaWnB5XIxd+5cMjIy2Lx5M88++ywWi4WysjJmz54NwLx581i5ciUWi4VrrrmGESNGHPGbJCIiIontr5vT2NBo5/yhXs4YlFxhStfg8i8O9fHQx1m8vMPN29UOvj+phQuH+nq9NS4Uhfs/zOLVXW6GpIX59dn1FHpSY37nrNJ23t7j5MXtbm6aEv+h9InqtV0uAhEzl5S09cnsr4uGeXmyPJ0Xtnn4j9FtWFUQJUngzc5WvOl9VAUFkO+OUpYbYNU+O/V+M7l9FH5Jz4WjsKHRRmlmOKHmTiabmcV+lle7WLTbxRmHqVk6bAj13//936xZswaAOXPmdF9uNps57bTTDruABQsWsHz5cpzOjif6M888w3XXXcewYcN44403WLBgAVdffTXbt2/n9ttvJyMjo/trX3rpJYYMGcIVV1zBihUrmD9/Ptdeey1PPfUUN910E/n5+Tz44INUVFQAsH79eu6//37q6+t5+OGHeeCBBw7/3REREZGEtqPFyh/XpZPrjHDj5MRuwzucrsHl87Z6eLI8nZ9/mM2/d7i5+cQmhqb3TkjUHjJx27vZfLDXyYScIL88syGm84D62ukFAfKcEV7b6WZuWQvO+M98TziGAQsrPFhMBhcN8/bJfabZDC4c5uUfW9N4s8rJzOK+O6kXOVbLOreQP6eob9uUzy32s6bewZJKJ7NH9M1zVHpua7ONQMTMhNzkbV9PBGcW+nFYoiza7eSuw1zvsO9Z3H777fz973/nnHPO4e9//3v3f3/729+44YYbDruA/Px8fvSjH3X//4033siwYcOAjkoqm81GNBqlpqaGJ598kjvvvJMlS5YAsHHjRiZPngzAlClTWLt2LV6vl3A4TEFBASaTiUmTJlFeXs7GjRuZNGkSJpOJvLw8IpEILS16l0xERCRZRYyO3fBCURM3n9BMZhK04R1OLAeX1/vNfHdZLh/sdXLmID+PnVOfUgEUdHz/LhzmpTVk5s1KtbMczMZGG1uabZwxyE+eq+9+/peP6BxQvlUDyiXxNfjNfLLPzoTcIAP78HkCMK3IhwlDLXkJam3nPKiJmgd1XNxWg6mDAuxqtR32eoethKqqqmLw4MGcf/753VVH+ystLT3k15522mnU1tZ2/392djYAmzZt4rXXXuOee+4hEAhw/vnnc/HFFxONRrnnnnsYPnw4Pp8Pt7ujv9zpdOL1evH5fN0te12X19bWYrPZSE9P777c5XLh9XoPqKw6lMLCwiNeR0RERPrWHz6GdQ0waxRceXJOvJfTawqB50bAq9vgrmUm/rg+g6V7MrhvBpxedPS3V9EI334NKlvgqgnw8+lOrOZBvb7uWDjaY7A5bvjfjfBqdTbXnp4do1Ulr8c2dHy89iQXhYV9d5JbCJyzAd7c6aDeWsjEgX121yJHbdlaiAJfGmfv8/PAQuDUwfBelQNTeiGD0o/4JdKHtnU0fzFjbDaF2fobczxml8HSysNf57Ah1J///GduueUWHn744c99zmQy8dvf/vaoFvTOO+/wwgsvcMstt5CRkUE0GuXCCy/E4XAAMGHCBHbu3InL5cLv7yjp9fv9eDweXC4XPt+n5XF+vx+3243Vaj3g8v0DrCOprq4+qvWLiIhIbO1qtfCrdwaS7YjynTH7qK5OraoegElueO4LJv5Qns4/tnq4cr6Ji4Z5+V5ZS4+rmNbV27jp7Ryagxa+Ob6F68a0UVsT44X3ksLCwqM+BrMDJw7I5b1KB+9v2ktxL7UypgJv2MS/NuaT74oy0l5LXx/eXlrs4M2duTzxrpc7Tm7q2zsXOQr/WpcDODkhfS/V1X3/GnJWvpv3qrL428fNXDkqtjtYytH5qHIg6TYzDm8N1erIOy5jHSY81nwO13R32Ha8W265BYDHH3/8c/8dbQC1fPlyXn31Ve6++27y8/OBjhDopz/9KdFolHA4zMaNGykpKWH06NGsXLkSgFWrVjFmzJjuwKmmpgbDMFi9ejVjx45lzJgxrF69mmg0Sl1dHYZh9KgKSkRERBJLxOjYDS8YNfHjE5pTrq1sf12Dy/84s46RWSFe3uHmylcH8PIOF8YRug/frnYw981c2kJmbj2xiTnj2np90HkiuqS0Y47Kizu0G9v+Fu124Q2bubjEhyUOvwenFgQoTgvz+i4XDX5NJ5fE1Bw08VGtgzHZQQbFadOGaYP9mNWSl3Aa/Gaq2q1MyA32yaYOqc5pNXh8Wv1hr9OjvW6bmpp44403aGtrw9jvyOi6667r0UKi0SjPPPMMeXl5/OpXvwJg3LhxXHHFFZx55pncfvvtWCwWzj77bIqLixk4cCCPP/44d955J1artXv+1PXXX89jjz1GNBqlrKyMkSNHAjBmzBjuuOMODMM4YIC6iIiIJI95WzysqXcwo8jH9KL+MeR43FEOLl9Y4eahjzOxWQwenNrAmYXJtWvg8Zg22Ee6LZN/73DzrfGt2o2t08IKNyYMLi6Jz7Bjswlmj2jnkU8yWbjdzTVj2+KyDpHDebvaScQwxfVvS44zygkDg3xU62BPuyVuYZgcqLzeDsAEzYPqNaOzQ4f9vMkwjvR+G9x77704HA6GDRuGab+32mbPnn38K4wjteOJiIgkht1tFr7x+gBcFoPnvriPnH64hfWedguPrMrk7T1ObGaDq8e08o0xbdgtHbufPb0+jT+uzyDTHuHhMxsYn3v4g7xEdSzteF0eWZXBvK1pPDS1gbP7cIv1RLW12co3Xh/I6QV+HjmrIW7raA+ZmPVSPm6rwT8v2quAUBLOj97OYcUeJ8+fH9923gUVbh78OIu5Zc18fbRa8hLB79ak8+dN6fz32XWckq8gqrccbu5ajyqhGhoa+PWvf91rCxIRERHpEjXg/g+zCETM3HFyQ78MoAAGeSL84owG3qx28siqTP64PoPXd7u4aUozS3a7WLDdQ6EnzK/PqmdIP52JNKvEy7ytaSzc7lYIRUcVFMCs0vhu+e6xGVw8zMvzW9NYVuXk3GL9bCRxtIdMfLDXwYjMUNznyU0b7OOXKzNZstulECpBrK23Y8JgfE5yvrGTjHr0PkVeXl73oHARERGR3jR/m5tP6hycM9jHzH7ShncoJlPH3JC/fbGWK0a0sbvVyg3L81iw3cOorCBPzqjrtwEUwIisMGOzg7y7x0Gtr3+X2/gj8OpONzmOCGcOiv/z5vIRHSfUz29Ji/NKRA709h4noaiJaUXxnzid6TA4OT/AhkY7lW2WeC+n3wtHYUOjjdLMMB7bERvEpJf0qBIqOzubm2++mXHjxmG327sv7+lMKBEREZGDqW638MSaDDLsUX58QnO/GLDdEx6bwf+b0sIXh/r4zSeZZDsi/PSUJh0k01H189DHWfx7R/+eP7Ss0kVryMw3xiTGfKzi9AhTC/y8U+NkQ4ONsaoqkASxrNIJwPQEqZ6cWeTjvRoni3e7uLofv4Ylgq3NNgIRMxNy4x9Q9ic9+pM1YMAAzjrrLPLy8sjIyCA9PV070ImIiMhx6WrD80XM/HByM7n9tA3vcMblhHhyRh0PndGoAKrTF4p9OC1RXtzuJtqPvyULulrx4jSQ/GBmj+yohpq31RPnlYh08IVNvFvjYGh6iJKMcLyXA8DZg/1YTdolLxGU19sAmJCjWVB9qUeVUO+99x4mk6l7Z7yu4eSXX3557FYmIiIiKe1fFW4+3ufgzEF+zhuidyGlZzw2g5nFfl7e4ebjWjsn98NBsjtbLXxS5+DEgQGK0hKnPfOU/ABD0kMs2u3ie2Ut/Xa+mySOd2scBCJmphe1J0ylbYbd4NSCACv2ONnZajnoTqjSNz7dGU+Vm32pRyHUnDlzuv8dDodZsWIF+fn5MVuUiIiIpLY97RYeX5NBui3KzSc2JczJgSSHWSXtvLzDzYvb3f0yhFpY0VFpdGlJYg02Nptg9oh2Hl6Vxb8q3Fw3Tq1GEl9LKzuqjaYnwDyo/c0s9rFiT0dLnp4n8VNebyfdFmVIemJUyfUXPWrHGzduXPd/ZWVlfPvb3+bjjz+O9dpEREQkBRkGPPhxJt6wmRsmNzPApWoJOToTc0MMSw+xrMpFc6B/JZihKLyy00WmPcI5CTLjZn8XDPXhsUb55zYPIT21JY4CEXhnj4PBnjAjMxMrZDi70I/drJa8eGrwm6lqtzIhN4i5f/0ZibtjGmPY2tpKY2Njb69FRERE+oEXd7j5YK+T0wv8XDg0sd6dluRgMnUMKA9FTby6yx3v5fSp5VVOGgMWLhjqw56Am2t5bAYXl3ip81u6q1BE4uGDvQ68YTPTivwJV23rsRmcVuCnosVGRXOPmpOkl33aitf/qmnjrUe/8TfddFP3HCjDMKirq+MLX/hCTBcmIiIiqafWa+bRTzLwWKPcojY8OQ7nD/XxuzUZLKxwc8WIxJn3EmsLt3eEbpeWJs5A8s/6yoh2nt/iYd4Wj+a9SdwsSdBWvC7nFvtYXu1icaWL0szWeC+n3+keSq4Qqs8d9UwogIyMDIqKimKyIBEREUlNHW14WbSHzdx6YhMD3erVkWOX7Yhy9mA/SypdrG+wMb4fDJatbrfwwV4nZbkBhiXITl8HU5wWYeqgjsHL6xpsjM9J/Z+NJJZQFN6udpLvCjMuOzF//84oDOCwRFm028k3x7X2myA9Uaytt2PC0OtTHBz1TKhx48YpgBIREZGj9u+dLt6tcXJKvp9LEmhbeUleszp/j7qqg1Ldi52Pc1YCV0F1uWJkx9D0f2zxxHkl0h99tNdBWygxW/G6uK0GUwcF2NVqY6ta8vpUOAobGm2UZITx2Ix4L6ffOaaZUCIiIiJHY5/PzH9/konbGuXWk5oT9qRAksvJ+QEK3GHe2OWiPZTav1ThKLy03U2aLcrMosQbSP5ZJw8MMCw9xKLdLur9OuWQvrW0ygnA9AR/rpxb3NEqqAHlfWtbs41AxMxEteLFhf4iiIiISEwZBvzi4yxaQ2bmlrVQ4I7Ee0mSIswmuLjEiy9iZnGKD8F+t8ZBnd/CeUN8OK2J/869yQSzR7YTNkz8a1v/qFSTxBCOdgzwz3VGEj5kmFoQwGWJsmi3CyPxn9YpY63mQcWVQigRERGJqdd3uXh7j5MTBwb4UhK0EUlyuXiYFxMGL1akdtCxoKKjre3S0vY4r6Tnzh/qI80W5YVtHkIaASd9ZNU+O81BC+cM9mNO8AJJp9XgzEI/Ve1WNjXZ4r2cfuPTnfE0DyoeFEKJiIhIzNT7zTy8KhOXJcptJzUl/AmBJJ98d5TTCgKUN9jZlqJzVWq9Zt7d42BsdpBRWYk7kPyz3FaDS0q8NAQsLFG7kfSRZVWJvSveZ80s7mgZXKTnSJ8pr7eTbosyJD15Xk9TiUIoERERiQnDgF+uzKQ1ZOY7ZS0UetSGJ7HRNaD8xRQdUP7SDjdRTEkxkPyzvjK8HRMGz2/VgHKJvYgByyqdZNkjTM5Ljlar0wr8eKxRFu92qiWvDzT4zVS1W5mQG9QbY3GiEEpERERiYnGlkzerXEzOC/CV4cl38izJ44xCP9mOCK/sdBNMsawzanSEay5LlC8UJ0dlx/4Gp0U4s9DP+gY76+rVbiSxtbbOTkPAwtmD/ViT5EzXYYGzBvup8VpZ36DnSKx1teKN1zyouEmSp6aIiIgkkwa/mV+tzMRhiXLbyWrDk9iymeHCYT5agmaWVzvjvZxe9cFeBzVeK+cO8SXtVuKzR3TMsVI1lMRa16540xJ8V7zPmtnZOqiWvNgr7wz6JmoeVNwohBIREZFe9/CqTJqDFr49oZXitBQrTZGEdElJR9CxsCK1go6FnQPXLy1J3mrCkwYGKckIsXi3i30+nX5IbEQNWFbpIt0W5aSBgXgv56icWhAg3RZlcaWLaHJmzUmjvN6OCYPxOaqEihf9FRAREZFetaTSyZJKF2W5AWaPTJ6dvCS5DU2PMDkvwIe1DqrbLfFeTq9o8HdUdg3PDDEuJ3nftTeZOqqhIoaJf6VYSCiJY0ODjVqfhTML/diS7CzXZoazB/vZ57OwtrNdTHpfONrxe1KSEU7aytJUkGRPTxEREUlkTYGONjy72eD2k5uwqA1P+tAlKTag/N873EQME5eWeDEl+XPp/KE+0m1R/rkt9eZ2SWJYmmS74n3WuZ0z3xbvTq2W4kSyrdmGP2JmouZBxZVCKBEREek1j6zKoDFg4VsTWhiSrjNN6Vszijp2mXp5h5twNN6rOT6GAQu3u7GbDb44NHlb8bq4rAaXlHhpDFhYXKm5N9K7DAOWVjpxW6Ockp9crXhdThoYINMeYUmli4iKdGJibefmCBMUQsWVQigRERHpFW9WOXljt5vxOUGuHKU2POl7TqvBF4f62Oez8P5eR7yXc1xW7bOzu83KjCIfGfbUOCO9fEQ7Zgye3+LRVvTSqzY3Walut3LGID+OJO3GtZph2mA/9X4Lq/epJS8WunbGm6Ch5HGlEEpERESOW3PQxC8+7mjDu0NteBJHszpb8roGeierBZ0thbNKk78KqssgT4QzC/1sbLR371Al0huWVna14iXXrnifNbOrJU/VgjFRXm8n3RZlSHo43kvp1xRCiYiIyHH7zSeZNAQszBnfyrAMHdxJ/IzODjEqK8iKPU7q/cl5qNscNLGs0sWQ9BCT81KrbeSKzs0K5m3RgHLpHYYBS6ucOCxRTitIzla8LlMGBMl2RFha6Uz6luJE0+A3U9VuZXxuELPeKIur5PzLLCIiIgnj7WoHr+50MzY7yNdGtcV7OSLMKvESMUz8e0dyVkO9ttNNMGpiVgoMJP+sEwYEKc0IsaTSRa1PpyJy/La3WNnVamNqQQCXNbn7PK3mjmquxoCFlWrJ61XrGjQPKlHolV9ERESOWWvQxEMfZ2E1deyGZ9WRhSSA84b4sJsNFm53J93sIcOABRVurCaDC4cl5y5fh2MydVRDRQwT/9ymaig5fksrO3aTm5bkrXhdulryluxWS15vWts5D2qi5kHFnQ4VRURE5Jj99+pM6vwWrhvXyvBMteFJYki3G8wo9lHZZmVVXXJVE6xrsFHRYuPswX6yHanZj/PFIT7SbVEWVLgJaBNNOU5Lq1zYzAZnDEqNEGpSXpA8Z4SlVS615PWi8no7JgzG56gSKt4UQomIiMgxebfGwcs73IzKCvKNMWrDk8TSNaD8xSQbUL6gc72XptBA8s9yWg0uLW2nMWBhkao95DjsarWwrdnGqfkBPLYkK3s8BIsJphf5aAma+bA2uXf5TBThKGxosFGSEU6Z35NkphBKREREjlpbyMSDH2VhMXXshqc2PEk0k/OCFKeFWVLpoiWYHIOV2kMmFu12UegJc9LA5B6wfCSXDfdixuD5LZ6ka5mUxNG1K960otRqXZ1Z3FHVtVghba/Y1mzDHzEzUfOgEoIOGUVEROSo/XZ1BrU+C9eMbWNkltrwJPGYTB3VUMGoidd3JceJ3Ou7XPgjZi4p8ab87k2DPBHOHuxnc5OdNfXJ1TIpiWNZlROLyeCswtRoxesyMTfIQFeEN6uchNSSd9zK6zuGko9XCJUQrLG88S1btvDcc89x9913U1NTw+OPP47JZKK4uJg5c+ZgNptZtGgRixYtwmKxcNlll3HiiScSDAZ59NFHaWlpweVyMXfuXDIyMti8eTPPPvssFouFsrIyZs+eDcC8efNYuXIlFouFa665hhEjRsTyYYmIiPRrH+y1s2C7hxGZIa4e2xrv5Ygc0gXDvPy+PJ2FFR6+Mjzxd5pbuN2NxWRw0bDUbcXb3+yR7SyrcjFvi4dJeTo5lKNT3W5hY6OdU/P9ZNhTq5zObOoYUP63zWm8X+PgzMLUroyMtXINJU8oMauEWrBgAb///e8JhTp+0H/605+48sor+dnPfoZhGHz00Uc0NTXxyiuvcO+993L77bfz17/+lVAoxOuvv86QIUP42c9+xtlnn838+fMBeOqpp/jBD37Az372M7Zu3UpFRQUVFRWsX7+e+++/nxtvvJH/+Z//idVDEhER6ffaQyYe2K8Nz6aaaklguc4oZxb62dJsY1OTLd7LOaxNjVY2NtqZOsjPAFf/KH2YkhdkRGaIZVVOar16MZGjs6xzV7zpKbIr3mfN7GwxVEve8VtbbyfdFmVIuiq3E0HMXu3z8/P50Y9+1P3/FRUVjBs3DoApU6awZs0atm7dyujRo7HZbLjdbgoKCti5cycbN25k8uTJ3dddu3YtXq+XcDhMQUEBJpOJSZMmUV5ezsaNG5k0aRImk4m8vDwikQgtLS2xelgiIiL92u/WZlDjtfKNMW2MztY7ipL4ugaUL0zwAeULt3sAuKSkf1RBQUfL5OyR7UQMEy9s88R7OZJklla6MGNw9uDUDKHG5YQY5A6zvNqpXSSPQ4PfTFW7lfG5wZRvc04WMWvHO+2006itrT3gMlNnDbTL5cLr9eL1enG7Pz0g6Lrc5/N1X+50Orsvc7k+TYGdTie1tbXYbDbS09M/dxsZGRlHXGNhYeFxPUYREZH+5J3d8MI2GJULt81Ix2FNP/IXiRxEXx6DfbkAfvkJLKr0cP/5HtwJWBDlDcEbuyHfA185IbdfDfq/ZiA8UQ4Ld6Rz28x0nDEdFiKpYk8rlDfA6UUwvqQg3suJmUvHwu8/hs3BQr44PN6rSU7rKjo+Th3m1Pl/guizl3nTfk34Pp8Pj8eD2+3G7/d/7nKXy9V9ud/v777M5/t01wO/34/b7cZqtR5w+f4B1pFUV1cf78MSERHpF3xhEze9PgAzFn4yuY76WlVBybEpLCzs82OwC4rTeWZDOs992MhFwxJvF62Xd7hoDWbzleGt1Nb0vzlrlwxL588b0/nf9xu5uCTxfj6SeOZt8QCZnDGgierq1K0ePC3bxu8ZwLzVXia6muK9nKT05pZ0IJ2h9nqqqzVbq68cLvDrs/dZhg0bxrp16wBYtWoVY8eOZcSIEWzYsIFgMIjX66Wqqori4mJGjx7NypUru687ZsyY7sCppqYGwzBYvXo1Y8eOZcyYMaxevZpoNEpdXR2GYfSoCkpERER67om16VS3W/mP0W2My1EAJcnlkhIvJgxe3J6YLXkLKjyYMLpbB/uby4Z7sZgMnt+ahpFa86UlRpZUOjFhcE6KtuJ1GZUVYrAnzNvVTvxh9ZIdi/J6OyYMxuVo84NE0WeVUP/5n//JH/7wB8LhMIMHD+a0007DbDZzwQUXcNdddxGNRrnyyiux2+2cd955PP7449x5551YrVZuuOEGAK6//noee+wxotEoZWVljBw5EoAxY8Zwxx13YBgGc+bM6auHJCIi0i98ss/OvK1pDE0PMWd8/6vSkOQ3yBPh5PwAH+x1sqPFyrCMxBlOW9FsZW19xw5fgzz9c/BLgTvC2YP9LK10sbrOzuQBOlmUQ2vwm1ldZ2dibpC8FB/ibzLBucU+/rQxnRV7HMwsTu3QrbeFo7ChwUZJRpg0mxLuRGEyjP77foPa8URERA7PHzbxjTcGUNVm4Q8z6rS9sRy3eLTjASza7eTO93L42qg2vj8pcTax+c0nGfx9Sxr3nd7AjBTd5asnPtln5zvL8phe5OP+0xvjvRxJYC9sc/PLlVncMKmZK0e1x3s5Mbe1yco33hio58Yx2NRo5ZpFA5lV0s6tJzXHezn9SkK044mIiEjy+UN5OpVtVq4c1a4ASpLa2YV+Mu0RXtnpIpQgxROBCLyy0022I8JZhf03gAKYlBdkZFaI5VVOaryWeC9HEtiyyo7Nqqb1k9B2eGaYoekh3tnjwKuWvKNSXm8HYEKuqisTiUIoEREROag1dTb+vsVDcVqYb01InMoRkWNht8AFQ300Biy8Xe2M93IAeLPKRUvQzIXDfNj6+VG5yQRXjGgjYph4YVtizu6S+GsOmFi5z864nCAF7v7RvmoywcxiP4GIOWFeu5JFVwilN9ESSz//cyciIiIH44/AfR9lAXD7yU04VZggKeCSzsHfCxNkQPnCio51zCpJ/ZainvjCEB9Z9ggLKjz4+0e+IEdpebWTiGFieooPJP+sc4s7do1cvFsh1NFYW28n3RZlSHrizAEUhVAiIiJyEH9cl8GuVhuzR7YzKU9l7JIaSjPDTMgN8n6NI+4tX7vbLHy8z8GUAQGGpCtxAXBY4NJSLy1BM6/vSoygUBLLp614vjivpG+VZIQpzQjxbo2T9pBa8nqiwW+mqt3K+NwgZn3LEopCKBERETnAunobf9vkYbAnzLcnaDc8SS2zStoxMPHydldc1/FiZxXUpZ3VWdLhsuHtWEwG87Z46L/bJ8nBtIVMfLDXwcisEEVp/S+4nVnsIxQ1sVwteT2yrsEGwIQcvZGWaBRCiYiISLdAZxteFBO3ndSEy6qzQEktM4v9uK1RXtrhJhKnX+9wFF7e4SbdFu13FR1HMtAdZdpgP1ubbayqs8d7OZJA3q52EjZMTB/cP58zXS15i3bHN0BPFp8OJdc8qESjEEpERES6Pb0+ne0tNr4yvJ0TBurdQ0k9bqvBF4p91HitfLjXEZc1vF3tpCFg4YKhXhyat/Y5s0d2zMiat8UT55VIIlla2VEBNL2f7Ir3WUPSI4zMCvFBjYOWoPrLjqS83o4Jg/HaGS/hKIQSERHpxwwDqtst/HuHiwc+yuS5TWkMcof5bpl2w5PUdUlpfAeUL+i831mlasU7mLLcIKOzgiyvcrKnXSmdgDds4r0aJyUZIYZl9N8h0+cW+wgbJpZXqSXvcMJRWN9goyQjTJpNFd2JxhrvBYiIiEjfiRiwrdnK6jo7q/c5WF1np87/6Uleui3Knac04VYbnqSwcdkhhmeGeKvKSYPfTI4z2mf3vafdwvs1DibkBBme2X9Ppg/HZOqohvr5h9m8sM3N3DLNpuvv3tnjIBg1Ma2f7Yr3WTOLfDyxNoNFu11cXNI/2xJ7YluzFX/EzIRcfY8SkUIoERGRFOaPwIYGe0foVGdnbZ2d9vCnhdC5zgjTi3xMzgsyKS/I8MwQVtVJS4ozmWBWiZdff5LJqztdfG10e5/d90s73BiYmFXad/eZjM4t9vH4mgwWVHiYM64Np4Lxfq1rV7wZ/XyG2uC0CGOzg3xU66ApYCbL0XcBejL5dB6UWvESkUIoERGRFNIcNLGmzs6aOjuf1DnY2GAjbHw6O2JIWpgZA3xM6gydBnsimDRaQvqhLw718viaDBZud3PVqPY+eR5EDHhpuxu3Ncq5xf27ouNIHBa4tNTLsxvSeW2Xi0vVuthv+SMdlVBFaWFVD9KxS96GRjtvVjn1vDiErhBqooaSJySFUCIiIklsT7ulM3DqCJ4qWmzdn7OYDEZlhToCpwFBynKDfdp2JJLIMu0G5wz28cZuN2vq7UzKi/075u/VOKj1WfhSabt2nuyBLw9v588b03h+i4dZJV4F5v3U+zVOfBEz04v6JixOdDOK/Px2TSaLdiucPZTyBjvptihD0hVaJiKFUCIiIkkiakBFi5XV+zpa69bU2dnr+/RPudMS5aSBASbnBSjLCzI+N6TZTiKHMavUyxu73by43d0nIdTCio6B5Dpx7JmBrigzijqCwpX77JyoHTv7pe5d8fr5PKgugzwRJuQEWVlr7/OZdsmgMWCmss3Kqfl+zAotE5JCKBERkQQVjMCGxgPnObWGPh3YlO2IMG2wj7LO1rpRWZrnJHI0ThgQZLAnzOLdTm6cbIrpLkp1PjMr9jgZlRVkTLZaRHpq9sh23tjt5vktHoVQ/VAwAm9XOylwh/W82c/MYh/lDXaWVjr5ygiF2vsrr++oCJ+oeVAJSyGUiIhIgmgNmlhb/2lr3YYGO8Hop2/jFaWFOXuwn7K8IJPzAhSnaZ6TyPEwm+DiEi9/KM/gjV0uvjw8didzL+1wEzFMqoI6ShNyQozNDvJ2tZPqdguFnki8lyR96KNaB+1hM7NK1Y65vxnFPh5dncHiSpdCqM/4dCi5QstEpRBKREQkTmq9Zj6pc3RXOlU0WzHoOMo2YzDyM/Oc8lwquRfpbRcN8/JUeTovbnfHLISKGvDidjdOS5TzhvTv3b2OlsnUUQ31sw+ymb/Vw/cntcR7SdKHlnTuijdtsJ43+xvoijIpL8gn++zs85kZoOODbuX1dkwYjFclVMJSCCUiItIHogbsaLF2B06r6+zUeD/9M+ywRJkyINi9a92E3CCeGLYGiUiHAa4oUwcFeHuPk81NVkZl9f4g249q7VS3W7lomDemLX+pamaRj8dWZ/DidjffHN+qoe79RDgKb1U7yXNGVNVyEDOKfXxS52BppYsrRrbHezkJIRyF9Q02SjLCeq1NYAqhREREYiAUhY2Nto7AaZ+DNfV2WoKfDmzKtEc4u9DX2VoXZFR2CJvmOYnExazSdt7e4+TF7W5umtL7lTYvbvd03E+JThSPhd0CXx7u5en16by6M7Ztk5I4Vu5z0BI0c/mINg2YPogZRX5+s8pg0W6FUF22NVvxR8xMyFXlXCJTCCUiItIL2kMd85y6qpzW1R84z6nQE2bqID+TOyudhqSHdVAtkiBOLwiQ54zw2k43c8tacFp677abAmberHJSkhFioqo5jtmXS9v504Y05m318CXNB+oXtCve4eU6OyqoP97nYK/XTL5bLXnrGjrmQY3Xa21CUwglIiJyHJoCZm5/N5tP9tmJds5zMmEwIjPMpAEBJuUFKcsLMlDzGkQSltUMFw7z8r8b01lW6eL8ob33LvorO12EoiZmlSg4OR55rigzi328vsvNR7V2Ts7XvJdUFjHgzSon2Y4IkwboZ30oM4t9fLzPwZJKF1eNUjXU2s6h5NoZL7EphBIRETlGgQj8ZEU2a+odjM8JctLAAJMGBJmYG9QsApEkc3FJRwi1cLu710Iow4AFFW5sZoMLhqqF7HhdMaKd13e5mbfVoxAqxa2us9MYsHBpaTsWhbeHNK3Iz8OdLXkKoTqGkqfbogxN7/3ZftJ7FEKJiIgcA8OA+z/KYk29g3OLfdxzaqPa60SSWHFahBMHBPh4n4NdrRaGpEeO+zbX1NvZ2WrjC8VeMh0Kpo/X+NwQ43KCvF3tpKrNwuC04/8ZSWJa1tmKN6NIrXiHk+2IcuLAAB/sdVLdbqHQ03+fE40BM5VtVk7N9+t4LMFpBKqIiMgx+OP6dF7f5WZCbpA7TlYAJZIKLintqFZ6abu7V25vQUXH7Vxaqiqo3nLFiHYMTMzf5on3UiRGogYsq3KRbotywoBAvJeT8GYWdwR1S3a74ryS+CqvtwFqxUsGCqFERESO0is7XTy9Pp1CT5hfnNGAoxeHGItI/Ewb7CPdFuXlHW7CxznGrTVoYkmlk6K0MCdopk2vmVHsI9cZ4cXtbrxhpf+paF2DjX0+C2cP9mPV2eoRnTPYh8VksGi3M95LiavyznlQEzSUPOHpaS0iInIUVu2zc/+HWaTZojx8ZgPZDg0cF0kVDgucP9RLQ8DCij3Hd0L32i4XgYhZA8l7mc3csVNeW8jMqzv7d+VHqlpa2fFznV7UexsEpLJMu8Ep+QE2NdnZ3dZ/3xUrr7djwmC8KqESnkIoERGRHtrdauGWd3IwgAemNjAsQ4MvRVLNrJKO1rmFx9GSZxiwsMKDxWRw0TC14vW2Lw33YjUZPL/Fg6FRWynFMGBppROPNcrJA9WK11MzizsCu8X9tCUvHIUNDTaGZYS1MUwSUAglIiLSA80BEz98O5eWoJmfnNjESQP1TptIKhqRFWZsdpD39jio9R7bofKGRhtbmm2cVegnx6lqyd6W64xybrGPna02Pqx1xHs50os2Ndmo8Vo5s9CPvf8W9Ry1swv92MxGvw2hKlqs+CJmJqgKKikohBIRETmCYARueSeHyjYr/zmmlUtK1CIgkspmlXqJYuLlHcdWDbWwcyD5LA0kj5nZIzu2o39+iwaUp5KlnbviTdOueEcl3W5wan6Arc02drRY472cPqd5UMlFIZSIiMhhGAY88FEWn9Q5mFHk478mtMZ7SSISY18o9uG0RHlxu5voUXZ2eMMm3tjtosAd5pR8tRPFyricEBNygryzx9Gv5+Ckko5WPBdOS5TT9Nw5aud2t+T1vwHlaztDKO2MlxwUQomIiBzG0+vTeHWXmwk5Qe48pRGzBgyLpDyPzWBmsZ89Xisf1dqP6msX7XLhDZu5uMSLRa8XMTV7ZDsGJuZvVTVUKtjWYmV3m5WpgwI4rZrrc7TOLPRjNxssrux/LXnl9XbSbVGGpmtWZzJQCCUiInIIr+108cf1GQxyh3nojAacerNdpN+YVdLR7vXi9qMLOBZsd2PG4BINJI+56UU+8pwRXtrupj2kxC/ZaVe84+OxGUwd5Gd7i41tzf2nJa8xYKayzcq4nKDeKEwSffrbuWzZMpYtWwZAKBRix44d3HvvvTz00EMMGjQIgPPOO4+pU6eyaNEiFi1ahMVi4bLLLuPEE08kGAzy6KOP0tLSgsvlYu7cuWRkZLB582aeffZZLBYLZWVlzJ49uy8floiIpKBP9tm576Ms0mxRHj6rQcOFRfqZibkhhqWHeLPKSVPATJbjyK8BW5usrG+wM3WQn4FuvWbEms0MXx7ezlPrMnhlp4vLRyj4S2bLKp3YzQanF6gV71jNLPaxrMrFot0uhmf2j/EB5fU2QPOgkkmfhlDTpk1j2rRpAPzxj39k+vTpbN++nYsvvphLLrmk+3pNTU288sorPPjgg4RCIe68807Kysp4/fXXGTJkCFdccQUrVqxg/vz5XHvttTz11FPcdNNN5Ofn8+CDD1JRUUFpaWlfPjQREUkhu9ss3PJONlED7ju9gZIMlXeL9DcmU8dg8UdXZ/LqThdXjmo/4tcs2N4xkPzSEoUhfeVLpV6e3ZDOvK0eLhvuVSVEktrRYqWixcbZhT48NrXiHaszBgVwWqIs3u3iW+NbMfWD58O67qHkmgeVLOLSjrdt2zYqKys599xzqaioYOXKldx111088cQT+Hw+tm7dyujRo7HZbLjdbgoKCti5cycbN25k8uTJAEyZMoW1a9fi9XoJh8MUFBRgMpmYNGkS5eXl8XhYIiKSApqDJn70Vi7NQQs3n9DMKfk6qBHpr84f6sNqMnhxuxvjCOfF/gi8ttNNnjPC1EHa2auv5DijnFvsY1erjQ/2OuK9HDlGy6q0K15vcFkNzhgUYHeblS39pCWva2e88Tk6XksWcfnN/Oc//8nll18OwIgRI5g5cyalpaW88MILzJs3j2HDhuF2f7olrsvlwuv14vP5ui93Op3dl7lcnw5fczqd1NbW9mgdhYWFvfioREQk2QUj8P/+Cbva4NsnwrfPzAKy4rwqkdSTLMdghcAXR8DLW2zsNRdywqBDX/eFDdAagv+cDEOKkuPxpYq5p8MrO2Hh7lwuOyHeq5Fj8fayjvbKy0/IJtORHe/lJLXZk2BxJbzfOJBp4+K9mtgKR2FDE4zMgdHDDvMCLQmlz0Oo9vZ2qqqqmDBhAgCnnHIKHo+n+99PP/0048aNw+//NAX3+Xx4PB5cLlf35X6/v/syn+/T4XV+v/+AAOtwqqure+thiYhIkjMMuPfDLN6rcjN9sI9vlDSiPxMiva+wsDCpjsG+UODg5S25PP1hOwUnNR/yen9amQs4mJ63l+rqSN8tUMgFJubmsXSHnfc37aU4Xd//ZFLVZmHdvnxOL/DTXt/AkRtf5XBGO8BtLeBfG6J8fVhtSrfkrWuw4Q0NYExmO9XVh359lr53uDeb+rwdb8OGDUycOLH7/++77z62bt0KwNq1ayktLWXEiBFs2LCBYDCI1+ulqqqK4uJiRo8ezcqVKwFYtWoVY8aMwe12Y7VaqampwTAMVq9ezdixY/v6YYmISJJ7dkMar+x0My4nyE9PadJcEREB4OT8AAXuMIt2uQ65A9uOFiuf1Dk4eWCAwWkKQOLhipFtAPz6k0z2tGsr02SytLMVT7vi9Q6nBc4s9FPdbmVDoy3ey4mJrU1W7vswk+8uzQPgxAFqxUsmfV4JVV1dTX5+fvf/f/Ob3+Tpp5/GarWSlZXFt771LdxuNxdccAF33XUX0WiUK6+8Ervdznnnncfjjz/OnXfeidVq5YYbbgDg+uuv57HHHiMajVJWVsbIkSP7+mGJiEgSe32XiyfXZVDgDvPLMxpwWjUUVUQ6mE1wcYmXP67LYPFuF7NKPz90fGHnQPJZparhiJdpg/2MzQ7ybo2T2a84OH+oj6vHtlKsUDDhLat0YTEZnF2oeVC95dxiH6/vcrN4t4txOamxa1zUgBV7HPx9Sxof13bMfytKC/PVkW2cN0QBZjIxGcaRxiymrmQqBRcRkdhYXWfn+2/mYjcbPDmjjtJM7YQnEkvJ1o4HsNdr5ssv5zMuJ8QfZ9Yd8LlgBC59qeMN1gUX78WuIpy4CUdh8W4Xz25IY0erDTMGXxji45qxbQzTLqcJaa/XzJdeLuCkgQEeO6c+3stJGcEIXLiwgHR7lBcuTO6WvPaQiZd3uHl+i4eq9o4ampMGBvjqyDamDgqocj1BHa4dr3+MzBcRETmIyjYLt6zIJmrA/VMbFUCJyEHlu6OcVhDg3RonW5utjNjvtWJ5tZOmoIWrRrUpgIozqxm+ONTHuUN8LK108uyGdF7b5eb1XS5mFPm5ZlzrAT87ib9lVR0bTKkVr3fZLXD2YD+v7HRT3mBjYm7yVUNVtVmYt9XDS9vdtIfN2M0Gs0ramT2yXc/jJKcQSkRE+qWWoImb3s6hKWjhJyc2cUp+IN5LEpEENqvEy7s1Tl7c7ub/TW7pvnxhhaf785IYLCY4t9jPjCI/b1U7eWZ9GosrXSyudHF2oY/rxrUxOjv5TspT0dJKJyYMzhmsVrzedm6xj1d2drTkJUsIZRiwap+dv2/x8Fa1EwMTec4IXx/TwpdKvWQ5ovFeovQChVAiItLvhKJw6zs57Gq18bVRbXzpIDNeRET2d0ahn2xHhFd3uvnuxBYclo536j+sdTA5L6B2rwRkNsE5g/2cXejn3RoHz6xPZ3m1i+XVLqYW+Ll2XCsTkuTkPBXV+82sqbMzKS9IrlPhQm87OT9Aui3KkkoXP5jUktBta4EIvLHLxfNb0tjS3DFMfWx2kK+OamdGkQ9bn2+nJrGkEEpERPoVw4CHPs5i5T4H5wz2Mbes5chfJCL9ns0MFw7z8dymNJZXOfnCED8vdg8kV5CdyEwmmDoowOkFAT6stfPM+nTeqXHyTo2TU/L9XDu2jcnaXavPvVnVUekyvUhVULFgM8M5g328tMPDmjp7Qv6O1/vNvLDNwz+3uWkMWLCYDGYW+fjqqDYm5ISSepaVHJpCKBER6Vf+tDGNl3e4GZsd5O5TmhL6nUERSSyXlLTz3KY0Fm73ML3Iz8s73KTZoppnkyRMJjglP8gp+fWs3NcRRn2w18kHe51MGRDg2rGtnDQwqBPfPrKksmMe1LTBev7EyrnFfl7a4WHRbldChVAbG238fYuHRbtchA0T6bYo3xjdyldGtJPvVlVcqlMIJSIi/cai3U7+UJ5BvivML85owGnttxvEisgxGJoeYXJegI9qHczb6qHOb+Erw9txaiB50jlhQJATzqlnbb2NZ9an826Nk1X7HEzIDXLd2FZOKwgojIqhpoCZT/bZmZATZKBCh5g5cWCALHuEpZVO/t+UZixx/J0OR+Gtaid/3+JhdZ0DgKHpIb46sp3zh/pw6Zis31AIJSIi/cLaehv3fpCN2xrlV2c1kOfSQa+IHL1LSrx8Uufg8TUZAFxa2h7nFcnxmJgb4pGzGljfYOPZDWm8Ve3ih2/nMjY7yLXjWjlzkMKoWFhe7SRimJimKsKYspphWpGff1V4+GSfnRMH9n01VGvQxMLtbv6x1UONtyN+OL3AzxUj2zklP6CK9H5IIZSIiKS8qjYLN7+dQ8SAh05v1Na+InLMZhT5eWRVlPawmbHZQUZm6fUkFYzLCfGLMxrZ0tTKMxvSWVbp5OYVuYzMDHHNuFamDfbrZLkXLa10AmgeVB+YWezjXxUdLXl9GULtbLXw/JY0Xtnhwhcx47REuWx4O7NHtGsjh35OIZSIiKS0lqCJm97OoSlo4ccnNHFaQSDeSxKRJOa0GnxxqI8Xtnm4VAPJU87IrDD3n97I9hYrz25IY9EuF7e/m0NJRoirx7ZxbrEvri1NqaAlaOKjvQ5GZwUp9ETivZyUN2VAkBxHhGWVTm6a0ow1hjvNGQZ8sNfB81s8vFPTETTmu8JcN7KVWSVeMuxquROFUCLHJRyF5qCZpoCZ5qCZloCZpqCZfHeE03WiKxJ3oSjc9m4OO1ttXDWqjcuG64RRRI7ff01oYVRWiIuG6TUlVZVkhLnn1CbmjGvlTxvSeW2Xi7vfz+Z/1qVz9dhWvjjEF9OT+VT2drWTsGFimqqg+oTF1FFxNn+bh5X7HJyS3/vnKP6wiVd3uXh+i4ftLTYAynIDfHVUO2cX+vVckQMohBLp5I9AS2eY1BUqNXd93P/f+31sDx/6FfXS0nZ+OLkZu4aVisSFYcAvPs7k41oHZxf6mFvWEu8liUiKyLAbqoLqJ4akR7jzlCauG9fKnzt3V/35h9k8vT6d/xzTxoXDvNh0gn1UllV1VMjM0DyoPnNusY/52zws2u3s1RCq1mvmH9s8LKjw0BI0YzUZnD/EyxUj2xmbE+q1+5HUYjIMo9/WxFVXV8d7CRIDhgHesImW4CECpQM+mrr/3x/p2RGE3WyQ6YiSZY+S0fkx0xElwx4lyxEl3Rbl/7aksaXJxoScIPdNbWCgBiBLL2kLmVjfYOPEgUG1AxzB/25M44m1GYzJDvK7afXadUUkQRQWFuoYTJJWjdfCXzam8eJ2N8GoiXxXmK+PaeOSEi8OvfF4RO0hExcuLKAoLcxzX9wX7+X0G1EDLn0pn0DExMuzao47OC2vt/H3LWksrewYMJ9lj/Cl4V4uG97OAJ33CB1/6w9FlVCS0Ayj46S7ab9Wt4OHSQf+OxTt2dm529oRHg3LCJNp/zRIyuwMljo+GmTaI2Q6DLLs0R5t6T6jyM9DH2fy6i43174xgPtOb2TygL7fjUJSS3PQxPeW5bG12cbwzBBzy1o4LV+79hzM4t1OnlibwUBXhF+c0aAASkREekWBO8KPTmjm6rGtPLcpjX9VuHl4VRZ/2pDOf4xu40ul3h4dK/ZX7+xxEIyaVAXVx8wmmFHs4/ktaXy418HUQUdfDRWOwpLKjpa7dQ12AEZkhrhiZBvnDfEphJUeUyWUxI1hwF6fhYpmKxUtVna3Wj9XtdQSNBMxenaGnW7rCJEOV6V0QLhkj8a0Vc4wYN5WD4+u7tjC+QeTWpg9ol2BgRyT9pCJ77+Zy4ZGO6OzgmxusmFg4qSBAb5X1sLobJU8dymvtzF3WR5Ws8EfptcxQjtXiSQUVUJJKmnwm/nbZg/zt3rwRcxkOyJ8bVQ7Xx7ejsfWb0+zDum2d7NZWuniL+fVMlw71faptfU2vrVkABcO9XLnKU09/rrmgIl/VXiYv83DPp8FEwZnFvr56sh2ThgQ1LmNHNThKqEUQknMGQY0Bsxsa7ZS0WLrDJ06PnoPMlPJhNEdJmXajQOCo64gaf+AqauCKVEH3q3aZ+f2d7NpDFg4f6iXn5zQrHfI5Kj4wiZ++FYOn9Q5uGiYl9tOaqKi2crjazN4r3PnkfOHePnWhFYG9fNdZqrbLXxzcR7NATO/PLPhmN7pE5HYUgglqag5YOL/tqQxb4uH9rCZDHuUK0e2MXtkO2kKo4CO4dUXLMxnoCvK/51fq/CijxkGXPbvgbSFzLx8Sc0R34yvaLby/BYPr+zsaD11W6NcXOJl9oh2itL69/GmHJlCqEPQAVDvawmaqGi2UdFi3e+jlebgga9yFpPBkPQwpRlhSjJDDM8IMzQjTI4jQprdSLlZN7VeM7e9m8O6Bjsjs0I8NLWh34cF0jOBCNy8IocP9jqZWeTjntMaD3h+fLDXzuNrMtjcZMdmNpg9op2rx7b2yy1wW4MmvrUkjx2tNn40pYmvjNDQYJFEpBBKUllr0MTzWz38fXMarSEzabYos0e089VRbWT2w7/N+1tW6eTWd3O4ekwr357YGu/l9EuPrs7gb5vT+MUZ9ZxV+Pk36qIGvFvj4PktHj7Y2/FG52BPmNkj27l4mFfVfdJjCqEOQQdAx84bNrG9M2CqaLaxvcXKtmYbdf4DwyYTBoWeCMMzQ5RmhinNCFGSGWZIWrjf7RoXjMAjqzJZsN1Dhj3Kvac1xmSLVEkd4WhH2fpb1S7OHOTngakNB634ixrwxi4Xvy9Pp8ZrJd0W5ZqxrXxlRHu/6c8PR+H/vZXLR7UOvjqyjRsnayc8kUSlEEr6g/aQifnbPPxtk4emoAW3NcpXRrRz1ah2sh39c3DzXe9n8fouN8+eu09jBOJkfYONOYsHcN4QL/ec2tR9uTds4uUdLuZtSWN3W8fY6BMHBLhiZDtnFPpTrkBAYk8h1CHoAOjIAhHY1doRNG1r+TRwqm7//Ez7fFeY0swwJRlhSjNDDM8MMyw9rNazz1hQ4ebhVZlEovDtia18fXSbypHlcyIG3P1+Not2uzh5YIBfnll/xEApEIF/bPXwpw3ptIbMFLjDfHtCK18Y4sOcwr9jhgEPfpzJwu0ezir08cDURh0siSQwhVDSn/jCJv5V4ea5TWnU+y04LVG+PNzL10a1kdePdhELRuCChQVkOaL84wK14sWLYcDsVwbSGDDz8qwaGv0W5m318OJ2N20hMzazwXlDfHx1ZBsjNVNTjoNCqEPQAdCnwlGobLOyrdnK9s55TdtarFS2Woly4F+JbEeE0swwwzNCnaFTx0f1u/fcunobt76bwz6fhelFPu44uQm3wjrpFDXg/o+yeHmHm0l5AX591tHt7tYcNPGnDen8Y6uHUNTE6Kwg35vUwkkDU3OHxr9sTOPxtRmMygryxPR6PZdEEpxCKOmP/BF4scLDnzelsc9nwW42mFXazjdGtzHQnfph1NvVDn68IpevjWrj+5NUrRxPv1ubzp83pjMuJ8jGBhtRTOQ6I1w2vJ0vlXrJcab+76PEnkKoQ+iPB0BRA/a0W6jobJ+r6AyddrZaCUUPDJvSbVFKM0OfVjZlhCnJDPfbEuLe1uA3c/u72XxS56Ako2NOVHG65kT1d4YBD6/KZP42D2Ozgzx2Tv0x99/vabfwh/J0XtvlBuD0Aj/fLWthRArtRrO00slt7+YwwBXhjzP3MbAfvasskqwUQkl/FozAyzvc/O/GNGq8Vmxmg4uGefnPMW0pPS/03g+y+PdON0/N2MeEXLXixdPmJitXvzEQgNFZQb46qp2ZRb5+NypFYksh1CGk8gGQYcA+n/lzu9Ftb7Hijxw4VMZpiXYGTWGG7xc6DXBGVSobY+EoPLYmg+e3pOGxRrn71EbOPMiQQOkfDKPj3am/bEpneGaIx6fV9coQ042NNn67JoOPax2YMLhwmI9vjW9J+nde1zXY+O7SPCwmg9/PqGOUysZFkoJCKJGOY8BXd7r408Z0KtusWEwG5w/1cfXYVopTbOexcBQuXFiAy2rwz4v2pvSIgGSxvMpJpiNKWW5Q53sSEwqhDiFVDoAaA+buAeFdu9FVtNhoCx0YNtnMBsPSO3ajK91vblOBO6I/BnH26k4XD3yURTBqYs64Vq4b16qfST/09Po0nlqXwZC0ME9Mr+vVcmjDgPdqHPx2TQYVLTYclihXjmzn62PakrKVdk+7hW8uzqMpYOYXZzZwxiCFtyLJQiGUyKfCUVi828UzG9LY2WrDjMEXhvi4ZmwbwzJS482V92sc3PhWLleMaOP/TVErnkh/oBDqEJL1AKjWZ+bDvQ4+2OtgZa3jczvSWUwGRWnhzt3oOsKm0owwRWnhg+6sJYlhU6OVW9/JYY/XyhmD/Nx1SiPp/Xwr3/7kb5s9PLo6k0HuML+fXhezKqWIAa/scPGH8gzq/Bay7BGuG9fGl4a3Y0uS14e2kIn/WpJHRYuNH05uZvbI9ngvSUSOgkIokc+LGB0t5s9uSGdbsw0AhyWKx2rgthl4rFE8NgOPLYrbanT82xrt/JyB2xb93GWezstcFiOu1S4PftSxO/QT0+qYPCA151OKyIEUQh1CshwAecMmVtbau4OnHa227s/lOiOMzQ51BE2ZYUozQgxJD/ebbdlTTXPAxE/fz+aDvU6K08I8OLWB0hSa3yMH98I2N79cmcUAV4QnptUxuA/K8P1hE/+3xcOfN6bhDZsZ7AnznYktzCjyJ3RZdjgKN72dwwd7nXpHVSRJKYQSObSoAW9VO1lY4aYxYKY9ZMYbNtEeMuGLHNu7RSaMT4Or7hDrwIDLbfv8ZQcLvY52blDEgEtezMcELLxkr3avFeknFEIdQqIeAEUM2Nhg44PO0Km83k7Y6HjFdliiTBkQ5JT8AKfkByjNCCf0CaMcvYgBfyjv2LXCZYly+8lNzCz2x3tZEiP/3uHi3g+zyXZE+N20+j4vvW8MmHlmfRovbPMQMUyMzwnyvbKWhHyn0jDgoZWZLKjwcMYgPw+d0aCDWZEkpBBK5NiEo+ALmzpDKTPtnR+7QqrPXubd7zJv9+c6Lus6tzhaNrOBuyugsh4Yah1QldV5WVPAwu/WZnDZ8HZ+fEJzL39HRCRRKYQ6hEQ6AKpqs/D+Xgcf7nXwca2D1s55TiYMxmSHOLkzdJqYG9TOBf3E0kon936QhS9i5uujW/mvCa1qp0wxSyqd3PluNh6bwePT6hgZx8Hau9ss/H5tBksqXQCcVejjuxNbE2oexXObPPx2TSYjs0L8fnodbmu//fMlktQUQonEXzAC7WFzZyhlwtv1786PXUGXt/Oyjo+dodZ+l3nDJgyOHGg9dk4dJw1MvDe4RCQ2FEIdQjwPgFqCJj6u7ah0+nCvg6p2a/fnCtxhTskPcHJ+gJMHBsh09NsfUb+3vcXKT1bksLvNyskDA/zstEayHMm9o5l0WLHHwU9W5OCwGDx6Tj3jcxJju+Ly+o6d9FbXObCYDC4p8fLN8a3k9uKQ9GOxrMrJbe9kk+uM8j8z9yX9zn4i/ZlCKJHUETU6qrM+W23l3a8Cy22LcuFQn7o3RPoRhVCH0JcHQKEolNfbu0OnDQ02op3vGnisUU4cGOhusStKi+hFWrq1hUzc8342b+9xUuAO8+DURkZnJ0ZgIcfmw712fvR2LiaTwW/Oaki41jejcx7F42vT2dVqw2WJ8rXR7XxtdFtcqo/WN9j47rJczMAT0+sYnZ041VkicvQUQomIiKQ2hVCHEMsDIMOAHa3W7rlOq2rt3cMELSaD8Tmdc50KAozNDqnNSg4rasAzG9L4n3Xp2MzwkxObuHCYL97LkmOwus7OjctziBgmfnlGA6cWBOK9pEMKR+HF7W7+uC6dhoCFHEeEOeNbmVXi7bPXrBqvhW8uzqPRb+bBMxo4qzBxv18i0jMKoURERFKbQqhD6O0DoAa/mQ9rHd272O3zfTq8aUhamFMK/JySH+CEAUE8tn77bZfjsGKPg7vfz6YtZObyEW3cMKlFAWYS2dho43vLcvFHTNx/eiNnD06OgfPesIm/bfLw3KY0fBEzQ9JDzJ3YylmFsd1Jrz1k4ltL8qhosXHj5Ga+OrI9dncmIn1GIZSIiEhqUwh1CMd7AOSPwOp9n8512tJs6/5cpj3CyfnB7oHiBe7Yb7ku/cPuVgu3vJNDRYuNyXkBfn56Y9zn9ciRbWu28t1lebQGTdxzaiNfGJIcAdT+6nxm/md9Oi9udxMxTEzKC/C9shYm5PZ+e2g4Cj9ekcN7NU6+Mrydm6Y0q01ZJEUohBIREUltCRVC3XzzzbjdbgAGDhzIZZddxuOPP47JZKK4uJg5c+ZgNptZtGgRixYtwmKxcNlll3HiiScSDAZ59NFHaWlpweVyMXfuXDIyMti8eTPPPvssFouFsrIyZs+e3aO1HO0BUNSALU1WPtzr5IO9DlbX2QlGO86KbGaDSXnB7rlOI7NCmHXCJDHiDZu4/8MsFle6yHNGeGBqQ0yCAOkdu1otfGdpHg0BC7ef1MjFJcndSrmjxcoTa9NZXt2xk970Ih/fmdBCcXrvhO2GAb9alckL2zycXuDnF2c0qOJPJIUohBIREUlthwuhrIf8TAwEgx3Dd+++++7uyx566CGuvPJKxo8fz5NPPslHH33EqFGjeOWVV3jwwQcJhULceeedlJWV8frrrzNkyBCuuOIKVqxYwfz587n22mt56qmnuOmmm8jPz+fBBx+koqKC0tLSXllzrdfcPdfpo1oHjYFPW+xGZIa6K50m5wVxartw6SNuq8G9pzUyZnOQJ9Zk8J2ledx0QjNfKvXGe2nyGXvaLXz/zY4A6qYpTUkfQAEMywjz0BmNfLKvnd+uyWBppYvlVU6+PLyd68a1kX2cOzj+3xYPL2zzMCIzxL2nNSqAEhERERFJEX0aQu3cuZNAIMDPf/5zIpEIV111FRUVFYwbNw6AKVOmsHr1asxmM6NHj8Zms2Gz2SgoKGDnzp1s3LiRWbNmdV93/vz5eL1ewuEwBQUFAEyaNIny8vJjDqHaQyZW7vv/7d17dFT1vffxz2QmyczkQkxAkgl3wUDQcNOQhKvgQs9zShUBi1KfQmuRp4CIemhtm9O0FoUj1XI7irQiVLGtgvRoi22JgoFg5X4ziCmIbUIg99vcM3P+SJvqI8GozEwy836txR/Z2Tv5/rKyhu988tvfHdM21+lc479usetubtG/9bVrdE+Xbujp4hYohJTBIH09o1nXJnn0n+9cpRUHk1RSE60HR9Qr1vjZ1yPwKh1RWrQ7RRcdRi24vkEzBoZXSDi8h1sbJlXpzb+b9fTxRL1SGq8/fGjVPYObNGtQ8xcK5neXmbXmaKK6m1v0s7HVzM8DAAAAwkhQQ6jY2FhNnTpVkydP1vnz5/X4449Lkgz/GPRhsVhkt9tlt9vbbtn7+HGHw9F23Gw2tx2zWCxt55rNZl28eLFD9dhsNnl90rELUtFH0p6PpEMVrbNIJMlikm7qJ43r0/pvULJRBoNVkvVyXxYIqttt0qhrpPtel/7nbJw+ssfp6X+XbAmhriyyVdulBwulsmbp/mzpodxESYmhLisg7kmXvnaD9OJxafW7UVp/IlHbzybqoVxpxhDJ2MGdTMcvSD9+VzKbpOdvN+r6nqmBLRxAyFxumz4AAAhfQQ2h0tLSlJqaKoPBIJvNpvj4eJ05c6bt8w6HQ3FxcbJarXI6nZ86brFY2o47nc62Yw7Hv25vcTqdnwiwLuf/vuLQwYuxavK0vkMyyK/BV3la5zqlunR9ilvR/3zz5JLOn/+SPwAgQIyS1o6T/utgknacs+r/vNiin+bWamQPd6hLi0gNboMW7uqu0vpo3XVtk2b1aVAkjD+55WppzC0GvXAqXi+djtfSnQY9865HC7IalJvquuxg8Qv2KN1b2ENOb5SW59UqpcUZET8zIBIxEwoAgPB2uT82BXXSxltvvaXNmzdLkmpqauRwODRs2DCdPHlSknT48GENGTJEAwcOVElJidxut+x2u8rKytS7d29lZGTo0KFDbecOHjxYVqtVJpNJFRUV8vv9Onr0qIYMGdKhenaXWZQQ7dNtA5q1LLdGO26r0HM3V2n+9Y0a2eNjARTQBZiNUv6NdXpwRJ0a3FG6f3eKfn06TpH7/MvQaPYY9GBRij6oj9a0Ac1alNUQUU91i4/2a/71jXr53y7o3/vZdbbBpIf2pGjR7hSdqo2+5DXNHoMe3pOiKqdRi4Y1aHx613tyIAAAAIDPFtSn43m9Xq1bt05VVVUyGAyaPXu2EhIStH79enm9XqWnp2v+/PltT8crLCyUz+fTtGnTlJOTI5fLpXXr1qm2tlYmk0mLFy9WUlKSTp8+rU2bNsnn8ykrK0t33XVXh+r5y+kL6hXXElFvEBEZjlTG6Af7rlKNy6gpfex6ZFQ9g/ODwOk1aElRso5UxerWvnbl31gX8U/JLK036b+PJWpfhVmSNKWPXfdd1yhbXOuT9Lw+aeneZO2rMOuOa5r18Ih6XpOBMMdOKAAAwtvldkIFNYTqbGiAEM4uOqL0g+JknaiJ0aBuHj2eV6P0+JZQlxW23C2tYcpfLph1Uy+HfjKap7p93P4LMVp3LFHv18UoOsqvGQOb9Y0hjdpwIlFb/xqnnFSnnhhTw88MiACEUAAAhDdCqHbQACHcuVuknx/pplfPxCkh2qef5NQqJ9UV6rLCjtcn/WDfVXq73KK8NKeW59VwO+8l+PzSn/9m0TPHE1RhN8ls9MnZEqVrunm0/qYqnoQHRAhCKAAAwlunmQkFILhijNLSUfX6/g21crYY9GBRsjaVxDMn6gpq8Us/eTdJb5dbNOpqlx7LJYBqT5RBuqWPQ7++9aIWZdUrOkrqbm7RyrE1BFAAAABABGAnFBAh3quJ1iPFybroMGpCukP5N9bxxv9L8vml5Qe76bWzcbo+xa2fj6+WldlbHeb0GtTiF7+HQIRhJxQAAOGNnVAAlJns0cabKzWyh0u7yyy6t7C7zjUaQ11Wl+X3S6uOJOq1s3HKSHLryXEEUJ+X2eQngAIAAAAiCCEUEEGSzT6tGl+tWYOa9GFjtL61s4eKymNDXVaX9MyJBP22NF4DEj36+fgaxROmAAAAAMBlEUIBEcYUJS0e3qCC0bXy+qWle1P07IkE+chQOuz5knhtPpWg3vFerZ5QraRYX6hLAgAAAIBOjxAKiFC39HFow6Qq2eK82liSoP/Yk6wGtyHUZXV6vz4dp/UnEpVq9WrNhCqlmAmgAAAAAKAjCKGACDYoyavnbq7U6J5OFVeY9c2dPVRabwp1WZ3W785YtepoN3U3t2jNhGr1tBJAAQAAAEBHEUIBEa5bjF8/G1ejbwxuVFmzSd8u7K6dfzOHuqxO541zFq042E1JMS1aPaFaveJbQl0SAAAAAHQphFAAZDRI869v1ON5NYoySPnvJGv10UR52egjSdr1d7N+uj9J8dF+rZpQrf6J3lCXBAAAAABdDiEUgDYT05365eQq9Unw6KXT8XqgKEWVjsh+mdh3Plb571ylWKNfT46r1rVJBFAAAAAA8EUY/H5/xD4Tq7y8PNQlAJ1Ss8egn7ybpLfLLTLIr8xkj/LSnBqT5tS1SV4ZImR++aGLMVpSlCJJemp8tUb2cIe4IgDo+mw2Gz0YAABhzGaztfs5QigAl+Tztw7i/tNHFh2vjlGLvzV56m5u+Ucg5dINPV2ymsLzJeR4dbQW706Rx2fQf42tUW6qK9QlAUBYIIQCACC8EUK1gwYI6JgGt0HvXojV3nKz9lXEqt5tlCRFR/k1sodLY9JcyktzKj1MhnW/XxuthbtT5PAatCy3VhPSnaEuCQDCBiEUAADhjRCqHTRAwOfX4pfeq4nW3nKzis+b9UF9dNvn+iZ4NCbNpTFpTmV1d8vUBcdJnak36Tu7UtTgjtKPRtfplj6OUJcEAGGFEAoAgPBGCNUOGiDgy7tgj1Lx+dZAav/FGLlaWpOn+GifRvds3SGVm+bSVbGd/1F7f2sy6jtvdVeV06hHRtXpqwPsoS4JAMIOIRQAAOGNEKodNEDAleVskQ5fjNXe82YVn4/VebtJkmSQX0P/Mdw8r5MONz/fbNR3dqWowm7SkuH1unNQc6hLAoCwRAgFAEB4I4RqBw0QEDh+v/Rho0l7y83aez72E8PNe1halJfqVF6aSzf2dMkS4uHmVY4o/b9d3fX3JpPmX9egbwxpCmk9ABDOCKEAAAhvhFDtoAECgqfBbdBfKmJVfP6Tw81jovwaEcLh5rWuKC3YlaKzDdGaM6RR913XGNTvDwCRhhAKAIDwRgjVDhogIDRa/NLJ6ui2WVIfH27eL8GjvCANN290G7Rwd4pO18XozkFNemBYQ6e7TRAAwg0hFAAA4Y0Qqh00QEDnEIrh5navQYvfTtGJ6hjd1r9Z3x1VTwAFAEFACAUAQHgjhGoHDRDQ+XRkuPkYm1ODun3x4ebOFunhohQdrIzVLX3sys+uk5EACgCCghAKAIDwRgjVDhogoHPz+6WzDSYVn79yw83dLdL3ipO1r8KsCekO/TSnNqC3/AEAPokQCgCA8EYI1Q4aIKBr+bLDzb0+Kf+dq7SrzKKcVKdW5NUoxhjMFQAACKEAAAhvhFDtoAECuq4ODTe3OZWV0jrc3OeXHn03SW98ZNXIHi79bFy1zARQABB0hFAAAIQ3Qqh20AAB4eOzhpv7JL31d4uuS3br5+OrFRcdsS99ABBShFAAAIQ3Qqh20AAB4am94ebXJrm1dkK1EmIi9mUPAEKOEAoAgPB2uRDKFMQ6ACAozEYpN82l3DRX23DzE9UxmtDLQQAFAAAAACFCCAUgrBkM0oBuXg3o5g11KQAAAAAQ0XgwOQAAAAAAAAKOEAoAAAAAAAABF9Tb8bxer55++mlVVlbK4/Fo+vTpSk5O1ooVK5SWliZJmjJlivLy8rRz507t3LlTRqNRd9xxh0aNGiW3263Vq1eroaFBFotFCxYsUGJiok6fPq3nn39eRqNRWVlZmjlzZjCXBQAAAAAAgM8Q1BCqqKhICQkJWrRokRobG7V06VLNmDFDX/nKVzR16tS28+rq6rRjxw4tX75cHo9H+fn5ysrK0p/+9Cf16dNHd955p/bu3autW7dq7ty52rBhgx566CH17NlTy5cv15kzZzRgwIBgLg0AAAAAAACXEdQQKjc3Vzk5OW0fG41GnTlzRuXl5Tpw4IBSU1M1Z84clZaWKiMjQ9HR0YqOjlZqaqrOnTunU6dO6atf/aokacSIEdq6davsdru8Xq9SU1MlScOGDdOJEycIoQAAAAAAADqRoIZQZrNZkuRwOPTkk09q1qxZ8ng8mjx5sgYMGKBt27bp5ZdfVr9+/WS1Wtuus1gsstvtcjgcbcfNZnPbMYvF8onvcfHixQ7VY7PZruDqAAAA0BH0YAAARKaghlCSVFVVpZUrV2rKlCkaO3asmpubFRcXJ0nKzs7Wc889p8zMTDmdzrZrHA6H4uLiZLFY2o47nc62Yw6Ho+1cp9P5iQDrcsrLy6/gygAAAPBZbDYbPRgAAGHscn9sCurT8erq6rRs2TLNnj1bkyZNkiQtW7ZMpaWlkqTjx49rwIABGjhwoEpKSuR2u2W321VWVqbevXsrIyNDhw4dkiQdPnxYgwcPltVqlclkUkVFhfx+v44ePaohQ4YEc1kAAAAAAAD4DAa/3+8P1jfbuHGjiouLlZ6e3nZs1qxZeuGFF2QymZSUlKR58+bJarVq586dKiwslM/n07Rp05STkyOXy6V169aptrZWJpNJixcvVlJSkk6fPq1NmzbJ5/MpKytLd911V4fq4a9wAAAAwcVOKAAAwtvldkIFNYTqbGiAAAAAgosQCgCA8NZpbscDAAAAAABAZCKEAgAAAAAAQMBF9O14AAAAAAAACA52QgEAAAAAACDgCKEAAAAAAAAQcIRQAAAAAAAACDhCKAAAAAAAAAQcIRTwJW3fvl3z5s2T2+0OdSkIYwUFBSorK7vk5xYsWMDvHz63ixcvauXKlSooKFB+fr5+8YtfyOFwXPLcqqoqHThwIMgVAsDl0YMhGOjBcKVFeg9GCAV8SXv27FFeXp6Ki4tDXQoAdIjb7daKFSt02223qaCgQI8++qgGDhyoVatWXfL8EydO6P333w9ylQBwefRgALoaejDJFOoCgK7s5MmT6tmzp6ZMmaI1a9Zo4sSJKigokM1mU3l5ufx+v5YsWaKysjK9+OKLMplMuvnmmzV+/PhQl44u6OWXX1ZmZqamTJmisrIybdiwQQUFBaEuC13QoUOHlJmZqUGDBrUdmzhxov785z+rvLxc69evl9frVWxsrO6//35t375dLpdLGRkZuuGGG0JYOQC0ogdDMNGD4UqhB4uQEKqgoEDf/va3lZ6eHupSEGYKCws1efJk2Ww2mUwmffDBB5KkjIwMzZs3T3/84x+1bds2jR49Wh6PR4899liIKwYA6cKFC+rZs+enjvfo0UOPPPKIlixZouHDh6u4uFjnzp3T7bffrrKysrBpfhA89GAIFHowAF0RPViEhFBAIDQ1Nenw4cNqaGjQjh07ZLfb9cYbb0iSrrvuOkmtjdA/7+FNS0sLWa3ompxOp0wmk0ymT79U+/3+EFSEcJGcnKzS0tJPHa+oqJDb7da1114rScrLy5Mk7dq1K5jlAcBl0YMh0OjBECj0YBEUQjU2Nmr58uXyeDxqamrS9OnTlZ2drYcffliZmZk6d+6cDAaDli5dKqvVGupy0QUUFRVp0qRJuueeeyRJLpdLCxcuVEJCgs6cOaOUlBSdOnVKvXr1kiRFRTGCDZ/P2rVrdeuttyozM1P19fXKyspSXV2dJOns2bOhLQ5d2o033qht27aptLRUAwcOlNS6qyAxMVEjR45UaWmpsrKyVFRUpKamJlmtVppufGH0YLjS6MEQaPRgCBR6sAgKoT788ENNnTpVQ4cO1fvvv6/f/va3ys7OlsPh0JgxY/TNb35Tq1ev1uHDhzVmzJhQl4su4M0339TChQvbPo6NjdXo0aNVWFioXbt26fXXX5fZbNbChQv10UcfhbBSdFVTp07Vxo0bFR0drYkTJyo3N1dPPfWUSkpK1L9//1CXhy7MbDbru9/9rjZt2qSmpia1tLSoT58+Wrx4sRobG/Xss89q27Ztio2N1aJFi1RZWalt27apf//+/B+Jz40eDFcaPRgCjR4MgUIPJhn84Rar/cPHt1AWFBRozpw52r59u4xGowwGg6qqqlRQUKAFCxboqaeeUkxMjF588UWlp6dr4sSJoS4fXRjzLwAAkYweDKFCDwYAnV/Y7k1du3atTp06JZ/Pp/r6em3atEkTJkzQokWLNHTo0LDb0gYAANAZ0IMBAID2hO3teP//FsqUlBRt3LhRr776qlJSUtTY2BjqEhGmeFwrACCS0YMhVOjBAKDzC9vb8QAAAAAAANB5hO3teAAAAAAAAOg8CKEAAAAAAAAQcIRQAAAAAAAACLiwGkzu9Xr19NNPq7KyUh6PR9OnT1evXr20bt06GQwG9e7dW9/61rcUFdWavTU0NOiHP/yhVq5cqZiYGDU1NWnNmjWy2+1KSEjQfffdp27duoV4VQAAAJ3b5+nBXn/9dRUXF0uSRowYoZkzZ8rtdmv16tVqaGiQxWLRggULlJiYGOJVAQCAKy2sQqiioiIlJCRo0aJFamxs1NKlS9WvXz/NmjVLQ4cO1bPPPqsDBw4oOztbR44c0ZYtW1RfX992/bZt25SRkaE77rhDx44d00svvaT58+eHcEUAAACdX0d7sL59+2rPnj167LHHJEk/+tGPlJ2drePHj6tPnz668847tXfvXm3dulVz584N8aoAAMCVFla34+Xm5uprX/ta28dGo1FnzpxRZmampNa/th07dkySFBUVpfz8fMXHx7edX1ZWphEjRkiSBg8erFOnTgWxegAAgK6poz1YSkqKvv/97ysqKkpRUVHyer2Kjo7WqVOnNHz48LZzjx8/HoplAACAAAurEMpsNstiscjhcOjJJ5/UrFmzJEkGg0GSZLFYZLfbJUlZWVlKSEj4xPV9+/bVgQMHJEkHDhyQy+UKYvUAAABdU0d7MJPJpMTERPn9fm3evFn9+/eXzWaTw+GQ1Wpt+1r/7NcAAEB4CasQSpKqqqr04x//WOPGjdPYsWPbmh9JcjgciouLa/faadOmqbKyUo8++qiqqqrUvXv3YJQMAADQ5XW0B/vn/Cen06l7771XUmtI5XQ6JUlOp/Oy/RoAAOi6wiqEqqur07JlyzR79mxNmjRJktSvXz+dPHlSknT48GENGTKk3etLSko0fvx45efn6+qrr1ZGRkZQ6gYAAOjKOtqD+f1+PfHEE+rbt6/mzZvX9rCYjIwMHTp0qO3cwYMHh2YhAAAgoMJqMPmrr76qpqYmbd26VVu3bpUkzZkzRxs3bpTX61V6erpycnLavd5ms2nt2rWSpOTkZIaSAwAAdEBHe7D9+/frvffek8fj0ZEjRyRJd999t6ZMmaJ169YpPz9fJpNJixcvDuFqAABAoBj8fr8/1EUAAAAAAAAgvIXV7XgAAAAAAADonAihAAAAAAAAEHCEUAAAAAAAAAg4QigAAAAAAAAEHCEUAAAAAAAAAo4QCgAAoBN45513VFBQcNlzXnnlFe3fvz84BQEAAFxhhFAAAABdxIkTJ9TS0hLqMgAAAL4QU6gLAAAAiFS/+c1vtGfPHsXHxystLU2SVF5erl/+8pdyOp2qra1Vv3799MADD+jNN9/UX//6V/3qV79SVFSURo4cqRdeeEElJSXy+Xzq16+f5s6dK6vVGuJVAQAAXJrB7/f7Q10EAABApNm/f79eeuklLVu2TDExMXriiSfkdDp1zTXXqG/fvho/fry8Xq++973vacaMGcrJyVFBQYFuvfVW5eTk6JVXXpHD4dDXv/51GQwGbdmyRXa7Xffee2+olwYAAHBJ7IQCAAAIgePHjys7O1sWi0WSdNNNN2nHjh2aPXu2jh07pt/97nc6f/68amtr5XQ6P3X9wYMHZbfbdezYMUmS1+tVt27dgroGAACAz4MQCgAAoBMwGo2SpFWrVqmlpUV5eXkaOXKkqqqqLnm+z+fTnDlzNGLECEmS0+mU2+0OWr0AAACfF4PJAQAAQmD48OHat2+fmpub5fP59Pbbb0uSjh49qhkzZigvL0+S9MEHH8jn80lqDaq8Xq8kadiwYXrjjTfk9Xrl8/n0zDPPaMuWLaFZDAAAQAcwEwoAACBEtm/frsLCQsXHx6tv376qqKhQbm6uXnvtNcXGxspqtSo+Pl69e/fW3XffrT/84Q/6/e9/r5kzZyovL0+bN2/We++91zaYfN68eQwmBwAAnRYhFAAAAAAAAAKO2/EAAAAAAAAQcIRQAAAAAAAACDhCKAAAAAAAAAQcIRQAAAAAAAACjhAKAAAAAAAAAUcIBQAAAAAAgIAjhAIAAAAAAEDA/S9SW2g52XSB4QAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 1440x432 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.style.use('ggplot')\n",
    "df2c['units'].groupby('date').agg(sum).plot(figsize=(20,6), c='dodgerblue')\n",
    "\n",
    "plt.title('Units sold per month')\n",
    "\n",
    "plt.ylabel('units')\n",
    "plt.xlabel('date');"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 27,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 364
    },
    "id": "VkIOHaECB4pE",
    "outputId": "3635b989-198a-4e35-c8ee-4b9ad307602f"
   },
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAABI0AAAGNCAYAAACc8IGTAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMSwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy/YYfK9AAAACXBIWXMAAAsTAAALEwEAmpwYAACLJ0lEQVR4nOzdd3zdddn/8dfZI3unSbppSyelu0AnZUgZAvITBBFBQQS9BVyACIgsGSogS2Uqot4MbwFBoBvoXrR07ybNzsk8+3x/f2S0pdCmbU7OyPv5ePRRmnHORdok37y/13V9TIZhGIiIiIiIiIiIiBzAHOsCREREREREREQk/ig0EhERERERERGRQyg0EhERERERERGRQyg0EhERERERERGRQyg0EhERERERERGRQyg0EhERERERERGRQyg0EhERkaiZOXMmQ4YMOejXmDFjuPzyy1m7dm2sy5NOMgyDf/zjH/j9fgBef/11Jk6cGOOqREREJNoUGomIiEhU3XzzzSxatIhFixaxcOFCXnjhBWw2G9/97ndpbm6OdXnSCcuWLeOOO+4gFArFuhQRERHpRgqNREREJKpSUlLIy8sjLy+P/Px8Ro0axQMPPIDH42Hx4sWxLk86wTCMWJcgIiIiMaDQSERERLqd3W4HwGKxdLzsz3/+MzNmzODkk0/msssuY/Xq1QB88sknDB8+nLq6uo63ra2tZfjw4axcuRKA+fPnc8EFFzBq1Chmz57Na6+91vG2r7/+OhdddBF//OMfOe2005g4cSI//vGPaWlpAeDxxx/noosuOqi+b37zmzz44IMdfz7c43/e66+/zgUXXMAzzzzDhAkTmDRpEo8++iiRSKTjbdasWcOll17KyJEjOfPMM/njH//Y8frXX3+dCy+8kB//+MeMGTOGJ5988pDnePzxx/nBD37Aww8/zNixY5k0aRIvvfQSy5cv57zzzmP06NF85zvfwePxdLzPokWLuOSSSxg9ejQzZszgT3/6U0cYdLiP0d69e7nyyisBGDNmDK+//vpBf2ennXYao0eP5oc//CGNjY1f+nERERGRxKPQSERERLpVXV0dv/jFL8jLy2PcuHEAvPrqq7z00kvceeedvPHGG0ybNo1vfetb7Nmzh4kTJ5KVlcUHH3zQ8RjvvfcehYWFjBkzhi1btvDDH/6QSy+9lLfeeosbbriBBx98kLfffrvj7Tdv3syKFSt4/vnn+fWvf83777/Pq6++2ql6O/P4n7dt2zbmzp3Liy++yP3338/f//73jvCnpqaGa665hilTpvDvf/+b22+/nVdeeYU//elPHe//2WefkZKSwhtvvMFXv/rVL3yOuXPn0tLSwhtvvMGll17KAw88wD333MOdd97Jn//8Z9avX8+LL74ItI6XXXvttcyYMYM33niDm266iSeffJJXXnnliB+jXr168fjjjwPwwQcfcM455wDg8XhYtmwZzz//PM8++yxLlizh2Wef7dTHVERERBKDNdYFiIiISHJ74IEHeOSRRwCIRCKEw2HGjRvH888/T2pqKgDPPPMMt9xyC9OnTwfge9/7HkuXLuWVV17hZz/7GbNnz+Y///kPl1xyCQDvvPMO5557LgB/+tOfOO+887jssssA6NOnD7t37+bPf/4zs2fPBiAYDHLPPfeQl5fHoEGDmDJlCuvXr+9U/Z15/M8Lh8M8/PDDlJSUMHToUK6//nr++Mc/csMNN/DXv/6VkSNHcsMNNwDQr18/br75Zn79619z7bXXdjzGjTfeSF5e3pfW5XA4uO2227BarXzzm9/kqaee4oorrugI4qZNm8bWrVsBePnll5kyZQrf//73Aejfvz/l5eU8/fTTXH755Yf9GFksFjIyMgDIzs7G6XQCYDKZuO+++8jOzgZg1qxZbNy4sVMfUxEREUkMCo1EREQkqq677jrOP/98AoEAr7zyCu+//z433ngjgwYNAqC5uZmysjLuuOMO7rzzzo73CwQCHWNs5557Lpdeeim1tbWEQiGWL1/OL3/5S6C1E2jz5s0Hdf6EQiGs1v2XOe17ldqlpqZ2jKcdSWce//N69epFSUlJx59HjRpFdXU1dXV1bN26laVLl3LyySd3vD4SieDz+TpG8Fwu12EDI4Di4uKOGtqDnAOf0263dzzeli1bOP/88w96/7Fjx/LII4/Q0NAAHP3HKC0trSMwAkhPT2f37t2HrVlEREQSS8KFRlu2bOGvf/0rd9111xe+fvXq1bz55ptA69LGjRs38sgjjxx0ESUiIiLdJysri759+wJw5513Ultby/XXX8///d//0atXr45dPg888ADDhg076H3bw5CRI0fSu3dv3n//ffx+P4MHD+4IncLhMN/85je59NJLv7QGm832pa8zmUyHvOzAU8I68/ifd+CuJqDj/9FsNhMKhTjzzDP50Y9+dMj7paWlAa1dREfyRaGV2fzFmwfaP44Hat9n1F7b4T5GX+TLnktERESSR0J9t//Xv/7F008/TTAY/NK3GT16NHfddRd33XUXY8eO5YILLlBgJCIiEkfuvPNOLBZLxw2gtLQ08vLyqKiooG/fvh2//vKXv7Bw4cKO9zv33HOZM2cO77//Puedd17HywcOHMiuXbsOet/20bbOsNlsNDU1dfzZMAz27t17XI+/b98+amtrO/786aef0qtXLzIzMxk4cCDbt28/6PG2bdvGH/7wh6gFMQMGDOhYLN5u1apV5OTkdIyeHc4XBWsiIiKS/BIqNCooKODHP/5xx593797N3XffzV133cXDDz98UAt1TU0NCxYs6Nh9ICIiIvEhOzubW265hXnz5nUst/7Od77Dk08+yTvvvMOePXt48skn+etf/0r//v073u+8885j8eLFrFq16qBdQldffTXz5s3j6aefZteuXbz33nvcd9995OTkdKqekSNHsmvXLl555RV2797NfffdR319/XE9fjAY5NZbb2XLli18+OGHPP300x0nkF1++eXs2rWLX//612zfvp2PP/6YX/7yl7hcrqiFRt/5zndYuHAhTz75JDt37uSdd97h2Wef5Zvf/GanAiG32w3A+vXraW5ujkqNIiIiEn8Sajxt0qRJVFZWdvz5mWee4frrr6ekpIQ5c+bwr3/9q2NJ5VtvvcXs2bOPutVaREREou9rX/sar7/+Ovfddx+nnnoqV155JT6fj4ceeojq6mr69evHY489xtixYzvep2/fvgwePBiHw0GvXr06Xj5ixAgee+wxHnvsMZ544gny8vK49tpr+e53v9upWiZPnsy1117L73//ex599FEuvvjig0KpY3n8zMxMRo4cyaWXXorb7eaaa67h29/+NgCFhYX86U9/4uGHH+aCCy4gIyODc84556AbY11t6NChPP744/z+97/nySefpLCwkO9///tcddVVnXr/wYMHM2PGDK6++mpuueWWTnUniYiISOIzGe0D7QmisrKS3//+99x7771861vf6rgDGQ6H6dWrF9///veJRCLcdNNNPPTQQx0LNEVERES6w+uvv86DDz7IkiVLYl2KiIiIyHFJqE6jzysqKuLGG28kNzeXjRs34vF4ANizZw9FRUUKjEREREREREREjlFCh0bf/e53eeKJJzpO/fje974HQFlZGQUFBbEsTUREREREREQkoSXceJqIiIiIiIiIiERfQp2eJiIiIiIiIiIi3UOhkYiIiIiIiIiIHCKhdhqVlZXFugQRERGRHqWoqEjXYCIiIkmsqKjoS1+nTiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERERERERETmEQiMRERGRLvT+bif3LM0kFIl1JSIiIiLHR6GRiIiISBcxDHh2fTrv7HKzutoe63JEREREjotCIxEREZEusqPByt4mKwDz9rpiXI2IiIjI8VFoJCIiItJF5pc6O/57QZmTiBHDYkRERESOk0IjERERkS6yoMyJ1WQwrdhLldfChlpbrEsSEREROWYKjURERES6QHmLhY11dsbm+5ndrwWAeQd0HomIiIgkGoVGIiIiIl1gYVtANLXYx/gCPy5LhHmlLgyNqImIiEiCUmgkIiIi0gXa9xlNKfLhtMDkXn72NlnZ1mCNcWUiIiIix0ahkYiIiMhxqvebWF1tZ0R2gDxXBIDpxV4A5u/ViJqIiIgkJoVGIiIiIsfpo31OwoaJqcW+jped0suPzWwwv9QVw8pEREREjl1U+6Xr6+v5+c9/zi9+8QuKi4s7Xv7WW28xZ84c0tPTAbj22mspKiqKZikiIiIiUTO/Y5+Rt+NlKTaD8QV+Pt7nZG+ThZLUcKzKExERETkmUQuNQqEQzz77LHa7/ZDXbd++nRtvvJEBAwZE6+lFREREuoUvZGJJhYN+aUH6ph0cDE0r9vHxPifzS51cPqQ5RhWKiIiIHJuojae9/PLLnHHGGWRlZR3yuh07dvDGG29wxx138MYbb0SrBBEREZGoW1LhwB82HzSa1m5KkQ8zBvM0oiYiIiIJKCqdRvPmzSM9PZ3Ro0fz5ptvHvL6U045hbPOOgu3281DDz3EihUrGDt27BEfVyNsIiIiEm+Wr2v9/WsnpVFUmHbQ64qACSWweK8dS3oRBandX19X0DWYiIhIz2QyDMPo6ge98847Wx/cZGLnzp306tWLn/3sZ2RmZmIYBl6vF7fbDcB7771HY2MjX/va1474uGVlZV1dqoiIiMgxC0Vg9r8LcVgM3pxdgdl06Nv8c0sKj67O4Mcne7j4hJbuL/I4FRUV6RpMREQkiR3u5lBUxtPuvvtu7r77bu666y769evHjTfeSGZmJgBer5dbbrkFn8+HYRisW7dOu41EREQkIa2pttMQMDO1yPeFgRHsX46tU9REREQk0UT19LQDLVq0CJ/Px6xZs7jsssu4++67sVqtjBw5kjFjxnRXGSIiIiJd5otOTfu8AneEYdkBVlbZqQ+YyLB3eZO3iIiISFREZTwtWtQaLSIiIvHCMODCt/NpCZl55/xyrIfp335pYypPfZrOL8bXMbvflwdM8UjjaSIiIsmt28fTRERERJLdJo+NCq+VU3v5DhsYAUzvGFFzdkNlIiIiIl1DoZGIiIjIMWgPgKYV+474tn3SwgxID7Kk3ElL6EuWH4mIiIjEGYVGIiIiIsdgQakTu9lgYqG/U28/rdhHIGLik32OKFcmIiIi0jUUGomIiIgcpT2NFrY32JhY6MNl7dx6yOklGlETERGRxKLQSEREROQozS9rOzWt6Mijae0GZYQoSgnx0T4ngXC0KhMRERHpOgqNRERERI7SglIXZgxOK+rcaBqAydQ6otYSMrO8UiNqIiIiEv8UGomIiIgchRqfmXU1Nk7KC5DpiBzV+7YvzZ6nETURERFJAAqNRERERI7CwjInBqajGk1rNzInQI4zzMJSJ6Gjy5tEREREup1CIxEREZGjsKCtS6i9a+homE2te5A8AQtrq+1dXZqIiIhIl1JoJCIiItJJzUETyysdDMoM0ivl2LZZTy9pDZt0ipqIiIjEO4VGIiIiIp30SbmDYMTEtGLvMT/GmDw/abYI80pdGEYXFiciIiLSxRQaiYiIiHTS/FIXANOOYZ9RO6sZTi3yUem1sKHO1lWliYiIiHQ5hUYiIiIinRAIw8f7HBSnhBiYETqux5quU9REREQkASg0EhEREemEFZUOWkJmphb7MJmO77EmFvhxWiLM26sRNREREYlfCo1EREREOmF+2bGfmvZ5TqvB5EI/e5qs7GiwHvfjiYiIiESDQiMRERGRIwgbsLDUSZYjzIicQJc85jSdoiYiIiJxTqGRiIiIyBGsr7FR67cwpciH5ThH09qd2suH1WRor5GIiIjELYVGIiIiIkfQfmra1C4YTWuXajMYV+Bns8dOWbOlyx5XREREpKsoNBIRERE5DMNoHSFzWyOMy/d36WO3n6KmETURERGJRwqNRERERA5je4OV0mYrkwr9OLq4IWhKkQ8TBvP2KjQSERGR+KPQSEREROQwFpR23alpn5ftjHBSboBPa+zU+HRZJiIiIvFFVyciIiIihzG/1InVZHBKr64PjQCml/gwMHWEUyIiIiLxQqGRiIiIyJcob7GwyWNnbL6fVJsRleeYpr1GIiIiEqcUGomIiIh8ifbun648Ne3zCt1hTswKsLzSQUPAFLXnERERETlaCo1EREREvkR7aDSlKHqhEbR2G4UNEx/tU7eRiIiIxA+FRiIiIiJfoN5vYnW1nRHZAfJckag+1/S2TiadoiYiIiLxRKGRiIiIyBdYtM9J2DBFdTStXb/0EP3Sgiwud+INaURNRERE4oNCIxEREZEv0D6aNq3Y2y3PN73ERyBiYkm5o1ueT0RERORIFBqJiIiIfI4vZGJJhYN+aUH6pIW75Tk7RtR0ipqIiIjECYVGIiIiIp+zpMKBP2xmWjeMprUbnBmk0B1iUZmTYHRXKImIiIh0ikIjERERkc+Z39bt0x37jNqZTK2nqDWHzCyv1IiaiIiIxJ5CIxEREZEDhCKwqMxJnivM0Kxgtz53+4jafJ2iJiIiInFAoZGIiIjIAVZX22kMmpla5MPUzQeZjcwNkOUIs6DMSdjo3ucWERER+TyFRiIiIiIH6O5T0w5kMbWOxNX5LXxabe/25xcREZGexXeE8z4UGomIiIi0MYzW0CjNFuHkvEBMatApaiIiItJd7l+eedjXKzQSERERabPJY6PCa+XUIh/WGF0ljc33k2qLML/UiaERNREREYmSOr+ZD/e4Dvs2Co1ERERE2rSfmjatqPtOTfs8mxlO7eWjvMXKJo8tZnWIiIhIcntvl4uwcfgFjgqNRERERNosKHViNxtMLPTHtI6OETWdoiYiIiJRYBjw9k43VtPh25oVGomIiIgAexotbG+wMbHQh8sa27mwiYV+HJaI9hqJiIhIVGz22Nhab+O0I3RXKzQSERERAeaXtQY0U2M4mtbOZTWYVOhnV6ONnQ3WWJcjIiIiSeatna27jGb3azns2yk0EhEREQEWlLowY3BaUWxH09rpFDURERGJBn8Y3tvlJscZZtIRRvIVGomIiEiPV+Mzs67Gxkl5ATIdkViXA8ApvXxYTEbHcm4RERGRrrCwzElj0MzZfb1HPC1WoZGIiIj0eAvLnBiYmFYc+9G0dul2g3H5fjbW2dnXbIl1OSIiIpIk3t7pBuDcI4ymgUIjERERkY5unnjYZ3Sg9hBL3UYiIiLSFSq9ZpaWOxieHaBfeuiIb6/QSERERHq05qCJ5RUOBmcG6JUSjnU5B5la7MOERtRERESka/xnp5sIpiMuwG6n0EhERER6tI/3OQgZJqbG0WhauxxnhFG5AdZU26n16bJNREREjp1htI6m2c0GZ/Txdup9dPUhIiIiPdqCstYjZ+Npn9GBphX7MDCxsEzdRiIiInLs1tbY2dNkZXqJl1Sb0an3UWgkIiIiPVYg3NppVJwSYmAn5vpjYXpbmDVPI2oiIiJyHN7e2XqjrLOjaRDl0Ki+vp7rr7+e0tLSg16+fPlybr31Vm6//XY++OCDaJYgIiIi8qVWVDpoCZlbdweZYl3NF+uVEmZwZoDlFQ4aA3FapIiIiMQ1b8jEh3tcFLpDjMsPdPr9ohYahUIhnn32Wex2+yEvf/HFF7n99tu5++67+fDDD/F4PNEqQ0RERORLtS+YjtfRtHbTi32EDBMf71O3kYiIiBy9uXudtITMfKWvF/NR3IOyRqugl19+mTPOOIM333zzoJeXlpZSWFhIamoqAEOGDGHDhg1Mnjz5iI9ZVFQUjVJFRESkBwpH4KNyyHXBmSNyscTx0P4lDnh2PSyuyeLbk7O6/fl1DSYiIpLY3v+k9ferJ6ZRlJHW6feLSmg0b9480tPTGT169CGhkdfrxe12d/zZ5XLR0tK5ebqysrKuLFNERER6sDXVdqq9uZzfv5mK8vpYl3NYKQb0Sctj3k4L23dX4LR2bnllVygqKtI1mIiISAIrbbKweG8BY/L8WJtrKGs++PWHuzkUlXtqc+fOZe3atdx1113s3LmTJ554omMEzeVy4fPtbwH3er2kpKREowwRERGRL7UgQUbTAEym1hE1X9jMkgpHrMsRERGRBPLOrtbGnaNZgN0uKp1Gd999d8d/33XXXXz3u98lMzMTgOLiYvbt20dTUxNOp5MNGzZw/vnnR6MMERERkS9kGK37jNzWCGPz/bEup1OmFft4aWMa80qdCRF0iYiISOxFDHhnpwu3NcKMkqO/fojaTqPPW7RoET6fj1mzZnHllVdy7733EolEmDFjBtnZ2d1VhoiIiAjbG6yUNluZWeLFYYl1NZ0zNCtIvivMR2VOghGwxfEOJhEREYkPyyvtlLdYOa9/M65jGG+Pemh01113Aa0dRu3GjRvHuHHjov3UIiIiIl8oUU5NO1DriJqXf2xNZWWlg4mFidEhJSIiIrHz9s720TTvMb2/7lGJiIhIj7Og1InVZHBKr8QJjQCmtbWVz2sLvURERES+TGPAxLy9LvqkhhiVEzimx1BoJCIiIj1KeYuFTR47Y/P9pNq67xSyrnBSboAsR5gFpU7CiVW6iIiIdLMP9rgIREyc068Fk+nYHkOhkYiIiPQo7aemTU2g0bR2FhNMKfJR67ewrsYe63JEREQkjr29040Zg68cw6lp7RQaiYiISI/SERoVJV5oBPv3MM3XiJqIiIh8iZ0NVtbX2plQ6CffFTnmx1FoJCIiIj1Gvd/E6mo7I7ID5B7HBVQsjcv347ZGmLfXiaERNREREfkCb3UswD72LiNQaCQiIiI9yKJ9TsKGKaFOTfs8uwVO7eVjX4uVzZ6oH4QrIiIiCSYUgXd3uUizRZhynJ3VCo1ERESkx9i/z+jYjp2NF9M7TlFzxbgSERERiTeLyx3U+Cyc2ceLw3J8j6XQSERERHoEX8jEkgoH/dOD9EkLx7qc4zKp0I/dbHSEYCIiIiLt3m4bTTu3//GNpoFCIxEREekhFlc48IfNCbsA+0Buq8GkQh/bG2zsajzOW4giIiKSNDx+M4vKnJyQEWRIZvC4H0+hkYiIiPQI7V05ibzP6EBTO05R04iaiIiItHpvt4uQYWJ2vxZMpuN/PIVGIiIikvRCEVhU5iTfFebErOO/6xYPTivyYTEZzNurETURERFp9fYONxaTwVl9u2Z/o0IjERERSXqrq+00Bs1MLfZ2yV23eJBhNxiTF2BDnZ3yFo2oiYiI9HSb6qxsqbdxWpGPLEekSx5ToZGIiIgkvfntp6YlwT6jA00vab2LqIXYIiIi0r4Ae3a/41+A3U6hkYiIiCQ1w4AFpS7SbBFOzgvEupwuNbXIhwmjIxQTERGRnikQhvd2u8l2hJlc6O+yx1VoJCIiIkltY52NSq+FU4t8WJPsyifXFWFETpDVVXbq/En2PyciIiKdtrDMSUPAzNl9vV16vaOrCxEREUlqC8raTk1LstG0dtOKvUQwsbBM3UYiIiI9Vfto2rn9u240DRQaiYiISJKbX+rEbjaY2IWt2vFkWnFrGDZfp6iJiIj0SJVeM0vKHQzLDtA/PdSlj63QSERERJLW7kYLOxpsTCz04bIasS4nKkpSwwzKCLKs0kFTMEmOhhMREZFOe3eXmwimLl2A3U6hkYiIiCStjtG04uQcTWs3rcRLMGLi433qNhIREelJDAPe3uHGbjY4o7e3yx9foZGIiIgkrfmlLswYnNorOUfT2k1vH1HTKWoiIiI9yqc1NnY3WZlW7CXN3vVd1QqNREREJClVe82sr7ExOi9ApiMS63KiakB6iN6pIT7Z58AXjnU1IiIi0l32L8Du+i4jUGgkIiIiSWphmRMDE1OTfDQNwGRqPUXNGzazrMIR63JERESkG3hDJj7Y46LAFWJsfnS6qhUaiYiISFJq32c0tSj5QyPYP6I2b68rxpWIiIhId5hX6qQlZOYr/bxYonQWhkIjERERSTpNQRPLKxwMzgzQK6VnzGsNzQ6S5wqzsMxJKLmn8URERITWBdhAVE5Na6fQSERERJLOJ/schAxT0p+adiBz24haY9DMqip7rMsRERGRKCprtrCiysHJeX5KUqN3g0yhkYiIiCSd+aWtI1o9YZ/RgTpG1Eo1oiYiIpLM3tkZ/S4jUGgkIiIiSSYQhk/KHRSnhBiYHop1Od3qpNwAGfYwC0qdRLr+1F0RERGJAxED3t7pwm2NMLMkujfIFBqJiIhIUlle6aAlZGZqsQ9TlJZCxiurGU4r8lPts7C+1hbrckRERCQKVlbZKW+xMrPEi8sa3btECo1EREQkqSwobT01rSftMzrQ9GIvoFPUREREktVbbQuwz+3vjfpzKTQSERGRpBE2YEGZkyxHmBE5gViXExPjC/y4rRHmlzoxNKImIiKSVJqCJubuddE7NcSobrjWUWgkIiIiSWNdjZ06v4UpRT4sPWw0rZ3DAqf08lPabGVbvTXW5YiIiEgX+mCPi0DExDn9WrplDF+hkYiIiCSN+T18NK3dtPYRNZ2iJiIiklTe3uHGjME5faN7alo7hUYiIiKSFAyjdZ+R2xphbL4/1uXE1ORCP3azwby2EE1EREQS384GK+tq7Ywv8JPvjnTLcyo0EhERkaSwrcFKabOVyYV+HJZYVxNbKTaDCQV+ttXb2NPYwz8YSeaDPU5+8UkWDYEeOn8pItKDvb2ztYP43P7d02UECo1EREQkSbSfmja1h4+mtWsfUZuvEbWkEDbgyU/TuGNxNh/udfHhHv29ioj0JKEI/GeXmzRbhClF3Xeto9BIREREksKCUidWk8EpvRQaAZxW5Mdi0ohaMmgKmvjpomxe3phGgSsEwLIKR4yrEhGR7rSkwkGNz8IZfbzd2lGt0EhEREQS3r5mC5s8dsbm+0m16Zx5gExHhNF5AdbX2qn06pIvUe1qtHDNh7l8XO5kYoGPl86sotAdYnmlg7D+qYuI9Bhv73ADcG6/7htNA4VGIiIikgQWlunUtC8yvW1EbYG6jRLSx/scXPNBHrsbbVw+pIlHptSSbm/dV9UYNLOxzhbrEkVEpBt4/GYWljkZmBHkxKxgtz63QiMREelxDKN1LlySx/xSJyaMbp3xTwTt+53maa9RQjEMeHljKj9elE0wYuKuCXXcOKoBS9vu6/EFracDakRNRKRn+O9uFyHDxOx+LZi6+RwEa/c+nYiISOz9cEEO62psjM0PMKnQx6RCPyWp4ViXJceo3m9idZWd4TlBcl1KAw+U74owIjvA6io7Hr+ZTIc+PvHOFzJx3/IM3t/jJs8V5sFTahmaffBd5fH5fkwYLK1wcNXQphhVKiIi3eWtnW4sJoOz+3q7/bkVGomISI+yp8nC8koHdrPBR/ucfLSvdWynJDXEpEIfkwv9nJwXwGXVspBEsWifkwgmpqnL6AtNK/axrtbOojIH5/bv/otN6bzyFgs//yiLTR47I3MC3H9KLTnOQ4O+DIfBkKwgn1bbaQmZcOvrlYhI0trssbLFY2NqkZesGNz8UWgkIiI9ypy2Y6p/OtbDmLwASyocLC53sKzCwf9uTeV/t6ZiNxuMzvMzqbD1V7+0ULe3Akvnte/raT9iXg42rdjLHz5NZ16pS6FRHFtTbefWj7Oo81s4r38zPz65HvthTseZUOBnY52dVVV2Tu3l775CRUSkW3UswO7fvQuw2yk0EhGRHmXO3tZj2acU+Ui3G3x1QAtfHdBCMAKf1thZXO5gcbmTpRWtvx5bAwWuUEeANK5Ap3PFE2/IxOJyJ/3Tg/RO04jhF+mdFmZgRpBlFQ6agyZS9O837ry53c0jKzMwgFtO9nDxwCPvrJhQ4OeljWksrXAoNBIRSVKBMLy7202WI8zkwth8rVdoJCIiPcbeJgubPXYmF7YGRgeymWFMXoAxeQG+P7KRaq+ZJRUOlpQ7WFLh5F87UvjXjhQsJoOROQEmFvqZXOhnUGYQs7qQYmZJhYNAxKRT045gerGPP3+WxiflDmb11scqXgQj8LvVGby+LYUMe5j7JtcxJj/QqfcdmRPAaYloGbaISBJbtM9JQ8DMZYObsMboGDOFRiIi0mPM3ds6mjaz5MgjOrmuCLP7eZndz0vYgI21to4upLXVdlZXO3hmHWQ5wkxs60KaUOCPyax5Tza/bTRtqvYZHdb0Yi9//iyN+aUuhUZxotZn5vZPslhd7eCEjCC/ObWWXimd75azW2B0XoDF5U4qvWbytQReRCTpdIym9YvNaBooNBIRkR5kzl4nFpPBlKPsSrGYYHhOkOE5Qa4Z3kS938SyytYAaXG5g3d3uXl3lxsTBidmBdtG2XwMyw7G7K5QTxCKwEdlTvJdYU7MCh75HXqwgRkhilNCfLzPgT8MjsPsypHo21Rn5ecfZ1PeYmVGiZc7xnuOafn+hAI/i8udLKtwMLuf9lWJiCSTKq+ZxeUOhmYFGJARilkdCo1ERKRHKG2ysLHOzsQCHxn249vpkuEwmNXbx6zePgwDttZbOwKkNdV2NtTZeX5DGmm2COMLWgOkiYV+dQJ0sVVVdhqDZs7q26RF5UdgMrWeovbK5lSWVTg4rUg7cGLlgz1Ofr0sE3/YzHUjGvjWicf+73d8Qevfo0IjEZHk8+4uNxFMMVuA3S5qoVEkEuHpp59m3759mM1mrr/+egoLCzte/9ZbbzFnzhzS09MBuPbaaykqKopWOSIi0sN1jKZ18WiOyQSDMkMMymzimyc20Rw0saLS0TbK5mDOXhdz2p57YMb+LqRROYHDnowkR7agTKNpR2N6iZdXNqcyr9Sl0CgGIgY8uy6NFzem4bZG+M2pNUw5zr+HgekhcpxhllU4MAwUnoqIJAnDgLd2urCbDWb1ju1NgaiFRsuXLwfgnnvuYf369bz00kv89Kc/7Xj99u3bufHGGxkwYEC0ShAREenQPpo2rSi633hTbAZTi31MLW7tQtrdZOnoQlpZ6WBbvY2/bkrFZYkwNj/ApEIfkwr9FKfq5K+jYRiwoNRFmi3CyXmdWxzc0w3PDpLrDLOozEEogkYnu1FT0MRdS7L4aJ+T4pQQvzm1tktGDUwmGJ/v593dbrbVWzkhM3bjCyIi0nXW1drY3WjjjN4thxze0t2iFhpNmDCBsWPHAlBVVUVGRsZBr9+xYwdvvPEGHo+HMWPGcOGFF0arFBER6eH2NVvY0D6a5ui+b7wmE/RNC9M3rZmvD2rGF4bVVfu7kBbtc7JoX2u3TO/UUEeANCYvgPMY9pv0JBvrbFR6LZzdt0XhRyeZTTC12Mfr21JYU21nbCdP6ZLjs7vRwk8/ymZXo40JBT5+NanuuEdkDzS+oDU0WlrhUGgkIpIk2hdgx8PocVR3GlksFp544gmWLVvGzTfffNDrTjnlFM466yzcbjcPPfQQK1as6AiZvozG10RE5Fj8e0Xr7xeOcMb8e8mA3nBR23/vaYAFu2D+Lli028o/t6byz62pOCwwoRim9W39NShbYyef95edrb9fOMJNUZE7prUkkotD8Po2WObJ5bzRnX+/WH/eJKp5O+EHc6AhAN8dAz8/1YnV3KtLn+O8dLhnGaytz+DHRRlHfgcREYlr3iB8WAq9UuH80TlYYnxzzGQYRtRvZXo8Hm677TYeffRRnE4nhmHg9Xpxu1sv8t577z0aGxv52te+dtjHKSsri3apIiKShK75MJdNdTbeOq+CTEd8LqMORuDTGntbF5KTLR5bx+sKXKG2XUh+xhX4SbWpC+kb7+VR2mTl3QvKj+nUqZ4qFIHZ/y7EYTF4c3YF5k6EkUVFRboGO0qGAX/dnMJTa9OxmuHn4zx8pW/07hZf/l4epc0W3rugXCfjiYgkuHd3ubh7aRZXDW3kuhGN3fKch7s5FLXMasGCBbzxxhsA2O12TCYTZnPr03m9Xm655RZ8Ph+GYbBu3TrtNhIRkajY12zhs1o7Y/ICcRsYAdjMMCYvwPdHNvLSGVX8+9xyfjG+jjN6t+ANm/nXjhRu/SSbs/9VyPVzc3hhQyqb6mxEemBesrvRwo4GG5MKfQqMjpLVDKf18lHltbCh1nbkd5Cj5gvDXUsz+cPaDLKdEZ6aUR3VwAhaR9T8YTNrq+1RfR4REYm+t3a2j6bF9tS0dlHdafTkk09y5513EgqFuOqqq1i6dCk+n49Zs2Zx2WWXcffdd2O1Whk5ciRjxoyJVikiItKDzd3bujNoZoxPnjhaua4Is/t5md3PS9iAjbW2ji6kNdV2Vlc7eGYdZDnC/L9BzVwxpKnH7PZZUNp6Gt3UYp2adiyml3h5Z5ebeaVOhucEY11OUqloMfPzj7PZWGdnRE6A+yfXkuuKflg9scDP37eksqzCwfgC7aoSEUlU+5otrKh0MDrXT0mcHJIStdDI6XQessfoQFOnTmXq1KnRenoREREA5u51tZ6alsABg8UEw3OCDM8Jcs3wJur9JpZVtgZIi8ocPLMunQWlTu6Y4KF/evIvwp1f5sSMwWm9EvfvNJbGF/hxWSLMK3Xx/ZGN2pfVRdZU27nt4yxq/RbO7dfMT8bUY++mUbHReQFsZoOlFQ6+T/eMMoiISNd7Z2frjbFz+8dHlxFEcTxNREQk1ipazKyrtXNyXoCsOB5NO1oZDoNZvX38YryHf3ylkrP7trChzs5V7+fxyqYUwkk8sVXtNbOuxs7ovEC3noSXTJwWmNzLz94mK9sbonomSo/xf9vd3Dgvh/qAmZtH13PbuO4LjABcVoOROQE2e2x4/Lq8FxFJRBED3t7pxmWJMKMkfm6MHdV3lebm5mjVISIi0uXm7G29WzOjJLFG045Gut3gzgkeHjillhRbhMfXZvD9uTnsaUrObbgLy1rHDRO5cyweTC9u/ZyYV+qMcSWJLRSBh1dmcP+KTNw2g99NreGSQc0x6d4aX+DHwMTySu01EhFJRKuq7OxrsTKztw93HO1s7FRoVFZWxk033cTNN99MbW0tN910E6WlpdGuTURE5LjM2evCjMH0HhAwTCv28dezqphR4mVtjYMr/5vH/251J92i7PltIceUouT/O42mU3r5sZkN5rcFq3L06vxm/mdBDq9tS2FgRpDnTq9iXH7s9glNKPADsLTCEbMaRETk2L21o3UB9rlxsgC7XadCo+eee45vf/vbZGRkkJ2dzdlnn82zzz4b7dpERESOWUVL6xjTyXkBsp3JM5p2OFmOCPdOquNXE2uxW+CRVZn8z4IcyluSo+uoKWhiRaWDIZkBeqXEx3LIRJViMxif72dLvY29SdqVFk1bPFau/iCXlVUOphd7eXZmNcUxXlg6JCtImi3CsgoHRpKFxSIiya4paGJuqZOS1BAn5cbXgQadCo0aGxsZNWpUx5/POussWlriK/0SERE50Ny2DopEOzXteJlMcEYfH389s5JTe/lYXung8vfy+PcOV8L/IPnxPichw6RT07rItLZ9CfM1onZUPtzj5No5uZS3WPnu8AbunVwXF2MEFhOMK/BT3mJN2vFUEZFk9eEeF/6wmdn9WuLugIpOhUYmk4lAIICprXqPx0Mk0jPu2oqISGKau9eJqYeMpn2RXFeEh06t5fZxdZiA+5Zn8eNF2VR5E3dJ7oK2cEOhUdeYUuTDjMH8Uo2odUbEgGfWpfGLxdmYTfDAKbVcPawJcxxd3GtETUQkMb21040Jg6/0jb/mnE5dOZ555pnce++91NfX88orr3D77bdz1llnRbs2ERGRY1LpNbO2xsHoHjSa9kVMJji3v5e/nFXF+Hw/H5c7ufy9fN7bnXhdR/4wfFLuoDglxMD0UKzLSQpZjgij8wJ8WmOnOoHDxO7QHDTxs4+yeWFDGsUpIZ6dWR2Xy9jbQ6NlCo1ERBLGzgYr62rsTCjwU+COv+vWTl0hzJw5k69//eucdtpphEIhrrvuOs4888xo1yYiInJM5rWPpiXxqWlHo9Ad5vdTa/jJGA/BCNy1JIvbP8miLoGO5l5R6aAlZGZqsS/u2rYTWXsn3oIyjah9mT2NFr7zYS6L9jkZn+/nz7OqGJgRn8FlUUqY4pQQKyodhOLv5w4REfkC7+xsvW6dHWcLsNtZO/uGw4YNY9iwYdGsRUREpEvMaRtNm1ESf50AsWIywUUDW5hQ4OfeZZnMLXWxutrOT8fUMz0BPk7te3fisbsjkU0t9vLo6gzm7XVx0cD4vFiNpSXlDu5YnEVj0MzXBzVx46gGrHGetU4o8PPG9hQ+q7UxKjcY63JEROQwQhH4zy43abZI3I7fdyo0uvLKKzv2GR3oxRdf7PKCREREjkeV18zaajsn5QbI6cGjaV+mJDXME9Nr+MeWFJ7+NJ1bP8nmrD4t3HxyPen2+JxZCxuwsMxJliPMiJz4OlEk0RW4IwzNCrCyyk59wERGnP4b6G6GAa9uSeGJNelYzPCL8XXM7pcYnYvtodHSCqdCIxGROLe0wkG1z8JFA5txxOkZBp0KjR555JGO/w4Gg3z00Uc4HJqVFhGR+DOv1ImBqcedmnY0LCa4bHAzkwv93LMsk/d2u1lR6eC2cR4m9/LHurxDrKuxU+e3cEH/ZiwaTety00t8bKizs6jMmTDBSDT5wvDgikze3eUm1xnmgVNqGZ6TOOHL2Hw/ZgyWVjj4zvDGWJcjIiKH8dZONxC/o2nQyZ1GeXl5Hb+Kioq45JJLWLx4cbRrExEROWpz9rh69KlpR6NfeohnZlRz3YgGPH4zNy/K4f7lGTQH4yuZma9T06JqenFrUNR+Ol1PVuk18/25uby7y83w7ADPzapKqMAIIM1uMCw7yGe1Npri7HNZRET2q/ebWFTmZEB6kKFZ8fu95pimsktLS6mvr+/qWkRERI5LtdfMmmo7o3ID5Lk0mtYZVjNcNbSJ52ZVMSgjyP/tSOGK/+axvNIe69KA1jGhBaVO3NYI4/LjrwsqGfRJCzMgPcjicictoZ4bMnxaY+PqD/LYUGfnnL4t/GF6dcJ+HRlf4CdsmFhZqckAEZF49d/dboIRE+f2b4nrQz6OeqdRJBIhHA5zxRVXRLUwERGRo9UxmpYAi53jzaDMEH+eVcVzn6Xx8sZUfjA/l6+d0MT3RzbissZuz822BiulzVZOL/Fij9NZ/2QwrdjH8xvSWFzu6JGfP//e4eKhlZlEDPjR6Hr+3wnNcX0BfyQTCvw8vyGNpRUOdeiJiMSpt3a6sJgMzuoT36PhR73TyGQy4Xa7cbvdUStKRETkWMzZ23pk6fSS+P7mG69sZrhuRCNTinzcszST/92ayuJyJ3eMr4vZQt0FHaem6e80mqaXeHl+Qxrz9jp7VGgUisBja9L559ZU0mwRfj25lgkFib9sfUROALc1wrIKdRqJiMSjLR4rmz12phZ5yY7zg1s6vdOoqqqKHTt2sG3bNj799FOWLFkS7dpEREQ6rdZnZnWVnVE5fvITdKQkXgzLDvLCGVV8Y3ATpU0Wvjc3lyfWpuMPd38t80udWE1GXC7oTiaDMkL0cof4aJ+TQAz+nmOh3m/iRwty+OfWVAakB3luVlVSBEbQOnZ6cl6A3U1WylvUoiciEm/2L8CO/5tineo0evrpp1m9ejWFhYUdY2oAEydOjFphIiIiR2P/qWk9p0simhwW+MFJDUwtbu06+uumVD7e5+CO8R6GZndP19G+ZgubPXYmFfpIteko+GgymVpPUfvb5lSWVzo4JclDuq31Vn72UTZlzVamFnn55QQPKUn2b2xCgZ+P9jlZWuHg/P7xeyqPiEhPE4zAe7tcZDnCnNIr/q9bOxUarVu3jt/+9re4XK5o1yMiInJM5uxp/R41Q2NMXeqk3AAvn1nFk5+m8b9bU/nunFy+NbSJq4Y2Yjum4zQ6b0FZ26lpRfF/QZUMphW3hkbzS51JHRrN3evknqWZeMNmrhnWyNXDGjEn8P6iLzOhoPXvcJlCIxGRuLKozEl9wMJlg5uwRvlaqit0qsScnBwFRiIiErdqfWZWVdkZkRMg363RtK7mshrccnIDj02tJs8V5rnP0rjmwzy21nfq3tMxW1DqxIShRb7dZGROgBxnmAWlTsLJ1XQDQMSAP65P47ZPsgG4f3It3xmenIERQN+0EHmuMMsr7ESS8O9TRCRR7R9NS4xAv1Oh0ZAhQ/jd737HwoULWbJkSccvERGReDCv1EkEEzO1ADuqxhcE+MuZVZzXv5ktHhvffj+PFzekEopCTufxt+6oGp4TJCfOF0QmC7OptavLE7Cwptoe63K6hGHAniYL7+928pNF2Tz3WRpFKSGePb2a6Um+8Ntkau028gQsbPHYYl2OiIgA1V4zi/c5GJoVYGBGKNbldEqnbhFu2bIFgDlz5hz0cu00EhGReNB+appCo+hLsRncNq6eacU+HlieydPr0llQ5uSO8R76pXfdxc9H+xxEMOnUtG42vcTHG9tTmL/XyZi8xFoKbRhQ5TXzWZ2dDbU2NtbZ2FBrpzG4/x7p2Hw/906qJcPRM1pvxhf4eXunm6UVDoZkxeYERBER2e/dXW4imBKmywg6GRrdeeed0a5DRETkmNT5zayqtDMiO0CBRtO6zam9/PzlrEoeXZXBf3e7+db7eXxvZANfH9TcJeM+80tb9xlN0z6jbjUmz0+aLcK8Uhc/Gt2AKY5Ht+r8ZjbU2tjQFg5tqLVR6z/4pLCS1BCTCn0MzQ4yNCvIyNwAljj+f+pq4/Nb9xotrXDwzRObYlyNiEjPZhjw1k4XdrPBGX0S56ZYp0Ijj8fDU089RXl5Ob/61a944oknuOGGG8jMzIxyeSIiIoc3v200bYa6jLpdht3g7okephf7+M2KDB5bk8GCUie/GO+hOPXYz233hkwsKXfSPz1I77Qecv57nLCa4dQiH+/ucrOhzsawbjop70iagqaOzqH2oKi85eDL2HxXmGnFXoZmBRmaHeTErADp9p7RUfRlsp0RBmUGWVNtxxcy4bT27I+HiEgsra+1savRxqze3oT6/tSp0OhPf/oT48eP57333iMlJYW+ffvy1FNPceutt0a7PhERkcPqODUtyfeTxLMZJT5Oyg3w0MoM5pW6+OZ/87jxpAYuHNByTJ0qS8odBCImpmkBdkxML24NjeaXOmMSGvlCJjZ5bAeNmO1uOviSNcsR5pRCHydmBxmaFWBotnZffZkJBX62eGysrrYzqTB5T8UTEYl3ibYAu12nQqOqqipmzZrFf//7X6xWK1dccQW33HJLtGsTERE5LI/fzMoqO8OyA/RKUUdKLGU7I9w3uY7/7vbxyKoMHlqZyYJSJ7eO8xz12OD8stbRtKkaTYuJiQV+nJYI8/a6+N6Ixqg+VzACWz3tI2Y2NtTZ2VFvJcL+tDHFGmFsvp9hbeHQiVlBCt3huB6diycTCvz8dVMqSyscCo1ERGLEFzLxwW4X+a4w4wsS62txp0Ijk8lEJLL/gs/r9WIYidNOJSIiyWl+qZOwoVPT4oXJBGf19TIm38/9yzP5pNzJ5e/lc9PJ9ZzT19upH/JDEfiozEm+K8yJWtwbE06rweRCP3NLXexstFLcRY8bNmBng7UjHNpQa2NrvY1gZP8/DIclwoicQMcOoqHZAUpSw12yJ6unGpXrx242WFbhiHUpIiI91vxSJ80hM5cMaky43XqdCo0mTJjAY489RktLC++//z5z5sxh8uTJ0a5NRETksObube1ImanRtLiS54rwyGm1/Hunm9+vTufXy7KYt9fFz8d5jjhCtKqq9bSrs/o2qZMkhqaV+Jhb6mLeXiennnj07x8xoLTJwmd1dja27SDaVGfDF95/kpnVZDAos7VzaGh2a1DULy2E1XyYB5aj5rTASbkBllU6qPWZydYYn4hIt2sfTTsnwUbToJOh0UUXXcSCBQswDIO1a9dy+umnc/rpp0e7NhERkS9V7zexvNLB0CyNpsUjkwnO79/C+Hw/9y7PZNE+J994L5+fjPEwq/eXh3zzS1t3VGmfUWyd2suH1WQwr9TJ7Ud4W8OACq/loJPMNtbZaDrgqHszBv3SQwzN9jEsO8CJWUFOyAhitxzmgaXLTCjws6zSwbIKB2f1VWemiEh32tdsYUWlndG5fnofx0EhsdKp0Oj999/ntNNOY+rUqdGuR0REpFPml7naRtMULsSzXilhHptaw2vb3PxhbTp3LM5m3l4vPx5TT6bj4I4Hw4AFZU7SbBFG5wZiVLEApNoMxhX4WVzuZHf9wReMtT7zQcfcb6izUfe5o+57p4aY3HbU/bDsIIMzg7h0clfMjC/wwafpLFVoJCLS7d7Z5cLAlHALsNt1KjRav349r776KuPGjeP0009n8ODB0a5LRETksObsaRtN660fgOKd2QSXnNDCpAI/9yzL4sO9LlZW2bl1nIcpRfuXQW6os1HltfCVvi0aUYoD04t9LC538swKSDVS204ys1HhPfjyscAVYnqxt+OY+xOzggl1lHBPMCgzRJYjzNIKB4aBRj9FRLpJxIB3drpxWSLMPEyndTzrVGj0ox/9iKamJj766COef/55AoEAp59+Ouecc0606xMRETlEfaB1NO3ErABFGk1LGL3Twjw1o5pXN6fw7Lp0fvpRDl/p28JNo+tJsxssKG07NU2jaXFhSpGPB1cY/OVTE5AOtB1138vXsaR6aFZQO3ISgNkE4/L9vL/Hzc5GK/3TQ7EuSUSkR1hdZaes2crsfi24E7TjtlOhEUBqaiqzZs0iKyuLf/3rX7z55psKjUREJCYWdpyapnAh0VhMcPmQZk7p5eeepZn8Z5eb5ZUObhvnYUGZE4clwqQEO4o2WWU7I/x8XD31ZNLbVsuJ2UEKXDrqPlGNL2gNjZZWOBQaiYh0k3+3LcBO1NE06GRotGPHDubOncsnn3zCgAEDOP/88xk3bly0axMREflCc/a2LkueUaLRtETVPz3EszOreWljKs99lsZNC3MAmFrkxZmgd+KS0fn9WygqyqSsTAFtopvQFsYurXDw9UHNMa5GRCT5NQdNzN3rpDgllNC7GjsVGv3mN79h5syZ3H///eTm5ka7JhERkS/VEDCxrMLB4MwAJQl4AoXsZzXD1cOaOLWXj3uWZbGt3sbpCTrvLxLvCtwR+qYFWVVpJxgBm/aGiYhE1Yd7XPjDZmb3a0roLt1OhUZ/+MMfCIVClJeXYxgGgUAAh8MR7dpEREQOsbDMSUijaUllSFaI506vYmu9jaFZwViXI5K0JhT4+efWVD6tsTMmL3HveouIJIK3droxYXBOAo+mAXTqHsO2bdv4wQ9+wP33309tbS3XX389mzZtinZtIiIih5izp3U0TaemJRe7BYZlBxP6TpxIvBvfNqK2rEI3f0VEomlXo4VPa+yML/BT4E7sAyM6FRq9/PLL3HHHHaSlpZGTk8ONN97ICy+8EOXSRKIrFIHPam38bXMKf1ibRktIP6mIxLvGgImlFQ4GZQbprdE0EZGjMiYvgMVksFShkYhIVL3dsQA78W9ydmo8ze/3U1JS0vHnMWPG8Oqrr0atKJFoaAyYWFdjZ22NnbXVdj6rteEL789NW0JmfjKmPoYVisiR7B9NS/xvwCIi3S3FZjAiJ8Cn1XYaAibS7Vo6LyLS1cIG/Genm1RbhKnFiX/N2qnQyGq10tTUhKmtZ7ysrCyqRYkcL8OAfS0W1la3BkRra+xsr7di0Ppv2IRB//QQo3K9jMoN8PLGVF7flsKs3l5O1oy/SNxqPzVNoZGIyLEZX+BnTbWDFZUOZmg3nIhIl1ta7qDaZ+HCAc04LbGu5vh1KjS68MILueuuu/B4PPzud79j7dq1XHvttdGuTaTTQhHY4rF1dBGtrbZT7dv/GeqwRBidF+Ck3ACjcgKMyAmQdsDdtT6pIa6dk8v9yzN56czKpPjkFkk2TcHW0bQTMoL0SdNomojIsZhQ4OdP62FphUIjEZFoeKttNO3c/om9ALtdp0Kjv//97/z4xz9mzZo1GIbB1772tYPG1US6W1OwbdSsrYtofc3Bo2bZjjAzir2MzA0wKjfAkMwg1sNs8BqeE+Trg5v52+ZU/rQ+nRtHNXTD/4WIHI2FZU6CEY2miYgcj6FZQVJtES3DFhGJgvqAiYVlTgakB5PmRNhOhUZOpxObzcZZZ50V7XpEDmEYUN5iOaiLaNsBo2YAA9KDjMz1MiqnNSQqTgkf9Qk81w5vZEGpk79tSmFmiZdh2cnxSS6SLHRqmojI8bOaYUyenwVlLkqbLBTrUAERkS7z390ughETs/u1JM2JsJ0KjXw+HzfeeCM5OTk4nc6Olz/88MNRK0x6rlAEttXbWFttZ01bJ1GVd/+8mN1stI6Ztf0akRMgowsWOTqtBreN83DD/FzuW57J87OqsHXqfEERibbmoIklFQ4GZgTpq9E0EZHjMqGgNTRaWuHgwtTkGJ8QEYkHb+9wYzEZnN03eW5ydio0+va3vx3tOqQHaw6aWF/bFhC1nWrWEtqf1mQ5wkwr3t9FNCQrGLUwZ0x+gK8OaObN7Sm8tCGVa4Y3ReeJROSoLNJomohIl5lQ4AdgWYWDCwcqNBIR6QpbPVY2eexMKfKS7YzEupwu06nQaNiwYdGuQ3qQihYza6odHfuItnmsRA4YNeuXFuw41WxUboCSYxg1Ox43jmrg431OXtiQxvQSHwMzQt335CLyhebsbe1ynamlrSIix60kNUyhO8TySgdhAyxJMkIhIhJL7QuwZ/dLrpucnQqNRI5V2GhNXNfW2Pm0rZOowrv/n53dbLQuq27rIhqZEyDDcfyjZscjxWbws7EeblmUw73LMnl2ZvVhl2iLSHQ1B00sLm9dKNgvXSGuiMjxMplgYoGff+1IYWOdjeHa4ygiclyCEXhvl4ssR5hTeyXXTU6FRtKlWkIm1tXYWgOiGjvrauwHjZpl2sNMLdrfRTQkM4g9Do+3P6WXn7P7tPDubjd/35LC5UOaY12SSI+1aJ+TgEbTRES61Pi20GhpuUOhkYjIcfqozIknYOHSQU1J13AQtdAoEonw9NNPs2/fPsxmM9dffz2FhYUdr1++fDmvvfYaZrOZGTNmMGvWrGiVIlFU2WI+6FSzLR7bQaNmfdKCnHTAqWa9U7t31Ox4/Gh0PUsqHDy7Lp2pRT56a/muSEzM2dM2mtY7ue7aiIjE0rh8PyYMllY4+PYw7XAUETkeHaNp/ZNvT1zUQqPly5cDcM8997B+/XpeeuklfvrTnwIQCoV48cUXuf/++3E6ndxxxx2MGzeOzMzMaJUjXWxBqZMn1qazp2n/PyGb2WBEzv5TzUbmBMl0JO4CsAyHwS0n1/OLxdnctzyTP0yvwZwggZdIsmgfTeufHqS/RtNERLpMhsPgxKxgW1e4Cbc1tusBREQSVY3PzOJyBydmBTghCffhRi00mjBhAmPHjgWgqqqKjIyMjteVlpZSWFhIamoqAEOGDGHDhg1Mnjw5WuVIF6nxmXlkVQZz97qwmQ2mFHkZlRNkZG6AE7MCOOJw1Ox4zCzxMa3Yy/xSF29ud3ORThgR6VYf73MQiJiYoQXYIiJdbnyBnw11dlZV2Tm1lz/W5YiIJKT/7HIRNkzM7pecPytGdaeRxWLhiSeeYNmyZdx8880dL/d6vbjd7o4/u1wuWlqO/AEuKiqKSp1yZIYBf18P9y6CBj+ML4IHTjdxQrYLcMW6vKh66Csw62V48tNMLjwpk+L0WFck0nN8vLL190tPTqMoNy22xYj0YLoGS05fCcNLG+Gzphwu0V+xiMhRMwx470OwW+DKCZlkOjNjXVKXi/oi7BtvvBGPx8Ntt93Go48+itPpxOVy4fPtv2vs9XpJSUk54mOVlZVFs1T5EnuaLDy4IpMVlQ7c1gg/GdPAVwe0YPZBT/kr+eEoF79elsXN//Hx6Gm1CbOXSSSRtYRMzNlRSN+0EKn+qh7z9UYk3hQVFekaLEkVAU5LIXO3h/nuoKpYlyMiknDW19jYWpvH6SVeWmrrSNReo8PdHIraXu8FCxbwxhtvAGC32zGZTJjNrU9XXFzMvn37aGpqIhQKsWHDBgYPHhytUuQYhSLwl00pXPFePisqHZzay8crZ1Vy0cCWHrfb55y+XiYW+Fhc7uSdXcndWSUSL9pH02aW+BTUiohEgd0Co/MC7GiwUelNsuN+RES6QTIvwG4X1Z1GTz75JHfeeSehUIirrrqKpUuX4vP5mDVrFldeeSX33nsvkUiEGTNmkJ2dHa1S5BhsqrNy3/JMNnvsZDnC3HFyPaf34B/cTCb42dh6rvivnd+vzmBSoZ8cZ+Iu+RZJBHP2tga0M3t7Y1yJiEjymlDgZ3G5k2UVDmb309dbEZHO8oXhgz0u8lxhJhQk7164qIVGTqfzoD1Gnzdu3DjGjRsXraeXY+QLw3Pr03hlc2rHMq8fjKonw6ETNXqlhLl+ZAOPrMrk4ZUZ3H9KXaxLEkla3pCJj/c56JMaYqBOTRMRiZrxbT/oKDQSETk680tdNAXNXDywEUsSN1dEfaeRJI4VlXYeWJHJ3iYrRSkhfja2PqkT02Nx0cAWPtzjYl6pizl7vczUiU4iUfHxPgf+sJmZvZt7bIejiEh3GJgeIscZZlmFA8NAX3NFRDrp7R1to2lJempaOw0vCw0BE/cvz+DG+bmUNVm4bHATfzmzSoHRFzCb4NZxHuxmg4dXZlDv15WVSDR0jKaV6K63iEg0mUwwPt9Prd/CtnrdTxYROZJQBJZV2FleaeekXD+908KxLimq9J2hh5u718kjqzKo8Vk4ISPIbeM8DM0OxrqsuNYnLcx3hzfyh0/T+d2aDO6c4Il1SSJJxdc2mtY7NcQJGRpNExGJtgmFft7d7WZphYMTMvV1V0TkQKEIbPbYWFnpYEWVnbXVdlpCrf03Xx2Q3F1GoNCox6rymnlkVQbzS13YzQbfG9HA5UOasKr3rFMuHdzEh3udvLvLzRm9vZzSS11Z8sWagyb+simVCwc0k+/W8vTO+KTcgS9sZmaJRtNERLrD+PzW65ilFQ6+MaQ5xtWIiMRW2ICtHhsrq+ysqHSwuspOc2j/D8p90oKMzfMyuZeP03rAz4EKjXqYiAH/3uHmibXpNAXNjM718/NxHvomeUtdV7Oa4fZxHq76II8HV2TyylmVpNi0LFwO9eLGVF7emMaaajtPTKvBrBDkiHRqmohI98p1RRiQHmRVlQN/GByWWFckItJ9IgZsr7eyosrByko7q6ocNAb3h0QlqSFm5XkZkx9gTJ6fXFfPuhGs0KgH2dNo4f4VmayqcpBijfCzsR7O79+iH2KP0QmZIb41tInnPkvjD2vT+enY+liXJHGm3m/ita0pAKyqcvB/O9w9ooX1ePjC8FGZg+KUEIM0miYi0m0mFPjZ3mBjbbWd8QWBWJcjIhI1hgE7GqysrLKzstLByio79YH9aXlRSoipxT7G5vsZm+fv8dMCCo16gFAEXtmcyp/XpxGImJha5OWWMfXk97CENBquGtrIvL1O3tiewqzeremzSLu/bU6lJWTmiiGNvLEthSfWpHNKL58+9w5j8T4nXp2aJiLS7SYU+Hl1SyrLKhwKjUQkqRgG7G6ysKLS0RES1fn3h0QFrhCn9G1hbL6fMXkBeqVoCudACo2S3MY6G/ctz2SLx0a2I8yPx9QzvdinH8a6iM0Mt433cO2Hudy3PJO/nFmF06oxNYH6gIl/bk0hxxnmmuGNFKeGeXBFJg+vzODBU+r0Ofgl5ux1AnB6iS/GlYiI9Cyj8wLYzAZLKxx8n8ZYlyMicswMA/Y2WzoCopWVDqp9+0OiXGeYs/q0dIybFaeEdW1+GAqNkpQvZOKP69N4dXMKEUyc17+ZG0c1kG5XoNHVhmcH+frgZv62OZVn16fxw5MaYl2SxIFX27qMvjO8HqcFzu/fwn93u1hY5uLDvV5m9VYo8nm+MCwqc1KcEmJwpk5xFBHpTi6rwcicAKuq7Hj8ZjId6ooVkcSxr9nCikp7214iB5Xe/SFRtiPcOhWS52dsvp/eqQqJjoZCoyS0rMLOgysyKW22UpwS4ufjPIzT2FRUXTu8kYVlTv6+OYXTe3sZnq0feHuyhoCJf25JIdsR5sK2HUZmE9w61sMV/83n0VUZjM/3k+FQiHugJeVto2k6NU1EJCbGF/hZWeVgeaVdNzdEJK5VtJhbx83allfva9kfbWTaw8wo8TI2z8/Y/AB900K6tjwOCo2SSH3AxONrMnh7pxuLyeCKIY1cM6xJ41LdwGk1uHWchxvm5XLfskyen1WFXSeP9Fh/35JKc8jM1cPqD/r8650W5rvDG/nDp+k8tiaDOyZ4YldkHGofTZuh0TQRkZiYUODnmXWwtMKh0EhE4kq119xxutmKSgelzfujjDRbhKlFXsbmBxiT72dAekiHPXUhhUZJwDBaf9h6dFUGtX4LgzKD3D7Ow5Asdbt0pzF5AS4c0Mwb21N4cWMa3x2ufQA9UWPAxD+2pJDlCHPhwENPSrt0cBMf7HHyzi43Z/bxMrHQH4Mq44+/bTStlzvEifraJSISE0OygqTZIiyrcGAY6M68iMRMrc/Myip7WzeRnd2Nto7XpdoinNbLx5j81nGzEzIUEkWTQqMEV+k188jKDBaUubCbDW4Y2cClg5uwmmNdWc90w6gGPt7n4MUNqcwo9nJCpo4M72n+sSWFpqCZG0bV4/qCLj9r2/L0qz/I48EVGfzlrCrc6gZkSbmTlpCZCwe26IcUEZEYsZhgXIGfuXtd7Gmy0CdNJwiJSPfw+M2sOiAk2tGwPyRyWyOcUtgaEo3JCzA4K4hF14vdRqFRgooY8OZ2N0+uTac5ZGZMnp+fj/XQW9/cYyrFZvCzsfXcvCiHe5dn8seZ1QrwepCmoIm/b0kl0x7m4i/oMmo3ODPEN4Y08fLGNJ5dl8aPRmt5evto2swSb4wrERHp2Sa0hUZLKxz0Sfvy72UiIsejIWBiVdX+08221u8PiZyWCBMLfIzJDzA2z8+QrKB+poohhUYJaFejhQeWZ7K62kGqLcKtYz2c11935+PF5F5+vtK3hf/scvPq5lSuOLEp1iVJN/nHlhQag2a+P7LhC7uMDnT1sEbm7XXxjy0pzOrtZUROzx3JCoRhYdto2lCNpomIxNSEgtax6WUVDr52gkIjEek6oQi8sCGNhWUOtnhsGLT+AGs3G4xrGzUbk+dnaHYQm0KiuKHQKIGEIvCXTak891kawYiJGcVebj65nlyXjkSNN/8zup4l5Q7+uD6NqcVetXf3AM1BE69uTiXDHubiE5qP+PZOC9w6zsP35+Vy//JMXjijqsd+c1xS4aAlZOarAxR+i4jEWlFKmJLUEMsrHYQi6O6+iHSJUAR+uTiLuaWta1VOzgswJs/PmPwAw7MDOkQojunbQIL4rNbGVR/k8cy6dDLsEe4/pZb7TqlTYBSnMuwGPx5TTyBi4r7lmUS0sibp/XNra5fRZYObO72j6OS25enbG2y8tCE1yhXGrzl7XYBG00RE4sWEAj8tITPra+2xLkVEkkDYgF8tzWRuqYuT8/y8c345f5hewzXDmzg5T4FRvFNoFOe8IRO/X53Odz/MZVu9jQsGNPPKWZVML9YxqPFuRomPGcVe1lQ7eH2bO9blSBQ1B038bXMq6fYIX+tEl9GBbhjVQJ4rzAsb0the3/OaPwNhWFjqpNAdYli2RtNEROLB+ANG1EREjkfYgF8vy+T9PW5G5fh5+LRaUmy6o55IFBrFsSXlDi5/L49Xt6RSnBrmD9Or+fnYetLs+iRLFLeMqSfNFuGpT9PZ16wIPVn979YUGgJmLhvcdNTfBFNsBj8Z4yFkmLh/eSbhHvbpvbTCQXPIzIwSn0bTRETixNg8P2YMlio0EpHjEDHggeUZvLvLzYjsAI9OqdWpwQlIoVEcqvebuGdpJj9amEOl18KVJzby0pmVjMkLxLo0OUo5zgg/Gl1PS8jMgysyMPQ1Mum0hEz8bXMKabYIlxxll1G7KUV+ZvX2sq7WzmtbU7q4wvg2V6NpIiJxJ81uMCw7yGe1NpqCSvRF5OgZBjy0MoO3dqYwNCvAo1Nq1GGUoBQaxRHDgPd3O7nsvXze2eXmxKwAz82q4vqRjTjVpJKwvtLXy6RCH0sqnLyzyxXrcqSLvbY1hfqAhUuPocvoQDeNrifdHuHpT9N6TFdaMNJ6alqBK8RwjaaJiMSV8QV+woaJlZXqNhKRo2MY8NvV6by5PYVBmUF+O7VG0zIJTKFRnKhoMfOTj7L55ZJsWkImbhxVzx9nVjM4MxTr0uQ4mUzws7H1uK0Rfr86g2qvPu2SRUvIxCubWruM/t+gY+syapftjPA/J9XjDfecrrRlFQ4ag2amazRNRCTuTGjba6QRNRE5GoYBj69N559bUxmYEeSxqTVkKDBKaPrpNcYiBry21c033svno31OxuX7+cuZVVw+pFlHnCaRQneYG0Y10Bg08/CqnhEI9ASvb3PjCVj4+qAmUrug3fYrfb1MLGjtSnt3d/J3penUNBGR+DUiJ4DbGtEybBHpNMOApz5N42+bU+mX1hoYZTp02neiUywRQzsbrHxvbi4Pr8rEYoLbx9Xx2NQaSlLDsS5NouCrA1oYnetnfqmLOXudsS5HjpM3ZOKVTamkdkGXUbv2rjSXJcLvVmdQ60veL9HBCCwodZLnCjMiR6NpIiLxxmqGk/MC7G6yUt7SM8amReT4/OmzNF7elEaf1BCPT6sh26nAKBkk708kcSwYgT9/lsqV7+fxaY2d00u8/O3sSs7t79WIRhIzm+C2cR7sZoNHVmVQ79dfdiJ7Y5ubOr+F/zeouUtntHulhPneyEYaAmZ+uzqjyx433ixvG02bUeLFrE8FEZG4pBE1Eems5z9L5bnP0ihOCfH49GpyXQqMkoVCo262ptrOVe/n8af16WTYI/zm1Bp+PbmOHKWwPULvtDDXjmigzm/hd0kcCCQ7X8jEXzalkmKN8PVBTV3++Bef0MyI7AAf7HGxsCw5L9Tbu+1mlvhiXImIiHyZ9tBII2oicjgvb0zl2fXp9HKHeGJ6DfkKjJKKQqNu4A/D2ztdXP1BLt+bm8v2BhsXDWzmb2dXMqXIH+vypJt9fVAzQ7MCvLvbzcf7dBGWiN7Y3tpldMmgZtKjsNjPYoJbx3mwmgweWpmZdMcdhyKwoMxFrjPMyJxArMsREZEv0TctRL4rzLIKOxHtYxSRL/C3zSk8+Wk6Ba7WwKjQrVUryUahURTta7bwh7VpXPBWAb9elsWmOhtTi7w8M6OKn4yp75LFuZJ4rGa4fXxrIPDgikyakywQSHa+MPx1Uypua4RLB3d9l1G7ARkhrhraSJXXwpNr06P2PLGwvNJBQ0CjaSIi8c5kgvEFfuoDFjZ7bLEuR0TizP9udfPYmgxynWEen15DUYoCo2Sk0KiLRQxYXO7gJ4uyufidfP6yKQ0TcOWJjfzvOZU8eGodo3K19LWnG9gWCFR6LTyRZIFAsvvX9hRqfBYuOaE56seHXjm0iQHpQd7YnsKqKntUn6s7aTRNRCRxaK+RiHyRN7e7eWRVJjnOME9Mr6a3DnNKWgqNukhjwMSrm1O49N18blqYw6J9ToZmB/nlhDrePLeC60c20kvJqxzgyqFNDMwI8ub2FFZUJk8gkMz8YfjLxtYuo8ui2GXUzmZuHVMzYfDA8kz8SfAlJBSB+aWto2mjcjWaJiIS78blKzQSkYP9e4eLB1dkkuUI8/i0GvqmJcFFqnwphUbHaavHygMrMjj/rQJ+vyaDihYLs/u18NzpVfz59Gq+0teLQ6eUyhewmVtPUzNjcP/yTLwhzenEu//bnkK1z8LFJzST4eie8dIROUEuGdTM7iYrz32W1i3PGU0rq1pH06ZrNE1EJCFkOyMMygyyttqOT9cqIj3eu7tc3L88kwx7mMem1dA/PRTrkiTKrLEuIBEFIzC/1Mn/bk1hTXXrXZde7hAXDWzi3P4tZDq0LV46Z1h2kMuGNPPXTak8uy6N/xndEOuS5Ev4w/DSxlRclgjfGNzcrc993YhGFpY6+eumVGaWeBmSlbjfnOfs0WiaiEiimVDgZ4vHxupqO5MKdYiLSE/1/m4n9yzNJNVm8PupNZyQkbjXpNJ56jQ6ClVeM39cn8aFbxdwx+Js1lQ7mFjg4zen1vDPcyq54sQmBUZy1L4zvIHeqSH+viWFdTVaMhmv/r3D3dFl1N2f526rwc/G1hM2TNy/PJNQgn6ZCbUF7tkOjaaJiCQS7TUSkbl7ndy9NAuX1eB3U2sS+iamHB2FRkdgGLCyys7tn2Rx4dsFPPdZGv6wiUsHNfGPsyv43dRaphT5sahbV46R09K6t8bAxL3LMgloJDjuBMLw8sY0nJYI3xjSvV1G7SYW+jmnbwubPHZe3ZwakxqO18oqO56AheklPn3NFBFJIKNy/djNBssUGon0SAvLHNyxOAuHpTUwGpatg516Eo2nfYmWkIl3d7l4bWsK2xtauz9OyAjytROaObOPF5e1e/aZSM9wcl6AiwY28/q2FJ7fkMZ1IxpjXZIc4K2dbiq9Fr4xuImsGHYT/nB0PZ+UO/jj+jSmFXvpnWBLB+fsdQFweok3xpWIiMjRcFrgpNwAyyod1PrMZDsTtOVVRI7ax/sc3PZxNjazwaNTahmRo8Cop1Gn0efsarTw21XpnP/vAh5amcmuRitn9G7h6RnVvHRGFRcMaFFgJFHx/ZENFLpDvLwxlS0e5bnxIhCGlzak4rBEuHxI9E9MO5wMu8HNJ9cTiJh4YEUmRgJ9KQpFYEHbaNpJeRpNExFJNO0jauo2Euk5lpQ7uPXjbCxmg0dOq+UkrRfokRQasX/Pxg/n53DpuwX8Y2sqLqvBd4Y38ObsCn41ycNJuQFMGqeQKEqx7d9bc++yxN1bk2ze3ummwmvlooEtcXFn9fQSH1OKvKyscvB/O9yxLqfTVlfbqfNrNE1EJFGNL2g9wEB7jUR6huWVdn76UTYAvzm1ljH5Cox6qh7dzlDnN/N/2928ud1NeUvrh+LkPD8XD2xmWrEPqyI16WaT2vbWvLPLzSubU7nyxNh2tvR0wUjriWl2sxHzLqN2JhP8eEw9KysdPL4mncm9fOS7Yh9mHcmcPa2jaTM0miYikpAGZYbIcoRZWuHAMNDNVJEktrrKzk8WZWMAD55ay4QCBUY9WY+LRQwD1tfYuHtpJhe8VcDT69Kp95u5cEAzfzmzkien13B6bwVGEjs/HF1PtiPMn9ensavREutyerR3drYGyl8d2ExOHHQZtct3RbhhVAPNITOPrMyI+zG1sAHzSp1kOcKMVluziEhCMptgXL6fap+FnY09+r6zSFJbW23jlkXZBCMm7p1cy+RCf6xLkhjrMdGILwxv73Rx9Ye5fGdOHu/uctMrJcTNo+v5v/Mq+OnYegZm6NhAib0Mu8FPxrTurblvWSaROA8EklUoAi9uaO0yuiJOuowOdMGAFk7O87OgzMWcvc5Yl3NYq6taR9PUwSkiktja9xotKdeImkgyWl9r4+aFOfjDJn49qY4pRQqMpAeMp5U1W3h9Wwr/3uGmIWDGjMHUIi8Xn9DM+HztKZL4NL3Ex4wSL3P3tp7gd8mg2Bzz3pO9s8vNvhYrl5zQRF4cjn+ZTXDrWA9X/DefR1ZlMK7AT4Y9PhPG9lPTZmo0TUQkoR24DPvSwbo2EUkmm+ps3LQgB2/IxN2T6phe4ot1SRInkjI0ihiwpMLBa1tT+HifAwMTmfYwV57YyIUDWyh0J9Yx1dIz/fjkelZUOnjq0zROK/LRK0X/brtLe5eRzWxwRRzvleqdFuY7wxt58tN0Hl+TwS/Ge2Jd0iHCBszb6yTTHuZknZomIpLQ8t0R+qYFWVVlJxgBm7pHRZLCFo+VHy7IoSlo4s4JHmb1VmAk+yVVaNQQMPH2Tjevb0thb1Pr/9rw7AAXn9DMzBIvDq2HkQSS7Yzwo9H1/GppFvcvz+T3U2vUGddN3t3loqzZysUDm+N+yfRlg5v4YI+Tt3e6ObOPt+MucLxYU22n1m/hggHNGk0TEUkCEwr8/HNrKp/W2BmjmwFJp6LFzO/XZJBpj9A/PUS/9CD900PkOCO6Dk1S2+ut/HB+Dg0BM78YX8dZfdUZLgdLitBoi8fKa1tTeG+3C1/YjN1sMLtfCxcPbGZodjDW5Ykcs7P7eHl/t4tPyp28tdPFef31RTzaQhF4YUMaNrPBlSc2xrqcI7Ka4bZxHq75MI8Hlmfw17OqcFnjZ0yt/dS0mWpxFhFJCuPbQqNlFQ6FRkkmFIE7l2SxpvrQnVVptgj9DgiR+qWH6J8eosAVVpiUwHY2WPnB/Bw8AQs/H+thdj/9rCGHStjQKBhpHXn4360prK1p/cLWyx3iohMaOa9fCxmO+PmhSeRYmUzws7EevvFePo+tyWBSoT8u9+skk/d2uyhttnLRwGby3YnxsR6SFeIbg5t4eVMaz65L439GN8S6JGD/qWkZ9jBj8uKrA0pERI7NmLwAFpPB0goH142I/5sr0nkvbkxlTbWDmSVevj20kR0NVnY02NjZYGVHg5XPam18WmM/6H3c1gh901oDpAM7kwpTwlgUJsW1PY0WfjA/h1q/hR+f7OGCAS2xLkniVMKFRpVeM29uS+Ff293U+lvnzSYV+rh4YDOTe/n1xUmSToG79Xj1h1Zm8vDKDB44pU53dKKkvcvIajL4ZhzvMvoiVw9vZF6pi39sSWFWby/Dc2LfZbm22k6Nz8L5/TWaJiKSLFJsBiNyAnxabachYCI9Tg9hkKOzptrOc+vTKHSH+NlYD+l2gxMyQ8D+TuFgBPY2WdvCJCs7G2zsaLCytd7GhrqDwyS72aBveoj+B3UmBSlOCeuaIA6UNlm4cX4u1T4L/3NSPRefoMBIvlxChUa3fZLFglInYcNEmi3CpYOauGhgM73TtCBYkttXB7TwwR4XC8pcfLjXq+V0UfL+Hhd7m6x8dUBzwi3Md1rg5+M83DAvl/uWZ/LCGVUxX1A6d68T0GiaiEiyGV/gZ021gxWVDmboa3zCawyYuGtJJgB3TvB8aRBoM9PRUXSgUAT2NVvY0RYitXcm7Wy0ssVjO+htrSaDPh2dScG2kbcQvVND2LV/tlvsa7Zw4/wcKr0WbhhVr5MQ5YgSKjSau9fFoIwgF5/QzJl9vHG1t0MkmswmuHWch2/+N49HV2UwLj9ApiMxRqcSRdiAFz5r7TK6MsG6jNqNyQvw1QHNvLk9hZc2pnLNsNj9f0SM1q/Z6fYIY/M1miYikkwmFPj503pYWqHQKNEZBvxmZSblLVauHtbI6GPYU2U1t57o2jstzNTi/S+PGFDeYjmoM6k9UNreYANcHW9rMRkUpx445tYaKvVJC+FUmNRlKlvM/GB+DuUtVq4b0cAVQxQYyZFFJTQKhUI89dRTVFVVEQwGufjiixk3blzH69966y3mzJlDeno6ANdeey1FRUVHfNynZ1QzKieg0RzpkXqnhrl2eCOPr83gt6vTuXuiJ9YlJZUPdrvY3WTlgv7N9EpJrC6jA90wqoFFZU5e+CyNmSW+Q+4GdpdPa+xU+yyc20+jaSIiyWZoVpBUW4RlFYcuTJbE8s4uFx/scTEyJ8C3h3btjiqzCYpSwhSlhDm11/4bSIYBVV7zIZ1JOxps7G60Mb90/2OYMChKCXd0JvU9IFRyq4HgqFR5zdw4P5fSZivXDGvkqqGJeZNUul9UQqOFCxeSlpbGD37wAxobG/npT396UGi0fft2brzxRgYMGHBUj3tSrk5okJ7t64Ob+XCvi//udnNGby+nFamDoyuEDXhuQyoWk8G3EvwbaKrN4KdjPfz0oxzuW57J0zOqY7Lrbc6ettE0jVKKiCQdqxnG5vuZX+qitMlCcWri3mzpyfY0WnhkZQYp1gh3T6zrtps8JhPkuyPku/1MLDw4TKr1mw8IkvZ3Ji3a52TRPudBj1Po3n+KW3tnUr+0EGnas3WIWl9rh9GeJitXntjINcO0xF46Lyqh0eTJk5k0aVLHny2Wg3sKd+zYwRtvvIHH42HMmDFceOGFnXrcznQjiSS7358D57wCj6zJ4eyRkK6bfMftX5tgdyN8fTiMHVQQ63KO29eLYEElvLXFzgdVRXx7dPc+f8SA+e9AhgPOPykHm9rKRRKersHk884YDPNLYbO/gPGDY12NHK1AGK6bD94wPH52/Fz/FAMjv+DltV7YWgtb2n/VwJZaK4vLrSwuP/htC1LghGwYlA1Dc2FGPyhI7Ybi41RNC9z0OuxqhO+OgdtPS8NkSot1WZJAohIaOZ2tKbDX6+XRRx/l0ksvPej1p5xyCmeddRZut5uHHnqIFStWMHbs2CM+bllZWTTKFUkoqcC3hqbyp/Xp/OK9Zn4+rj7WJSW0sAGPfpSHxWTlkj6VlJUlx93S6080M39nPg8uglEpVd06crem2k5Fcy6z+7VQVeHptucVkegoKirSNZgcYrDTAhTw301eZuTUxbocOUp/WJvG2so0ZvdrYVyah0T4FC8xQUkOzMgBBrW+rDFgYmfjoZ1JH+2x8tGe/e87LDvA1CIfU4t99EsL9Zh1J/UBEz+Yl8uWehv/74Qmvj2ggX37Yl2VxKPD3RyK2iLs6upqHn74Yc4880xOO+20jpcbhsHs2bNxu90AjBkzhh07dnQqNBKRVlee2MTcvS7+tSOFWX28jMvX6OaxmrvXyc5GG7P7tSRVe322M8L/jK7n18uy+M3KDB49rbbbLpDaT007vcTbPU8oIiLdriQlTC93iBWVDsIGMRmFlmOztMLOXzalUZIa4qbRiX3zMc1uMDInyMicILD/uqMlZGJXg5VPa+wsKHOyusrOZ7V2nl6XTklqqCNAGpETSNp/u40BEz9akMOWehsXDWzmR6MbekxYJl0rKpOrHo+He++9l8svv5yZM2ce9Dqv18stt9yCz+fDMAzWrVt31LuNRHo6mxluH+fBjMH9yzPxhvQd4FhEDHj+szQsJoOrunj5Yzw4p6+XiQU+Fpc7eXe368jv0AXaT01Ls0UYV6CdWyIiycpkaj1FrTFoZmOt7cjvIHHB4zdzz9IsLCaDX02sI8WWnPt/3FaDodlB/t+gZp6YVsPb55dz54Q6ZpR4qfGaeWVzKt+bm8t5/y7g3mUZLCxz4Euee4c0B038aGEOG+vsnNe/mVtOrldgJMcsKp1Gb7zxBk1NTbz22mu89tprAJx++un4/X5mzZrFZZddxt13343VamXkyJGMGTMmGmWIJLWh2UG+MaSJv2xK45l1afxodEOsS0o4c/c62d5g45y+LZQkUZdRO5MJfja2nsvfs/O71RlMLPCT7YxE9TnX19qo9Fo4p28LNp2aJiKS1MYX+PnXjhSWVjgYnhOMdTlyBIYB9y7LpNpn4YaRDQzN7jl/Zxl2g7P7ejm7rxd/GFZUOlhQ5mRhqZO3dqbw1s4UHJYIEwv8TC32cWovP5mO6F4zRUtLyMRNC3P4rNbOV/q28POx9ZgVGMlxMBmGkTDxsubpRQ7mC8O3/pvPniYLz8ysbmvNlc6IGPDN/+axs8HKq2dX0jst+UKjdn/fksLvVmdwRu8WfjXJE9Xn+v3qdF7dksrDp9UcdLyuiCQu7TSSL1PvN/GV/yvkpNwAT82oiXU5cgSvbXXz8KpMxuX7+f3UGgUJtF4PflZrY0GpkwVlTnY1tnbNmTEYlRtgarGPKUW+hLm56A2ZuHlhNqurHZzZp4VfTvAk7fiddK3D7TTSfWCRBOa0wG3jPQDctyyTQGJ8P4sL80tbu4zO7OtN6sAI4GsnNDM8O8D7e9wsKovecXuto2lOUm0RJmg0TUQk6WU4DE7MCrKuxk6LRuXj2rZ6K4+tySDDHuaXE+oUGLUxm2BETpDvj2rk1bOrePXsCm4Y2cDwnCBrqu08tiaDS/5TwOXv5fHMujQ21NqI15YLXxh+8lFrYDSjxMsd4xUYSddQaCSS4E7KDXDxCc3sbLTx/AYdn9kZEQOe+ywNMwbfTsJdRp9nMcFt4zxYTQYPrcykORidK4gNtTYqvFamFPk0miYi0kOML/ATMkysqrLHuhT5Er4w/HJxFoGIidvHe8hzJebYVXfomxbmihObeHZmNW+dV8GtYz2c2svH3iYrL2xI4+oP87jg7QIeWpnBknIHwTj5UPrD8POPsllR6WBqkZdfTazDqmsx6SL6pySSBK4f2UihO8TLG1PZ7InaoYhJY0GZk631Ns7o46VPkncZtRuQEeJbQ5uo9Fp48tP0qDzHh3tbl23P1KlpIiI9Rntn6dKK6HWyyvH5w9p0tjfYuHhgM1OK1AncWdnOCOcPaOHh02r5zwXl3D+5lq/0bcEXMvH6thR+tDCHr/yrkF8uzuT93U6aonRT7kgCYbjtk2yWVDg5pZePX09WYCRdSz9diiQBt9Xg52Pr+dHCHH61NIs/TKsmwxGnvbMxZrR1GZkwuGpoU6zL6VZXntjInL1OXt+Wwhm9vYzOC3TZYxtto2kpVo2miYj0JCNzAjgtEZYpNIpLC8sc/O/WVAakB7nxpPpYl5Ow3FaD6SU+ppf4CEVgbbWd+W2LtN/f4+b9PW6sJoOx+X6mFLXuQcp3R78NKRSBOxZn8fE+JxMLfNw3uVbd3tLl9E9KJElMLPTztROa2FZv43tzc6ls0af3F1lY5mSLx8as3l76pYdiXU63slvg1nEeTBjcvzwTfxc2WX1WZ6O8pXU0zW7puscVEZH4ZrfA6LwAOxpsVHp17RFPqrxm7l2Wid1scPekOpz6/twlrGYYkx/gptENvHZOJS+dUcl3hjcwMCPIkgonD6/K5IK3C7n6g1ye/yyVbfXWqOxBCkXgl0uyWFDmYmy+nwdOrcWhv2OJAn1lF0kiN41u4LLBTexstHHd3Fx2Neo7x4EMA/78WSomDK4e1rO6jNqNzAlyyQnN7G6y8txnXbcDa86ettG03hpNExHpado7TNVtFD8iBtyzNIv6gIUfnFTPCRk960ZZdzGZYFBmiGuGNfHCGdW8MbuCm0/2MC7fz2aPjWfXp3PFf/O55D/5PLYmnVVVdsJdECCFDfjV0kzm7nUxOtfPQ6fWKhSUqNF4mkgSMZvgB6MayHREeOrTdL43J5dHp9QyNDsY69LiwqJ9DjZ77D2yy+hA141sZEGZk79uSuX03l4GZx7fx6J9NM2t0TQRkR7pwNBodj/dPIgHr2xOYVmlg1N7+bh4YEusy+kxCt1hLjmhhUtOaKEhYOKTcicLSp0sLnfwt82p/G1zKhn2MKcVtY6xTSzw47QeXYoUNuDeZZm8v8fNqBw/j0ypxXWUjyFyNBQaiSQZkwmuPLGJTHuEB1dkcOP8HO4/pZYJBV23vyYRGQb8eX3rLqOecGLa4Ry4A+u+ZZn86fTq41qYuLHOxr4WK2f1aVFbtIhIDzQgPUSuM8zSCgcRAx3nHmMbam08/Wk6uc4wt4/3YNLfR0yk2w3O6uPlrD5eAmFYUeVgQamTRWVO3t7p5u2dbuxmg4mFrTuQTivyk+U4/B6kiAEPrsjgP7vcDM8O8OiUWtwKjCTKNJ4mkqTOH9DCvZPrCEZM/HhRDnP2OmNdUkx9tM/BJo+dGSU+BqhFm4mFfr7St4VNHjuvbkk5rsdq/7c1o8TXFaWJiEiCMZlgXIGfOr+FbfW6Jx1LLSETdy7JImyYuGNC3RFDCOkedgtMLvTzs7H1/OvcCv40s4orT2ykKCXEwjIX9y3P4tz/K+B7c3P466YU9jQdehfOMODhlRn8e0cKQzID/HZKDSk2BUYSfQqNRJLY9BIfv51Sg81s8ItPsnh9mzvWJcVE+4lpAN8e1rO7jA70PyfVk+UI88d16V94cdIZhgFz9rpwWyNMLFRoJCLSU7WPqC3VXqOYenRVBnuarFw+pKnHd5nHK7MJhucEuX5kI387u4p/nF3BjaPqGZETYG21nSfWZvD//lPAN97L4+lP01hfayNiwG9Xp/PG9hQGZQT5/bQa0uwKjKR7KDQSSXJj8wM8Ob2GTEeEh1Zm8txnqVE5wSGefVLuYEOdnRnFXi2CPECGw+Dmk+sJREw8uDzzmP5dbPLYKGu2cmovnxYwioj0YOPztQw71j7Y0zr2dGJWgOtGNMS6HOmk3mlhLh/SzDMza3jrvApuG1fHab18lDZZeXFjGt/5MI+z/1XIP7emMiA9yGPTashQYCTdSKGRSA8wJCvIMzOq6eUO8cf16fx2dTqRHvK9pvXEtNYuo6vVZXSI00t8nNbLx4oqB//ecfSdaHP2tI6mzeytLiMRkZ4s1xVhQHqQVVUO/OFYV9Pz7Gu28OCKTFyWCHdPrMOmn/ISUrYzwnn9vTx0Wi3vXlDO/afUck7fFswmgwHpQR6f1nojWKQ76cuJSA/ROy3MMzOrGZAe5J9bU7l7aSbBHvA9Z3GFg89q7Uwr9nLCcZ4SloxMJvjJGA9ua4TH16ZT5e38t4UDR9MmaTRNRKTHm1DgJxAxsbbaHutSepRQBO5akklT0MzNJ9fTJ02pXTJwWQ2mF/u4Y4KHd86v4OUzq8h29oCLd4k7Co1EepA8V4SnZlQzMifAf3e7+elH2XhDyXukhmHAc+vVZXQk+e4IN45qoClo5uGVGZ0eU9vssVKq0TQREWnTvtdII2rd64UNaaytcTCrt5fZ/byxLkeiwGzSqYQSOwqNRHqYdLvBY1NrOKXQx+JyJz9ckEN9IDm/Cy2tcLCu1s7UIi+D1WV0WBcMaGF0rp8FZS7mlnbupL05e12ATk0TEZFWo/MC2MyGlmF3ozXVdp7/LJVCd4ifjvFgSs5LOhGJIYVGIj2Q02rw4Km1nN2nhXU1dq6fm0tlS3J9OTh4l1FTjKuJf2YT3DrOg91s8MjKjCMGie2jaU5LhMmF/m6qUkRE4pnLajAyJ8Bmjw2PP7muK+JRY8DEXUsyAbhrokenaYlIVOiruUgPZTXDHRM8fH1QEzsabFw3N5ddjckzY7Ss0s6nNXZO6+VjSFYw1uUkhD5pYa4Z3kit38LjazIO+7Zb6q3sbbJyai8/TqsuUkVEpNX4Aj8GJpZXaq9RNBkGPLgik/IWK1cPa+Sk3ECsSxKRJKXQSKQHM5vgf05q4HsjGihvsfK9OblsqLXFuqzjZhjwXFuX0TXDtcvoaHxjcBODMoO8vdPN0oovv+Cf2zaaNrO3dieIiMh+E9v2GmlELbre3uniw70uRuX4+dZQdVSLSPQoNBLp4Uwm+NbQJn4+1kNDwMyN83NYdpiwIBGsqLKzptrBKb18nKguo6NiNcPt4zxYTAYPrsj8wkXphgFz9rSOpp2i0TQRETnA4Kwg6fYIyyocnT5YQY7O7kYLj67KINUW4a6JHqz6iU5EokhfYkQEaF2EfO/kOoIRE7csymHO3s4tQ45Hf247Me0anZh2TIZkBblscBNlzVb+2PaxPNC2eiu7m6xM1miaiIh8jsUE4/L9lLdY2dOUPGPv8SIYgV8uzsIbNvOzsR56pYRjXZKIJDmFRiLSYXqJj0en1GAzG/zikyze3O6OdUlHbWWlndXVDiYX+hiWrS6jY3XN8EZKUkP8fXMK6z83svhh+2haiUbTRETkUBPaRtSWaEStyz2zLp1NHjuz+7Uwq7dOLxWR6FNoJCIHGZcf4A/Ta8h0RHhwRSYvbEhNqPby9hPT1GV0fJwWuHWshwgm7luWSTDS+vLWU9OcOCwRTu2l0TQRETlUe2i0TKFRl1pa4eCvm1LpnRri5pPrY12OiPQQCo1E5BAnZgV5ekY1he4Qz6xL53er04kkQHC0qsrOyioHEwt8DM9Rl9HxGpMf4IIBzWxvsPHyxlQAtjdY2d1o45RCPy6NpomIyBfolRKmJDXEikoHoUisq0kOdX4zv1qaidVk8KtJdbj1PVhEuolCIxH5Qn3Swjwzs5oB6UH+sTWVXy3NjPsLvz/rxLQud+OoBnKdYV7YkMbOBitzdGqaiIh0woQCPy0hM+trE/twjXhgGHDvskxqfBauG9mgQz5EpFspNBKRL5XvivDkjGpG5gR4b7ebn36U/YWnacWDNdV2VlQ6mFDgY6S6jLpMqs3gJ2PqCUZM3Lc8kw/3OLGbDU7RaJqIiBzGeI2odZn/3ebmo31Oxuf7+cbg5liXIyI9jEIjETmsDLvBY1NrmFzo45NyJz9ckEN9IP6Co/YT064e1hTjSpLP1GIfM0u8fFpjZ1ejjcm9fGqLFxGRwxqb58eMwVKFRsdla72VJ9ZkkGkP88sJdZjj7xJMRJKcQiMROSKn1eA3p9ZyVp8W1tXY+f7cXCq98fPlY221jWWVDsbl+zkpNxDrcpLSLSfXk2ZrnU+cWaLTWkRE5PDS7AbDsoN8VmujKaik41j4wnDn4iwCERO3j/eQ64rzPQEikpTi56c+EYlrVjP8coKH/zeoie0NNq6bk8vuRkusywLgOZ2YFnXZzgh3TqxjVm8vU4sUGomIyJGNL/ATNkysrFS30bF4fE0G2xtsfO2EJk4r0li4iMSGQiMR6TSzCX50UgPXjWigvMXKdXNy2Vhni2lN62psLKlwMjbPz+g8dRlF06m9/NwzqQ6nRtNERKQTJha2Bh0aUTt6C8scvL4thQHpQW4Y1RDrckSkB1NoJCJHxWSCq4Y28bOxHhoCZm6Yl8PyytidjNJ+YtrVOjFNREQkrgzPDuC2RrQM+yhVes3cuywTu9ngV5PqcMZHY7eI9FAKjUTkmHx1QAu/nlxHMGLi5oU5zN3r7PYa1tfaWFzu5OQ8P2PUZSQiIhJXrGYYkxdgd5OV8hYlH50RMeBXS7OoD1j44Un1DMwIxbokEenhFBqJyDGbUeLj0Sk12MwGv/gki39td3fr8z+3XruMRERE4tmEAo2oHY2/bkplRaWDKUVeLhrYEutyREQUGonI8RmXH+CJaTWk2yM8sCKTFzakYnTDypvPam18XO5kdK66jEREROLV+PbQqFyh0ZF8VmvjmXVp5DrD3DauHpMOnROROKDQSESO29DsIM/MrKbQHeKZden8bk06kSgHR+0npl09rFEXVSIiInGqb1qIfFeY5ZX2qF8bJLLmoIk7l2QRMeCXE+rIdERiXZKICKDQSES6SJ+0MM/MrGZAepB/bEnlnqWZhKJ0vbOxzsZH+5yMyvEzLl9dRiIiIvHKZGrtNqoPWNjsie2Jq/Hs0VUZ7G2ycsWQJsYX6NpGROKHQiMR6TL5rghPzqhmRE6Ad3e7+dlH2fhCXd8G9NxnqQBcM7xJXUYiIiJxTnuNDu+/u128s8vN0KwA3x2hPY0iEl8UGolIl8qwGzw2tYbJhT4+LnfywwU51Ae6LtnZVGdlYZmLETkBxuf7u+xxRUREJDrG5Ss0+jL7mi38ZkUGLkuEuyfWYdNPZyISZ/RlSUS6nMtq8JtTazmzTwuf1tj5/txcKr1d8+WmfZfRNdplJCIikhCynREGZQZZW22PSgdyogpF4JdLsmgOmbllTD2908KxLklE5BAKjUQkKqxmuHOCh/93QhPbG2xcNyeX3Y2W43rMLR4rC8pcDM8OMLFAXUYiIiKJYkKBn2DExOpqe6xLiRvPb0hjXY2dM3q3cE5fb6zLERH5QgqNRCRqzCb40egGrhvRQHmLle/NzWVj3bEvwVSXkYiISGLSXqODra6y88JnqRS6Q/xkTL2ua0Qkbik0EpGoMpngqqFN/HSMB4/fzA3zclhRefR3Gbd6rMwrdTE0K8CkQnUZiYiIJJJRuX7sZoNlCo1oCJi4a0kmAHdPrCPNbsS2IBGRw1BoJCLd4sKBLfx6ch3BiImbFuYwb6/zqN7/uQ1tXUbD1WUkIiKSaJwWGJ3nZ2u9jVpfz/0RxDDggRWZVHitXD28kVG5wViXJCJyWD33K7aIdLuZJT4eOa0Gm9ng9k+y+Nd2d6feb1u9lbl7W7uMTlGXkYiISEIa3zai1pO7jf69083cvS5G5/q5amhTrMsRETkihUYi0q3GFwR4YloN6fYID6zI5MUNqRhH6Mp+vm2X0be1y0hERCRh9fS9RrsaLfx2VTqptgh3TvRg0TWNiCQAhUYi0u2GZgd5emY1he4QT69L57E16US+JDja0WBlzl4nQzIDnNZLXUYiIiKJ6oSMEFmOMEsrHEe8YZRsAmH45eIsfGEzPx/rodAdjnVJIiKdotBIRGKib1qYZ2ZW0z89yKtbUrlnaSahyKFv9/xnqRiYuHpYk7qMREREEpjZBOPy/VT7LOxosMa6nG719Lp0NnvsnNe/mdN7+2JdjohIpyk0EpGYyXdFeGpGNSOyA7y7283PPs7GF9qfDO1ssPLBHheDMoNMKdIFloiISKLriSNqS8od/G1zKn1SQ9w0uiHW5YiIHJWoRPyhUIinnnqKqqoqgsEgF198MePGjet4/fLly3nttdcwm83MmDGDWbNmRaMMEUkAGXaDx6bVcNsnWXy8z8kPF+Tw8Gk1pNsNnt/Q3mWkXUYiIiLJYMIBy7AvHdwc42qir9Zn5ldLM7GaDH41qQ6XtYfN5YlIwotKp9HChQtJS0vjV7/6Fbfddht//vOfO14XCoV48cUXuf3227n77rv58MMP8Xg80ShDRBKEy2rwm1NrOaN3C5/W2Ll+bi4rKu18sNvFCRlBpqrLSEREJCnkuyP0TQuyqspO8AvG0pOJYcC9yzKp9Vu4fmQDQ7KCsS5JROSoRaXTaPLkyUyaNKnjzxaLpeO/S0tLKSwsJDU1FYAhQ4awYcMGJk+efMTHLSoq6vpiRSRuPFsMd8+HF9bYuHF+LgC3nGqjpFif+yIisaRrMOlKMwbAC2tgH0VMSuJ/Ws+vho/LYWofuHl6BmZTRqxLEhE5alEJjZxOJwBer5dHH32USy+9tON1Xq8Xt9vd8WeXy0VLS0unHresrKxrCxWRuHPtILCHUnl2fToDM4KMclehT30RkdgpKirSNZh0qWGpDiCH/3zWSB9zY6zLiYqtHiv3LcwjyxHhpydVUb4vyduqRCShHe7mUNSOLaiurubhhx/mzDPP5LTTTut4ucvlwufbP2ri9XpJSUmJVhkikmBMJvj2sCbG5vspSglj1i4jERGRpDImL4DFZLC0wsF1I5IvNPKFTPxySRaBiIn7xnvIcSowEpHEFZWdRh6Ph3vvvZfLL7+cmTNnHvS64uJi9u3bR1NTE6FQiA0bNjB48OBolCEiCWxUbpBcly6yREREkk2KzWBkToCNtTYaAsl3d+ixNensaLBxyQlNnNrLH+tyRESOS1Q6jd544w2ampp47bXXeO211wA4/fTT8fv9zJo1iyuvvJJ7772XSCTCjBkzyM7OjkYZIiIiIiISh8YX+Fld7WBFpYMZJclz4MX8UidvbE9hYEaQG0Y1xLocEZHjZjIMI2HOfdQ8vYiIiEj30k4jiYZ1NTa+OyePrw5o5mdj62NdTpeo9Jr55n/z8YVMvHBGFf3TQ7EuSUSkU2Ky00hEREREROSLnJgVJNUW4b1dLrZ6bNgsBnazgcNiYDOD3WK0/jIb2C20/W4c8Pv+t7GZDRxtb2OzGDjM7S8HxwFvYze37k6MhrABv1qSRUPAzE/GeBQYiUjSUGgkIiIiIiLdymqGCwc289rWFDbW2QgZ3bPbyG5uC5AsnwuoPh9Gtf/5gPCp4/3MdIRc7W+7rtbOiioHU4u8XDigcydDi4gkAo2niYiIiMiX0niadIeIAYEIBMMmAhETgbCJQITW37/oZUd4m2DYhD9ianu8z73PYR7H4NjDq1xnmJfPrCLToYM8RCSxaDxNRERERETiltkETgs4LQYQm3vahtE6ZuZvC5OCYQ4Inkz4wyaCh4RUEIiYCEVMTCnyKTASkaSj0EhERERERHo8kwmsJrCaDVJiFFyJiMQbc6wLEBERERERERGR+KPQSOT/t3f3oVXW/x/Hn5tH59am4Cpx3mySNZthKjV1li0L8R/pRi3RAi1bgZoJYTc0OiFKoSTeUVkxtFQqnYssjVAkzQKX2rybaJbBzHLgzdZ23I473z+k8ft9j/md4Xad6fPx3zn7XOP9gbG9eO26PkeSJEmSJMWxNJIkSZIkSVIcSyNJkiRJkiTFsTSSJEmSJElSHEsjSZIkSZIkxbE0kiRJkiRJUhxLI0mSJEmSJMWxNJIkSZIkSVIcSyNJkiRJkiTFsTSSJEmSJElSHEsjSZIkSZIkxUmKxWKxoIeQJEmSJElSYvFOI0mSJEmSJMWxNJIkSZIkSVIcSyNJkiRJkiTFsTSSJEmSJElSHEsjXZfKysooKiqioaEh6FF0jQqHw1RVVV3ya9OnT/dnT1fszz//ZOHChYTDYYqLi/nggw+or6+/5Nrq6mrKy8vbeEJJujzzl9qCGUxX2/WewSyNdF3asWMHBQUF7Ny5M+hRJOl/amho4K233uKhhx4iHA4zd+5c+vXrx+LFiy+5fv/+/Rw+fLiNp5SkyzN/SWpvzGAQCnoAqa0dOHCA7t27M3r0aJYuXUphYSHhcJisrCxOnDhBLBZj9uzZVFVVsXr1akKhEA8++CAjR44MenS1M5999hl5eXmMHj2aqqoq3n//fcLhcNBjqR3avXs3eXl53Hrrrc3vFRYW8s0333DixAnee+89otEoKSkpPP/885SVlXH+/Hlyc3O56667Apxcki4yf6ktmcF0tZjBErQ0CofDPPPMM/Ts2TPoUXQN2rJlCw888ABZWVmEQiGOHDkCQG5uLkVFRXz99deUlpYydOhQGhsbmT9/fsATS7re/fHHH3Tv3j3u/ZtuuolXXnmF2bNnM2jQIHbu3Mnx48d5+OGHqaqqumbCitqOGUytxfwlqT0ygyVoaSS1ltraWvbs2cO5c+fYtGkTdXV1bN68GYA77rgDuBhe/n4OtUePHoHNqvYnEokQCoUIheJ/tcZisQAm0rWiW7duHD16NO79kydP0tDQwG233QZAQUEBANu2bWvL8STpssxfam1mMLUWM1gCl0Y1NTW8+eabNDY2Ultby7hx48jPz+fFF18kLy+P48ePk5SUxJw5c0hLSwt6XLUT27dvZ9SoUTz55JMAnD9/nhkzZpCRkcGxY8fIzMyksrKSXr16AZCc7LFfarlly5YxZswY8vLyOHv2LAMHDuTMmTMA/PLLL8EOp3bt7rvvprS0lKNHj9KvXz/g4n/tu3TpwpAhQzh69CgDBw5k+/bt1NbWkpaWZkjWv2YG09Vm/lJrM4OptZjBErg0+vXXXxk7diwDBgzg8OHDfPrpp+Tn51NfX8+IESN46qmnWLJkCXv27GHEiBFBj6t2YuvWrcyYMaP5dUpKCkOHDmXLli1s27aNjRs30rlzZ2bMmMFvv/0W4KRqj8aOHUtJSQkdO3aksLCQ4cOHs2jRIg4dOkTfvn2DHk/tWOfOnXnppZdYuXIltbW1XLhwgT59+jBr1ixqampYsWIFpaWlpKSkMHPmTE6dOkVpaSl9+/b1b6SumBlMV5v5S63NDKbWYgaDpFiC1GD/95bCcDjMlClTKCsro0OHDiQlJVFdXU04HGb69OksWrSITp06sXr1anr27ElhYWHQ46ud8wwHSdL1ygymoJi/JCnxJcy9n8uWLaOyspKmpibOnj3LypUrue+++5g5cyYDBgy45m7xkiRJSgRmMEmS9E8S5vG0/76lMDMzk5KSEjZs2EBmZiY1NTVBj6hrmB/BKUm6XpnBFBTzlyQlvoR5PE2SJEmSJEmJI2EeT5MkSZIkSVLisDSSJEmSJElSHEsjSZIkSZIkxQn0IOxoNMo777zDqVOnaGxsZNy4cfTq1Yvly5eTlJRE7969efrpp0lOvthtnTt3jtdee42FCxfSqVMnamtrWbp0KXV1dWRkZPDss8/StWvXILckSZKU8K4kg23cuJGdO3cCMHjwYCZMmEBDQwNLlizh3LlzpKamMn36dLp06RLwriRJ0tUWaGm0fft2MjIymDlzJjU1NcyZM4ecnBwmTpzIgAEDWLFiBeXl5eTn57N3717WrFnD2bNnm68vLS0lNzeXRx99lIqKCtauXctzzz0X4I4kSZISX0szWHZ2Njt27GD+/PkAvP766+Tn57Nv3z769OnDY489xnfffcf69euZOnVqwLuSJElXW6CPpw0fPpzHH3+8+XWHDh04duwYeXl5wMX/ZlVUVACQnJxMcXEx6enpzeurqqoYPHgwAP3796eysrINp5ckSWqfWprBMjMzefXVV0lOTiY5OZloNErHjh2prKxk0KBBzWv37dsXxDYkSVIrC7Q06ty5M6mpqdTX1/P2228zceJEAJKSkgBITU2lrq4OgIEDB5KRkfH/rs/Ozqa8vByA8vJyzp8/34bTS5IktU8tzWChUIguXboQi8VYtWoVffv2JSsri/r6etLS0pq/1995TZIkXVsCPwi7urqaN954g3vvvZd77rmnOawA1NfXc8MNN/zjtY888ginTp1i7ty5VFdXc+ONN7bFyJIkSe1eSzPY3+cXRSIRpk2bBlwslSKRCACRSOSyeU2SJLVfgZZGZ86cYd68eUyePJlRo0YBkJOTw4EDBwDYs2cPt99++z9ef+jQIUaOHElxcTE333wzubm5bTK3JElSe9bSDBaLxViwYAHZ2dkUFRU1fzhJbm4uu3fvbl7bv3//YDYiSZJaVaAHYW/YsIHa2lrWr1/P+vXrAZgyZQolJSVEo1F69uzJsGHD/vH6rKwsli1bBkC3bt08BFuSJKkFWprBdu3axcGDB2lsbGTv3r0ATJo0idGjR7N8+XKKi4sJhULMmjUrwN1IkqTWkhSLxWJBDyFJkiRJkqTEEviZRpIkSZIkSUo8lkaSJEmSJEmKY2kkSZIkSZKkOJZGkiRJkiRJimNpJEmSJEmSpDiWRpIkSf/CDz/8QDgcvuyadevWsWvXrrYZSJIk6SqzNJIkSWol+/fv58KFC0GPIUmS9K+Egh5AkiSpvfjkk0/YsWMH6enp9OjRA4ATJ07w4YcfEolEOH36NDk5Obzwwgts3bqVn3/+mY8++ojk5GSGDBnCxx9/zKFDh2hqaiInJ4epU6eSlpYW8K4kSZIuLSkWi8WCHkKSJCnR7dq1i7Vr1zJv3jw6derEggULiEQi3HLLLWRnZzNy5Eii0Sgvv/wy48ePZ9iwYYTDYcaMGcOwYcNYt24d9fX1PPHEEyQlJbFmzRrq6uqYNm1a0FuTJEm6JO80kiRJaoF9+/aRn59PamoqAPfffz+bNm1i8uTJVFRU8Pnnn/P7779z+vRpIpFI3PU//vgjdXV1VFRUABCNRunatWub7kGSJOlKWBpJkiT9Cx06dABg8eLFXLhwgYKCAoYMGUJ1dfUl1zc1NTFlyhQGDx4MQCQSoaGhoc3mlSRJulIehC1JktQCgwYN4vvvv+evv/6iqamJb7/9FoCffvqJ8ePHU1BQAMCRI0doamoCLhZL0WgUgDvvvJPNmzcTjUZpamri3XffZc2aNcFsRpIkqQU800iSJKmFysrK2LJlC+np6WRnZ3Py5EmGDx/OF198QUpKCmlpaaSnp9O7d28mTZrEV199xZdffsmECRMoKChg1apVHDx4sPkg7KKiIg/CliRJCcvSSJIkSZIkSXF8PE2SJEmSJElxLI0kSZIkSZIUx9JIkiRJkiRJcSyNJEmSJEmSFMfSSJIkSZIkSXEsjSRJkiRJkhTH0kiSJEmSJElx/gMR8+gjXGmMugAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 1440x432 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.style.use('ggplot')\n",
    "df2c['monetary'].groupby('date').agg(sum).plot(figsize=(20,6), c='dodgerblue')\n",
    "\n",
    "plt.title('Revenue per month')\n",
    "\n",
    "plt.ylabel('revenue')\n",
    "plt.xlabel('date');"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "eXjAtAMhdxLy"
   },
   "source": [
    "### Transform data to obtain RFM"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 28,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "hrcHkkTSdxLy",
    "outputId": "c1acc009-6788-4972-82b3-504cbc4d73a5"
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Sales from 2019-01-07 00:00:00 to 2020-11-30 00:00:00\n"
     ]
    }
   ],
   "source": [
    "print('Sales from {} to {}'.format(df2['date'].min(),\n",
    "                                    df2['date'].max()))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 29,
   "metadata": {
    "id": "HqiYHbSWdxLy"
   },
   "outputs": [],
   "source": [
    "#Let's focus on sales from last 365 days since most recent date\n",
    "\n",
    "period = 365\n",
    "\n",
    "date_N_days_ago = df2['date'].max() - timedelta(days=period)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "metadata": {
    "id": "nx4-70VqdxLy"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>4375152</td>\n",
       "      <td>773.58</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-16</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-23</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>421.56</td>\n",
       "      <td>2</td>\n",
       "      <td>2019-12-16</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>391.50</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id  monetary  units       date\n",
       "0      KR  4375152    773.58      1 2019-12-16\n",
       "1      KR   705462    337.26      1 2019-12-09\n",
       "2      KR   705462    337.26      1 2019-12-23\n",
       "3      KR   705462    421.56      2 2019-12-16\n",
       "4      KR   706854    391.50      1 2019-12-09"
      ]
     },
     "execution_count": 30,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Remove the rows with dates older than 365 days ago\n",
    "\n",
    "df2 = df2[df2['date'] > date_N_days_ago]\n",
    "df2.reset_index(drop=True, inplace=True)\n",
    "df2.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 31,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "DoBmQt_WdxLy",
    "outputId": "58894d84-b388-4de0-b98f-b41c7e393e1e"
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "<class 'pandas.core.frame.DataFrame'>\n",
      "RangeIndex: 124640 entries, 0 to 124639\n",
      "Data columns (total 5 columns):\n",
      " #   Column    Non-Null Count   Dtype         \n",
      "---  ------    --------------   -----         \n",
      " 0   country   124640 non-null  object        \n",
      " 1   id        124640 non-null  int64         \n",
      " 2   monetary  124640 non-null  float64       \n",
      " 3   units     124640 non-null  int64         \n",
      " 4   date      124640 non-null  datetime64[ns]\n",
      "dtypes: datetime64[ns](1), float64(1), int64(2), object(1)\n",
      "memory usage: 4.8+ MB\n"
     ]
    }
   ],
   "source": [
    "df2.info()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 32,
   "metadata": {
    "id": "oVPHV_IzdxLy"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "      <th>id+</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>4375152</td>\n",
       "      <td>773.58</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-16</td>\n",
       "      <td>KR4375152</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "      <td>KR705462</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-23</td>\n",
       "      <td>KR705462</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>421.56</td>\n",
       "      <td>2</td>\n",
       "      <td>2019-12-16</td>\n",
       "      <td>KR705462</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>391.50</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "      <td>KR706854</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id  monetary  units       date        id+\n",
       "0      KR  4375152    773.58      1 2019-12-16  KR4375152\n",
       "1      KR   705462    337.26      1 2019-12-09   KR705462\n",
       "2      KR   705462    337.26      1 2019-12-23   KR705462\n",
       "3      KR   705462    421.56      2 2019-12-16   KR705462\n",
       "4      KR   706854    391.50      1 2019-12-09   KR706854"
      ]
     },
     "execution_count": 32,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# There are customers with the same 'id' in several countries. This causes errors in the monetary values\n",
    "# Create a unique 'id+' identifier that combines 'country code' and 'customer id'\n",
    "\n",
    "df3 = df2.copy()\n",
    "\n",
    "df3['id+'] = df3['country'].map(str) + df3['id'].map(str)\n",
    "df3.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 33,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "62vRI_-WdxLy",
    "outputId": "56f9f179-2e81-4617-c04b-8f39ddaf4e82"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "Timestamp('2020-12-01 00:00:00')"
      ]
     },
     "execution_count": 33,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# We set the NOW date one day after the last sale\n",
    "\n",
    "NOW = df3['date'].max() + timedelta(days=1)\n",
    "NOW"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 34,
   "metadata": {
    "id": "uCQP5CrNdxLy"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "      <th>id+</th>\n",
       "      <th>days_since_purchase</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>KR</td>\n",
       "      <td>4375152</td>\n",
       "      <td>773.58</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-16</td>\n",
       "      <td>KR4375152</td>\n",
       "      <td>351</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "      <td>KR705462</td>\n",
       "      <td>358</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>337.26</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-23</td>\n",
       "      <td>KR705462</td>\n",
       "      <td>344</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>KR</td>\n",
       "      <td>705462</td>\n",
       "      <td>421.56</td>\n",
       "      <td>2</td>\n",
       "      <td>2019-12-16</td>\n",
       "      <td>KR705462</td>\n",
       "      <td>351</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>391.50</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>358</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  country       id  monetary  units       date        id+  days_since_purchase\n",
       "0      KR  4375152    773.58      1 2019-12-16  KR4375152                  351\n",
       "1      KR   705462    337.26      1 2019-12-09   KR705462                  358\n",
       "2      KR   705462    337.26      1 2019-12-23   KR705462                  344\n",
       "3      KR   705462    421.56      2 2019-12-16   KR705462                  351\n",
       "4      KR   706854    391.50      1 2019-12-09   KR706854                  358"
      ]
     },
     "execution_count": 34,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Add a column, 'days_since_last_purchase', with the days between purchase date and the latest date\n",
    "\n",
    "df3['days_since_purchase'] = df3['date'].apply(lambda x:(NOW - x).days)\n",
    "df3.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 35,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 204
    },
    "id": "byFCnMIwzrj6",
    "outputId": "334eb5b6-6aed-478b-fb6a-7a710b891129"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>country</th>\n",
       "      <th>id</th>\n",
       "      <th>monetary</th>\n",
       "      <th>units</th>\n",
       "      <th>date</th>\n",
       "      <th>id+</th>\n",
       "      <th>days_since_purchase</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>391.50</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-09</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>358</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>388.68</td>\n",
       "      <td>1</td>\n",
       "      <td>2019-12-30</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>337</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14169</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>369.66</td>\n",
       "      <td>1</td>\n",
       "      <td>2020-04-06</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>239</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14192</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>374.76</td>\n",
       "      <td>1</td>\n",
       "      <td>2020-07-27</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>127</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14210</th>\n",
       "      <td>KR</td>\n",
       "      <td>706854</td>\n",
       "      <td>371.82</td>\n",
       "      <td>1</td>\n",
       "      <td>2020-11-09</td>\n",
       "      <td>KR706854</td>\n",
       "      <td>22</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "      country      id  monetary  units       date       id+  \\\n",
       "4          KR  706854    391.50      1 2019-12-09  KR706854   \n",
       "5          KR  706854    388.68      1 2019-12-30  KR706854   \n",
       "14169      KR  706854    369.66      1 2020-04-06  KR706854   \n",
       "14192      KR  706854    374.76      1 2020-07-27  KR706854   \n",
       "14210      KR  706854    371.82      1 2020-11-09  KR706854   \n",
       "\n",
       "       days_since_purchase  \n",
       "4                      358  \n",
       "5                      337  \n",
       "14169                  239  \n",
       "14192                  127  \n",
       "14210                   22  "
      ]
     },
     "execution_count": 35,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df3[df3['id+']=='KR706854']"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 36,
   "metadata": {
    "id": "TZR5VWPwdxLy"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "{'days_since_purchase': <function __main__.<lambda>(x)>,\n",
       " 'date': <function __main__.<lambda>(x)>}"
      ]
     },
     "execution_count": 36,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Recency = Minimum of 'days_since_last_purchase' for each customer\n",
    "# Frequency = Total number of orders in the period for each customer\n",
    "\n",
    "aggr = {\n",
    "    'days_since_purchase': lambda x:x.min(),\n",
    "    'date': lambda x: len([d for d in x if d >= NOW - timedelta(days=period)])\n",
    "}\n",
    "aggr"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 37,
   "metadata": {
    "id": "xVi9-quwdxLy"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>id+</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>...</th>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "      <td>...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>16564</th>\n",
       "      <td>241575552</td>\n",
       "      <td>IQ241575552</td>\n",
       "      <td>IQ</td>\n",
       "      <td>15</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>16565</th>\n",
       "      <td>241794972</td>\n",
       "      <td>IQ241794972</td>\n",
       "      <td>IQ</td>\n",
       "      <td>351</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>16566</th>\n",
       "      <td>241888554</td>\n",
       "      <td>IQ241888554</td>\n",
       "      <td>IQ</td>\n",
       "      <td>43</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>16567</th>\n",
       "      <td>241900254</td>\n",
       "      <td>IQ241900254</td>\n",
       "      <td>IQ</td>\n",
       "      <td>8</td>\n",
       "      <td>62</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>16568</th>\n",
       "      <td>241930824</td>\n",
       "      <td>IQ241930824</td>\n",
       "      <td>IQ</td>\n",
       "      <td>36</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "<p>16569 rows × 5 columns</p>\n",
       "</div>"
      ],
      "text/plain": [
       "              id          id+ country  recency  frequency\n",
       "0         600018     CN600018      CN       29          7\n",
       "1         600060     CN600060      CN      155          1\n",
       "2         600462     CN600462      CN      211          2\n",
       "3         600888     CN600888      CN        8          3\n",
       "4         601014     CN601014      CN      225          1\n",
       "...          ...          ...     ...      ...        ...\n",
       "16564  241575552  IQ241575552      IQ       15          1\n",
       "16565  241794972  IQ241794972      IQ      351          1\n",
       "16566  241888554  IQ241888554      IQ       43          1\n",
       "16567  241900254  IQ241900254      IQ        8         62\n",
       "16568  241930824  IQ241930824      IQ       36          2\n",
       "\n",
       "[16569 rows x 5 columns]"
      ]
     },
     "execution_count": 37,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfm = df3.groupby(['id', 'id+', 'country']).agg(aggr).reset_index()\n",
    "rfm.rename(columns={'days_since_purchase': 'recency',\n",
    "                   'date': 'frequency'},\n",
    "          inplace=True)\n",
    "rfm"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 38,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 390
    },
    "id": "GHS2-oxAdxLz",
    "outputId": "33c3dc12-7191-42f3-a8e5-dcb52b9158fe"
   },
   "outputs": [],
   "source": [
    "# Customers with same id can have different 'recency' and 'frequency' values per country"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 39,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "oqtXiDvzdxLz",
    "outputId": "0c8fb0ef-576a-4e8a-9861-f3def188af06",
    "scrolled": True
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "id+\n",
       "AF186035892       277.86\n",
       "AF1915092      250651.86\n",
       "AF1915920        2238.60\n",
       "AF1916280         612.78\n",
       "AF1917144       29793.18\n",
       "                 ...    \n",
       "VN991620         1093.86\n",
       "VN993528         1018.86\n",
       "VN993996         4037.28\n",
       "VN995010          544.32\n",
       "VN998130          384.84\n",
       "Name: monetary, Length: 16569, dtype: float64"
      ]
     },
     "execution_count": 39,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Check revenue of the last 365 days per customer\n",
    "\n",
    "df3[df3['date'] >= NOW - timedelta(days=period)]\\\n",
    "    .groupby('id+')['monetary'].sum()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 40,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "0UIQXnoddxLz",
    "outputId": "dcf4483f-4100-407a-b350-026f87463f8b"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "id+\n",
       "AF3790218      9706.08\n",
       "BD3790218      7267.38\n",
       "CN3790218    716199.60\n",
       "ID3790218     49154.22\n",
       "IQ3790218      1243.08\n",
       "MM3790218      7110.60\n",
       "PH3790218      1013.58\n",
       "PK3790218    211108.20\n",
       "TH3790218      1245.48\n",
       "TR3790218     16072.02\n",
       "VN3790218      3377.34\n",
       "Name: monetary, dtype: float64"
      ]
     },
     "execution_count": 40,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Example: getting only the monetary value for specific customer with id 3790218\n",
    "\n",
    "df3[ (df3['id'] == 3790218) & (df3['date'] >= NOW - timedelta(days=period))]\\\n",
    "    .groupby('id+')['monetary'].sum()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 41,
   "metadata": {
    "id": "-qGxiJcpdxLz"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>id+</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "      <td>21402.78</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "      <td>1201.14</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "      <td>2033.64</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "      <td>2335.80</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "      <td>230.52</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       id       id+ country  recency  frequency  monetary\n",
       "0  600018  CN600018      CN       29          7  21402.78\n",
       "1  600060  CN600060      CN      155          1   1201.14\n",
       "2  600462  CN600462      CN      211          2   2033.64\n",
       "3  600888  CN600888      CN        8          3   2335.80\n",
       "4  601014  CN601014      CN      225          1    230.52"
      ]
     },
     "execution_count": 41,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Add new column 'monetary' to the rfm dataframe,\n",
    "# which is the (revenue from df3 of last period per customer)\n",
    "\n",
    "rfm['monetary'] = rfm['id+']\\\n",
    "    .apply(lambda x: df3 [(df3['id+'] == x) & (df3['date'] >= NOW - timedelta(days=period))]\\\n",
    "    .groupby(['id', 'country']).sum().iloc[0,0])\n",
    "rfm.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 42,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 80
    },
    "id": "56cInwKPdxLz",
    "outputId": "b5e6fbd5-2f76-4987-c58b-087a660bb6f2"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>id+</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>173</th>\n",
       "      <td>638544</td>\n",
       "      <td>CN638544</td>\n",
       "      <td>CN</td>\n",
       "      <td>1</td>\n",
       "      <td>217</td>\n",
       "      <td>21482332.56</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "         id       id+ country  recency  frequency     monetary\n",
       "173  638544  CN638544      CN        1        217  21482332.56"
      ]
     },
     "execution_count": 42,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Checking monetary value by checking on the biggest customer\n",
    "\n",
    "rfm[rfm['monetary']==rfm['monetary'].max()]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 43,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 80
    },
    "id": "zdHuOr9cdxLz",
    "outputId": "a81187d3-4e4a-43dd-9c30-d99613cdb57a"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>id+</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>8290</th>\n",
       "      <td>3249114</td>\n",
       "      <td>TR3249114</td>\n",
       "      <td>TR</td>\n",
       "      <td>1</td>\n",
       "      <td>1351</td>\n",
       "      <td>2731448.04</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "           id        id+ country  recency  frequency    monetary\n",
       "8290  3249114  TR3249114      TR        1       1351  2731448.04"
      ]
     },
     "execution_count": 43,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfm[rfm['frequency']==rfm['frequency'].max()]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 44,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 390
    },
    "id": "dNRr0-lidxLz",
    "outputId": "c35868a9-5067-47c6-d0e0-00c514b897f0",
    "scrolled": True
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>id+</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>11057</th>\n",
       "      <td>3790218</td>\n",
       "      <td>AF3790218</td>\n",
       "      <td>AF</td>\n",
       "      <td>309</td>\n",
       "      <td>1</td>\n",
       "      <td>9706.08</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11058</th>\n",
       "      <td>3790218</td>\n",
       "      <td>BD3790218</td>\n",
       "      <td>BD</td>\n",
       "      <td>176</td>\n",
       "      <td>4</td>\n",
       "      <td>7267.38</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11059</th>\n",
       "      <td>3790218</td>\n",
       "      <td>CN3790218</td>\n",
       "      <td>CN</td>\n",
       "      <td>1</td>\n",
       "      <td>60</td>\n",
       "      <td>716199.60</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11060</th>\n",
       "      <td>3790218</td>\n",
       "      <td>ID3790218</td>\n",
       "      <td>ID</td>\n",
       "      <td>260</td>\n",
       "      <td>9</td>\n",
       "      <td>49154.22</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11061</th>\n",
       "      <td>3790218</td>\n",
       "      <td>IQ3790218</td>\n",
       "      <td>IQ</td>\n",
       "      <td>176</td>\n",
       "      <td>1</td>\n",
       "      <td>1243.08</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11062</th>\n",
       "      <td>3790218</td>\n",
       "      <td>MM3790218</td>\n",
       "      <td>MM</td>\n",
       "      <td>183</td>\n",
       "      <td>3</td>\n",
       "      <td>7110.60</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11063</th>\n",
       "      <td>3790218</td>\n",
       "      <td>PH3790218</td>\n",
       "      <td>PH</td>\n",
       "      <td>127</td>\n",
       "      <td>3</td>\n",
       "      <td>1013.58</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11064</th>\n",
       "      <td>3790218</td>\n",
       "      <td>PK3790218</td>\n",
       "      <td>PK</td>\n",
       "      <td>43</td>\n",
       "      <td>5</td>\n",
       "      <td>211108.20</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11065</th>\n",
       "      <td>3790218</td>\n",
       "      <td>TH3790218</td>\n",
       "      <td>TH</td>\n",
       "      <td>295</td>\n",
       "      <td>1</td>\n",
       "      <td>1245.48</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11066</th>\n",
       "      <td>3790218</td>\n",
       "      <td>TR3790218</td>\n",
       "      <td>TR</td>\n",
       "      <td>29</td>\n",
       "      <td>10</td>\n",
       "      <td>16072.02</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11067</th>\n",
       "      <td>3790218</td>\n",
       "      <td>VN3790218</td>\n",
       "      <td>VN</td>\n",
       "      <td>302</td>\n",
       "      <td>1</td>\n",
       "      <td>3377.34</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            id        id+ country  recency  frequency   monetary\n",
       "11057  3790218  AF3790218      AF      309          1    9706.08\n",
       "11058  3790218  BD3790218      BD      176          4    7267.38\n",
       "11059  3790218  CN3790218      CN        1         60  716199.60\n",
       "11060  3790218  ID3790218      ID      260          9   49154.22\n",
       "11061  3790218  IQ3790218      IQ      176          1    1243.08\n",
       "11062  3790218  MM3790218      MM      183          3    7110.60\n",
       "11063  3790218  PH3790218      PH      127          3    1013.58\n",
       "11064  3790218  PK3790218      PK       43          5  211108.20\n",
       "11065  3790218  TH3790218      TH      295          1    1245.48\n",
       "11066  3790218  TR3790218      TR       29         10   16072.02\n",
       "11067  3790218  VN3790218      VN      302          1    3377.34"
      ]
     },
     "execution_count": 44,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Check if customers with id='3790218' get a different monetary value per country\n",
    "\n",
    "rfm[rfm['id']==3790218]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 45,
   "metadata": {
    "id": "xaEVEgNudxLz"
   },
   "outputs": [],
   "source": [
    "# Drop 'id+' column \n",
    "\n",
    "rfm.drop(['id+'], axis=1, inplace=True)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "6c0RhcucdxLz"
   },
   "source": [
    "### Calculate the R, F and M scores"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 46,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "KdO2AfoKdxLz",
    "outputId": "c4c70150-869d-4d82-907a-a350c775cf94"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "{'recency': {0.2: 15.0, 0.4: 50.0, 0.6: 120.0, 0.8: 239.0},\n",
       " 'frequency': {0.2: 1.0, 0.4: 2.0, 0.6: 4.0, 0.8: 9.0},\n",
       " 'monetary': {0.2: 967.5,\n",
       "  0.4: 2212.2,\n",
       "  0.6: 4852.548000000001,\n",
       "  0.8: 13957.500000000004}}"
      ]
     },
     "execution_count": 46,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Assign a rate between 1 and 5 depending on recency, monetary and frequency parameters\n",
    "# Using the quintiles method, dividing every feature on groups that contain 20 % of the samples\n",
    "\n",
    "quintiles = rfm[['recency', 'frequency', 'monetary']].quantile([.2, .4, .6, .8]).to_dict()\n",
    "quintiles"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 47,
   "metadata": {
    "id": "mesTzgG6dxLz"
   },
   "outputs": [],
   "source": [
    "# Assigning scores from 1 to 5\n",
    "# Lower values are better for 'recency'\n",
    "\n",
    "def r_score(x):\n",
    "    if x <= quintiles['recency'][.2]:\n",
    "        return 5\n",
    "    elif x <= quintiles['recency'][.4]:\n",
    "        return 4\n",
    "    elif x <= quintiles['recency'][.6]:\n",
    "        return 3\n",
    "    elif x <= quintiles['recency'][.8]:\n",
    "        return 2\n",
    "    else:\n",
    "        return 1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 48,
   "metadata": {
    "id": "YQOMkJPYdxLz"
   },
   "outputs": [],
   "source": [
    "# Higher values are better for 'frequency' and 'monetary'\n",
    "\n",
    "def fm_score(x, c):\n",
    "    if x <= quintiles[c][.2]:\n",
    "        return 1\n",
    "    elif x <= quintiles[c][.4]:\n",
    "        return 2\n",
    "    elif x <= quintiles[c][.6]:\n",
    "        return 3\n",
    "    elif x <= quintiles[c][.8]:\n",
    "        return 4\n",
    "    else:\n",
    "        return 5"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 49,
   "metadata": {
    "id": "7Z6xzJLHdxLz"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "      <td>21402.78</td>\n",
       "      <td>4</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "      <td>1201.14</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "      <td>2033.64</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "      <td>2335.80</td>\n",
       "      <td>5</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "      <td>230.52</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       id country  recency  frequency  monetary  r  f  m\n",
       "0  600018      CN       29          7  21402.78  4  4  5\n",
       "1  600060      CN      155          1   1201.14  2  1  2\n",
       "2  600462      CN      211          2   2033.64  2  2  2\n",
       "3  600888      CN        8          3   2335.80  5  3  3\n",
       "4  601014      CN      225          1    230.52  2  1  1"
      ]
     },
     "execution_count": 49,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Assign R, F and M scores to each customer\n",
    "\n",
    "rfm['r'] = rfm['recency'].apply(lambda x: r_score(x))\n",
    "rfm['f'] = rfm['frequency'].apply(lambda x: fm_score(x, 'frequency'))\n",
    "rfm['m'] = rfm['monetary'].apply(lambda x: fm_score(x, 'monetary'))\n",
    "\n",
    "rfm.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 50,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 204
    },
    "id": "ju7kft3GdxLz",
    "outputId": "c26bc26b-2ed0-4366-a9a9-86bab947da77",
    "scrolled": True
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "      <td>21402.78</td>\n",
       "      <td>4</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>445</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "      <td>1201.14</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>2</td>\n",
       "      <td>212</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "      <td>2033.64</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>222</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "      <td>2335.80</td>\n",
       "      <td>5</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "      <td>533</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "      <td>230.52</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>1</td>\n",
       "      <td>211</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       id country  recency  frequency  monetary  r  f  m rfm_score\n",
       "0  600018      CN       29          7  21402.78  4  4  5       445\n",
       "1  600060      CN      155          1   1201.14  2  1  2       212\n",
       "2  600462      CN      211          2   2033.64  2  2  2       222\n",
       "3  600888      CN        8          3   2335.80  5  3  3       533\n",
       "4  601014      CN      225          1    230.52  2  1  1       211"
      ]
     },
     "execution_count": 50,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Combine R, F and M scores to create a unique 'RFM' score\n",
    "\n",
    "rfm['rfm_score'] = rfm['r'].map(str) + rfm['f'].map(str) + rfm['m'].map(str)\n",
    "rfm.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 51,
   "metadata": {
    "id": "gotetdOBdxL0"
   },
   "outputs": [],
   "source": [
    "# With this 'RFM' scores we would have 125 segments of customers\n",
    "# To make a more simple segment map of 11 segments, we combine f and m scores, rounding them down\n",
    "# fm = (f+m)/2"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 52,
   "metadata": {
    "id": "Th4epxMZdxL0"
   },
   "outputs": [],
   "source": [
    "# Define 'truncate' function to remove decimal places\n",
    "\n",
    "def truncate(x):\n",
    "    return math.trunc(x)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 53,
   "metadata": {
    "id": "14Wz6XxndxL0"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "      <td>21402.78</td>\n",
       "      <td>4</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>445</td>\n",
       "      <td>4</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "      <td>1201.14</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>2</td>\n",
       "      <td>212</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "      <td>2033.64</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>222</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "      <td>2335.80</td>\n",
       "      <td>5</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "      <td>533</td>\n",
       "      <td>3</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "      <td>230.52</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>1</td>\n",
       "      <td>211</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       id country  recency  frequency  monetary  r  f  m rfm_score  fm\n",
       "0  600018      CN       29          7  21402.78  4  4  5       445   4\n",
       "1  600060      CN      155          1   1201.14  2  1  2       212   1\n",
       "2  600462      CN      211          2   2033.64  2  2  2       222   2\n",
       "3  600888      CN        8          3   2335.80  5  3  3       533   3\n",
       "4  601014      CN      225          1    230.52  2  1  1       211   1"
      ]
     },
     "execution_count": 53,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfm['fm'] = ((rfm['f'] + rfm['m'])/2).apply(lambda x: truncate(x))\n",
    "rfm.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "YHaw_3YadxL0"
   },
   "source": [
    "### Segment\tDescription\n",
    "* **Champions:**\tBought recently, buy often and spend the most.\n",
    "* **Loyal Customers:**\tBuy on a regular basis. Responsive to promotions.\n",
    "* **Potential Loyalists:**\tRecent customers with average frequency.\n",
    "* **Recent Customers:**\tBought most recently, but not often.\n",
    "* **Promising Customers:**\tRecent shoppers, but haven’t spent much.\n",
    "* **Customers Needing Attention:**\tAbove average recency, frequency and monetary values. May not have bought very recently though.\n",
    "* **About To Sleep:**\tBelow average recency and frequency. Will lose them if not reactivated.\n",
    "* **At Risk:**\tPurchased often but a long time ago. Need to bring them back!\n",
    "* **Can’t Lose Them:**\tUsed to purchase frequently but haven’t returned for a long time.\n",
    "* **Hibernating:**\tLast purchase was long back and low number of orders.\n",
    "* **Lost:** Purchased long time ago and never came back."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 54,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 204
    },
    "id": "kdM6u7iadxL0",
    "outputId": "93d3c36a-4d88-4b9d-a7d4-ef33121224ae"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "      <th>segment</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>600018</td>\n",
       "      <td>CN</td>\n",
       "      <td>29</td>\n",
       "      <td>7</td>\n",
       "      <td>21402.78</td>\n",
       "      <td>4</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>445</td>\n",
       "      <td>4</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>600060</td>\n",
       "      <td>CN</td>\n",
       "      <td>155</td>\n",
       "      <td>1</td>\n",
       "      <td>1201.14</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>2</td>\n",
       "      <td>212</td>\n",
       "      <td>1</td>\n",
       "      <td>lost</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>600462</td>\n",
       "      <td>CN</td>\n",
       "      <td>211</td>\n",
       "      <td>2</td>\n",
       "      <td>2033.64</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>2</td>\n",
       "      <td>222</td>\n",
       "      <td>2</td>\n",
       "      <td>hibernating</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>600888</td>\n",
       "      <td>CN</td>\n",
       "      <td>8</td>\n",
       "      <td>3</td>\n",
       "      <td>2335.80</td>\n",
       "      <td>5</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "      <td>533</td>\n",
       "      <td>3</td>\n",
       "      <td>potential loyalists</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>601014</td>\n",
       "      <td>CN</td>\n",
       "      <td>225</td>\n",
       "      <td>1</td>\n",
       "      <td>230.52</td>\n",
       "      <td>2</td>\n",
       "      <td>1</td>\n",
       "      <td>1</td>\n",
       "      <td>211</td>\n",
       "      <td>1</td>\n",
       "      <td>lost</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       id country  recency  frequency  monetary  r  f  m rfm_score  fm  \\\n",
       "0  600018      CN       29          7  21402.78  4  4  5       445   4   \n",
       "1  600060      CN      155          1   1201.14  2  1  2       212   1   \n",
       "2  600462      CN      211          2   2033.64  2  2  2       222   2   \n",
       "3  600888      CN        8          3   2335.80  5  3  3       533   3   \n",
       "4  601014      CN      225          1    230.52  2  1  1       211   1   \n",
       "\n",
       "               segment  \n",
       "0      loyal customers  \n",
       "1                 lost  \n",
       "2          hibernating  \n",
       "3  potential loyalists  \n",
       "4                 lost  "
      ]
     },
     "execution_count": 54,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Create a segment map of only 11 segments based on only two scores: 'r' and 'fm'\n",
    "\n",
    "segment_map = {\n",
    "    r'22': 'hibernating',\n",
    "    r'[1-2][1-2]': 'lost',\n",
    "    r'15': 'can\\'t lose',\n",
    "    r'[1-2][3-5]': 'at risk',\n",
    "    r'3[1-2]': 'about to sleep',\n",
    "    r'33': 'need attention',\n",
    "    r'55': 'champions',\n",
    "    r'[3-5][4-5]': 'loyal customers',\n",
    "    r'41': 'promising',\n",
    "    r'51': 'new customers',\n",
    "    r'[4-5][2-3]': 'potential loyalists'\n",
    "}\n",
    "\n",
    "rfm['segment'] = rfm['r'].map(str) + rfm['fm'].map(str)\n",
    "rfm['segment'] = rfm['segment'].replace(segment_map, regex=True)\n",
    "\n",
    "rfm.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 55,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "eQzgj9fMdxL0",
    "outputId": "23dd5719-d3c2-4b7a-9c7a-352c79c0d741"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "id           0\n",
       "country      0\n",
       "recency      0\n",
       "frequency    0\n",
       "monetary     0\n",
       "r            0\n",
       "f            0\n",
       "m            0\n",
       "rfm_score    0\n",
       "fm           0\n",
       "segment      0\n",
       "dtype: int64"
      ]
     },
     "execution_count": 55,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Check for null values\n",
    "\n",
    "rfm.isnull().sum()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "dcog_U9DdxL0"
   },
   "source": [
    "### Exploring the customers segments"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 56,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "e_TFIrzSdxL0",
    "outputId": "56d99b84-4352-4769-c330-7ab62342fb42"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "array(['loyal customers', 'lost', 'hibernating', 'potential loyalists',\n",
       "       'new customers', 'need attention', 'at risk', 'champions',\n",
       "       'about to sleep', 'promising', \"can't lose\"], dtype=object)"
      ]
     },
     "execution_count": 56,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfm['segment'].unique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 57,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 390
    },
    "id": "YE58OitYdxL0",
    "outputId": "bbcdd72f-6bda-4fbb-8ae1-e44f98d4a6b7"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "      <th>segment</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>13028</th>\n",
       "      <td>4096386</td>\n",
       "      <td>JP</td>\n",
       "      <td>260</td>\n",
       "      <td>105</td>\n",
       "      <td>220267.86</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3502</th>\n",
       "      <td>2443284</td>\n",
       "      <td>IN</td>\n",
       "      <td>246</td>\n",
       "      <td>10</td>\n",
       "      <td>102208.02</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14174</th>\n",
       "      <td>4262646</td>\n",
       "      <td>IN</td>\n",
       "      <td>316</td>\n",
       "      <td>10</td>\n",
       "      <td>91909.44</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2435</th>\n",
       "      <td>1803672</td>\n",
       "      <td>IN</td>\n",
       "      <td>267</td>\n",
       "      <td>12</td>\n",
       "      <td>70506.96</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13254</th>\n",
       "      <td>4132968</td>\n",
       "      <td>VN</td>\n",
       "      <td>253</td>\n",
       "      <td>26</td>\n",
       "      <td>42535.14</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11222</th>\n",
       "      <td>3815274</td>\n",
       "      <td>IN</td>\n",
       "      <td>267</td>\n",
       "      <td>11</td>\n",
       "      <td>37968.72</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1458</th>\n",
       "      <td>1031454</td>\n",
       "      <td>PH</td>\n",
       "      <td>267</td>\n",
       "      <td>23</td>\n",
       "      <td>31833.30</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5437</th>\n",
       "      <td>2809158</td>\n",
       "      <td>IN</td>\n",
       "      <td>274</td>\n",
       "      <td>12</td>\n",
       "      <td>27150.12</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14644</th>\n",
       "      <td>4326906</td>\n",
       "      <td>IN</td>\n",
       "      <td>337</td>\n",
       "      <td>11</td>\n",
       "      <td>22351.68</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>259</th>\n",
       "      <td>668070</td>\n",
       "      <td>MM</td>\n",
       "      <td>267</td>\n",
       "      <td>11</td>\n",
       "      <td>21886.92</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>15331</th>\n",
       "      <td>4418268</td>\n",
       "      <td>SA</td>\n",
       "      <td>302</td>\n",
       "      <td>10</td>\n",
       "      <td>14295.54</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>155</td>\n",
       "      <td>5</td>\n",
       "      <td>can't lose</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            id country  recency  frequency   monetary  r  f  m rfm_score  fm  \\\n",
       "13028  4096386      JP      260        105  220267.86  1  5  5       155   5   \n",
       "3502   2443284      IN      246         10  102208.02  1  5  5       155   5   \n",
       "14174  4262646      IN      316         10   91909.44  1  5  5       155   5   \n",
       "2435   1803672      IN      267         12   70506.96  1  5  5       155   5   \n",
       "13254  4132968      VN      253         26   42535.14  1  5  5       155   5   \n",
       "11222  3815274      IN      267         11   37968.72  1  5  5       155   5   \n",
       "1458   1031454      PH      267         23   31833.30  1  5  5       155   5   \n",
       "5437   2809158      IN      274         12   27150.12  1  5  5       155   5   \n",
       "14644  4326906      IN      337         11   22351.68  1  5  5       155   5   \n",
       "259     668070      MM      267         11   21886.92  1  5  5       155   5   \n",
       "15331  4418268      SA      302         10   14295.54  1  5  5       155   5   \n",
       "\n",
       "          segment  \n",
       "13028  can't lose  \n",
       "3502   can't lose  \n",
       "14174  can't lose  \n",
       "2435   can't lose  \n",
       "13254  can't lose  \n",
       "11222  can't lose  \n",
       "1458   can't lose  \n",
       "5437   can't lose  \n",
       "14644  can't lose  \n",
       "259    can't lose  \n",
       "15331  can't lose  "
      ]
     },
     "execution_count": 57,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Print some segments\n",
    "\n",
    "# Can't Lose\n",
    "rfm[rfm['segment']==\"can't lose\"].sort_values(by='monetary', ascending=False)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 58,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 359
    },
    "id": "eXm8JQyAdxL0",
    "outputId": "d9c3aa02-35f8-4b05-c6a0-a31509984c29"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "      <th>segment</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>8245</th>\n",
       "      <td>3242664</td>\n",
       "      <td>TR</td>\n",
       "      <td>64</td>\n",
       "      <td>1</td>\n",
       "      <td>73823.58</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13065</th>\n",
       "      <td>4107798</td>\n",
       "      <td>JP</td>\n",
       "      <td>120</td>\n",
       "      <td>2</td>\n",
       "      <td>67257.48</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>9847</th>\n",
       "      <td>3561900</td>\n",
       "      <td>ID</td>\n",
       "      <td>120</td>\n",
       "      <td>1</td>\n",
       "      <td>59700.00</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6626</th>\n",
       "      <td>2921070</td>\n",
       "      <td>ID</td>\n",
       "      <td>71</td>\n",
       "      <td>2</td>\n",
       "      <td>34730.22</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>10009</th>\n",
       "      <td>3587772</td>\n",
       "      <td>CN</td>\n",
       "      <td>92</td>\n",
       "      <td>1</td>\n",
       "      <td>29961.00</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3087</th>\n",
       "      <td>2131194</td>\n",
       "      <td>JP</td>\n",
       "      <td>57</td>\n",
       "      <td>1</td>\n",
       "      <td>28543.74</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13463</th>\n",
       "      <td>4160490</td>\n",
       "      <td>JP</td>\n",
       "      <td>99</td>\n",
       "      <td>1</td>\n",
       "      <td>24842.22</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1251</th>\n",
       "      <td>993414</td>\n",
       "      <td>KR</td>\n",
       "      <td>71</td>\n",
       "      <td>2</td>\n",
       "      <td>22018.32</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3936</th>\n",
       "      <td>2544588</td>\n",
       "      <td>BD</td>\n",
       "      <td>71</td>\n",
       "      <td>2</td>\n",
       "      <td>19043.82</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3616</th>\n",
       "      <td>2468010</td>\n",
       "      <td>TH</td>\n",
       "      <td>85</td>\n",
       "      <td>2</td>\n",
       "      <td>18599.58</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            id country  recency  frequency  monetary  r  f  m rfm_score  fm  \\\n",
       "8245   3242664      TR       64          1  73823.58  3  1  5       315   3   \n",
       "13065  4107798      JP      120          2  67257.48  3  2  5       325   3   \n",
       "9847   3561900      ID      120          1  59700.00  3  1  5       315   3   \n",
       "6626   2921070      ID       71          2  34730.22  3  2  5       325   3   \n",
       "10009  3587772      CN       92          1  29961.00  3  1  5       315   3   \n",
       "3087   2131194      JP       57          1  28543.74  3  1  5       315   3   \n",
       "13463  4160490      JP       99          1  24842.22  3  1  5       315   3   \n",
       "1251    993414      KR       71          2  22018.32  3  2  5       325   3   \n",
       "3936   2544588      BD       71          2  19043.82  3  2  5       325   3   \n",
       "3616   2468010      TH       85          2  18599.58  3  2  5       325   3   \n",
       "\n",
       "              segment  \n",
       "8245   need attention  \n",
       "13065  need attention  \n",
       "9847   need attention  \n",
       "6626   need attention  \n",
       "10009  need attention  \n",
       "3087   need attention  \n",
       "13463  need attention  \n",
       "1251   need attention  \n",
       "3936   need attention  \n",
       "3616   need attention  "
      ]
     },
     "execution_count": 58,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Need Attention\n",
    "rfm[rfm['segment']==\"need attention\"].sort_values(by='monetary', ascending=False).head(10)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 59,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 359
    },
    "id": "VOu3i5-4dxL0",
    "outputId": "bd4cb467-7287-40d5-e666-4d54cb3f38bd"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "      <th>segment</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>15420</th>\n",
       "      <td>4422780</td>\n",
       "      <td>TR</td>\n",
       "      <td>92</td>\n",
       "      <td>13</td>\n",
       "      <td>2315341.14</td>\n",
       "      <td>3</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>355</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2882</th>\n",
       "      <td>2030526</td>\n",
       "      <td>JP</td>\n",
       "      <td>22</td>\n",
       "      <td>50</td>\n",
       "      <td>1519339.86</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>455</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3220</th>\n",
       "      <td>2182446</td>\n",
       "      <td>JP</td>\n",
       "      <td>29</td>\n",
       "      <td>18</td>\n",
       "      <td>1492057.68</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>455</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>12660</th>\n",
       "      <td>4041366</td>\n",
       "      <td>PK</td>\n",
       "      <td>50</td>\n",
       "      <td>9</td>\n",
       "      <td>736626.96</td>\n",
       "      <td>4</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>445</td>\n",
       "      <td>4</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5612</th>\n",
       "      <td>2853774</td>\n",
       "      <td>VN</td>\n",
       "      <td>8</td>\n",
       "      <td>6</td>\n",
       "      <td>712230.00</td>\n",
       "      <td>5</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>545</td>\n",
       "      <td>4</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>10343</th>\n",
       "      <td>3649728</td>\n",
       "      <td>PH</td>\n",
       "      <td>29</td>\n",
       "      <td>81</td>\n",
       "      <td>579167.52</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>455</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>8284</th>\n",
       "      <td>3248568</td>\n",
       "      <td>TR</td>\n",
       "      <td>64</td>\n",
       "      <td>3</td>\n",
       "      <td>573792.72</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "      <td>5</td>\n",
       "      <td>335</td>\n",
       "      <td>4</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>15450</th>\n",
       "      <td>4427148</td>\n",
       "      <td>IN</td>\n",
       "      <td>29</td>\n",
       "      <td>14</td>\n",
       "      <td>502843.32</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>455</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>14678</th>\n",
       "      <td>4332210</td>\n",
       "      <td>ID</td>\n",
       "      <td>43</td>\n",
       "      <td>21</td>\n",
       "      <td>474773.40</td>\n",
       "      <td>4</td>\n",
       "      <td>5</td>\n",
       "      <td>5</td>\n",
       "      <td>455</td>\n",
       "      <td>5</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2802</th>\n",
       "      <td>1985592</td>\n",
       "      <td>IQ</td>\n",
       "      <td>78</td>\n",
       "      <td>4</td>\n",
       "      <td>460390.86</td>\n",
       "      <td>3</td>\n",
       "      <td>3</td>\n",
       "      <td>5</td>\n",
       "      <td>335</td>\n",
       "      <td>4</td>\n",
       "      <td>loyal customers</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            id country  recency  frequency    monetary  r  f  m rfm_score  fm  \\\n",
       "15420  4422780      TR       92         13  2315341.14  3  5  5       355   5   \n",
       "2882   2030526      JP       22         50  1519339.86  4  5  5       455   5   \n",
       "3220   2182446      JP       29         18  1492057.68  4  5  5       455   5   \n",
       "12660  4041366      PK       50          9   736626.96  4  4  5       445   4   \n",
       "5612   2853774      VN        8          6   712230.00  5  4  5       545   4   \n",
       "10343  3649728      PH       29         81   579167.52  4  5  5       455   5   \n",
       "8284   3248568      TR       64          3   573792.72  3  3  5       335   4   \n",
       "15450  4427148      IN       29         14   502843.32  4  5  5       455   5   \n",
       "14678  4332210      ID       43         21   474773.40  4  5  5       455   5   \n",
       "2802   1985592      IQ       78          4   460390.86  3  3  5       335   4   \n",
       "\n",
       "               segment  \n",
       "15420  loyal customers  \n",
       "2882   loyal customers  \n",
       "3220   loyal customers  \n",
       "12660  loyal customers  \n",
       "5612   loyal customers  \n",
       "10343  loyal customers  \n",
       "8284   loyal customers  \n",
       "15450  loyal customers  \n",
       "14678  loyal customers  \n",
       "2802   loyal customers  "
      ]
     },
     "execution_count": 59,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Loyal Customers\n",
    "rfm[rfm['segment']=='loyal customers'].sort_values(by='monetary', ascending=False).head(10)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 60,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/"
    },
    "id": "hV-0pAyTdxL0",
    "outputId": "d8d5f77f-5b5d-4526-defa-9baf257d73b8"
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "21629.611149737302"
      ]
     },
     "execution_count": 60,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfm['monetary'].mean()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 61,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 297
    },
    "id": "lmTaBuNrdxL0",
    "outputId": "4309c2ea-6b94-42a9-9100-b5f0adab2a52"
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>country</th>\n",
       "      <th>recency</th>\n",
       "      <th>frequency</th>\n",
       "      <th>monetary</th>\n",
       "      <th>r</th>\n",
       "      <th>f</th>\n",
       "      <th>m</th>\n",
       "      <th>rfm_score</th>\n",
       "      <th>fm</th>\n",
       "      <th>segment</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>8245</th>\n",
       "      <td>3242664</td>\n",
       "      <td>TR</td>\n",
       "      <td>64</td>\n",
       "      <td>1</td>\n",
       "      <td>73823.58</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13065</th>\n",
       "      <td>4107798</td>\n",
       "      <td>JP</td>\n",
       "      <td>120</td>\n",
       "      <td>2</td>\n",
       "      <td>67257.48</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>9847</th>\n",
       "      <td>3561900</td>\n",
       "      <td>ID</td>\n",
       "      <td>120</td>\n",
       "      <td>1</td>\n",
       "      <td>59700.00</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6626</th>\n",
       "      <td>2921070</td>\n",
       "      <td>ID</td>\n",
       "      <td>71</td>\n",
       "      <td>2</td>\n",
       "      <td>34730.22</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>10009</th>\n",
       "      <td>3587772</td>\n",
       "      <td>CN</td>\n",
       "      <td>92</td>\n",
       "      <td>1</td>\n",
       "      <td>29961.00</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3087</th>\n",
       "      <td>2131194</td>\n",
       "      <td>JP</td>\n",
       "      <td>57</td>\n",
       "      <td>1</td>\n",
       "      <td>28543.74</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13463</th>\n",
       "      <td>4160490</td>\n",
       "      <td>JP</td>\n",
       "      <td>99</td>\n",
       "      <td>1</td>\n",
       "      <td>24842.22</td>\n",
       "      <td>3</td>\n",
       "      <td>1</td>\n",
       "      <td>5</td>\n",
       "      <td>315</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1251</th>\n",
       "      <td>993414</td>\n",
       "      <td>KR</td>\n",
       "      <td>71</td>\n",
       "      <td>2</td>\n",
       "      <td>22018.32</td>\n",
       "      <td>3</td>\n",
       "      <td>2</td>\n",
       "      <td>5</td>\n",
       "      <td>325</td>\n",
       "      <td>3</td>\n",
       "      <td>need attention</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            id country  recency  frequency  monetary  r  f  m rfm_score  fm  \\\n",
       "8245   3242664      TR       64          1  73823.58  3  1  5       315   3   \n",
       "13065  4107798      JP      120          2  67257.48  3  2  5       325   3   \n",
       "9847   3561900      ID      120          1  59700.00  3  1  5       315   3   \n",
       "6626   2921070      ID       71          2  34730.22  3  2  5       325   3   \n",
       "10009  3587772      CN       92          1  29961.00  3  1  5       315   3   \n",
       "3087   2131194      JP       57          1  28543.74  3  1  5       315   3   \n",
       "13463  4160490      JP       99          1  24842.22  3  1  5       315   3   \n",
       "1251    993414      KR       71          2  22018.32  3  2  5       325   3   \n",
       "\n",
       "              segment  \n",
       "8245   need attention  \n",
       "13065  need attention  \n",
       "9847   need attention  \n",
       "6626   need attention  \n",
       "10009  need attention  \n",
       "3087   need attention  \n",
       "13463  need attention  \n",
       "1251   need attention  "
      ]
     },
     "execution_count": 61,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Customers with monetary over the average that need attention\n",
    "\n",
    "rfm[(rfm['monetary'] > rfm['monetary'].mean()) & (rfm['segment'] == 'need attention')]\\\n",
    "    .sort_values(by='monetary', ascending=False)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 62,
   "metadata": {
    "colab": {
     "base_uri": "https://localhost:8080/",
     "height": 387
    },
    "id": "rGSxrYZ2dxL0",
    "outputId": "63580569-9d4b-49f0-80cf-33415adb4080"
   },
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "D:\\Anaconda\\lib\\site-packages\\matplotlib\\collections.py:982: RuntimeWarning: invalid value encountered in sqrt\n",
      "  scale = np.sqrt(self._sizes) * dpi / 72.0 * self._factor\n"
     ]
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAABJUAAAFNCAYAAAC5YV47AAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMSwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy/YYfK9AAAACXBIWXMAAAsTAAALEwEAmpwYAABa4klEQVR4nO3deXhU5f3+8fvMlsxkIewQCEaMRBERxCputCrgz1qqYquxFb8oLlXU2mqtigi4IC61bohYN6hLbUVUtCgGtaLggiAgshoIkIAsIevMZLbz+yMmEBPIbJkJ8H5dl5fkzMw5n8x8Mss9z/McwzRNUwAAAAAAAEAELMkuAAAAAAAAAAceQiUAAAAAAABEjFAJAAAAAAAAESNUAgAAAAAAQMQIlQAAAAAAABAxQiUAAAAAAABEjFAJAAAklNvt1qOPPqqzzz5b/fv315lnnqkpU6aosrIyLvv3+/16+eWX47KvRDrppJP0xhtvSJJuu+023XjjjWHd7oMPPtDWrVv3efkTTzyhkSNHSpK++OIL5efnq6amJuo6v/zyS61atUqStGXLFuXn52vt2rVR7w8AABy4CJUAAEDCVFdX6+KLL9aiRYs0btw4vfvuu5o0aZI+/fRTXXHFFfJ6vTEf45133tHjjz8eh2qTZ9y4cbr33ntbvF5JSYmuv/56VVVV7fM6V1xxhZ577rm41TZq1Cht27ZNktS9e3d9+umn6t27d9z2DwAADhy2ZBcAAAAOHQ8//LBCoZBmzJih1NRUSVJOTo7y8vI0bNgwzZo1S7///e9jOoZpmvEoNakyMjLCul44v2taWprS0tJiLalZVqtVnTt3bpV9AwCAto+RSgAAICF8Pp/mzJmjSy+9tCFQqte9e3fNnDlTv/zlLyXVjYZ54IEHGl0nPz9fH330kSRp3bp1GjVqlAYOHKjBgwdr3Lhxcrvd+uKLL3T77bervLxc+fn5+uKLLyRJc+bM0YgRI9S/f3+dffbZmj17dsN+n3jiCd1www16+OGHNWjQIA0ePFgzZ87U4sWLNWLECA0YMEBXXnmlysvLG27zv//9T+edd5769++vc889V7NmzWq0vyuvvFJjxozRoEGDGh2rXjAY1EMPPaTBgwfrpJNO0ksvvdTo8r2nv1VXV+vmm2/WSSedpAEDBmjMmDHauHGjJOmss86SJI0YMUJPPPGE3njjDV1wwQW65ZZbdPzxx+upp55qNP2t3htvvKHTTjtNAwcO1F133dUwQqy56XF73/7MM8+UJP3hD3/Qbbfd1mT6W1VVle655x6dfvrpOu644zRmzBgVFRU17OvMM8/UjBkzNGrUKB133HEaMWKEPvzwwyb3DwAAODAQKgEAgITYvHmzqqurdeyxxzZ7+fHHH6/27duHta+bb75Zhx9+uN5++209/fTTWrRokZ555hkNHDhQd9xxh7KysvTpp59q4MCBevvtt3X77bfrkksu0dtvv61Ro0Zp/Pjx+vjjjxv299FHH8ntdmv27NkqKCjQlClTdM8992jChAl67rnntHLlSs2YMUNSXaB14403qqCgQO+8847Gjh2rBx54QO+++27D/hYsWKATTjhB//73v/Xzn/+8Sf1PPfWU3nzzTT344IOaMWOG5s2b1yi02tujjz6qLVu2aObMmXrjjTdksVh0xx13SJL+85//SJL++c9/6oorrpAkfffdd0pLS9Ps2bN1/vnnN7vPf//733ryySf1j3/8Q4sWLQprqp0kvf7665KkBx98UOPGjWty+Y033qgvvvhCjzzyiP79738rJSVFY8aMkcfjabjO448/roKCAs2aNUu5ubm6/fbb5fP5wjo+AABoW5j+BgAAEqKiokJS+FO79qekpERnnnmmsrOzlZOTo2nTpslut8vhcDTsv35a1osvvqiLLrpIv/vd7yRJubm5WrdunZ5++mn94he/kCSlpKTojjvukM1m06hRozRt2jRdeumlOuGEEyRJP//5z7V+/XpJ0rPPPqsRI0bokksukST16tVLmzZt0nPPPadzzz1XkpSamqprrrlGFkvT7+9M09S//vUvXXfddRoyZIikupCmfhRQc79rWlqaevbsqbS0NN17770qKSmRJHXo0EGSlJWV1WiK2/XXX7/faWmTJk3SgAEDJEl//etfddNNNzUEVftTf7zMzExlZGQ0PKaStHbtWi1cuFCvv/56Q3D48MMP64wzztCcOXN00UUXSZLOPffchvtp7NixmjdvnkpKSnT44Ye3eHwAANC2ECoBAICEqB+FtHcQEa1bbrlFd999t1599VWddtppOuecczR06NBmr7t+/XqNHj260bZBgwY1GlnUo0cP2Wx1b4vqp+b17Nmz4XKHw6Hdu3dLqhuptHbt2ka3DwQCDbevv21zgZIk7d69Wzt37lTfvn0btnXr1k1dunRp9vrXXHONrrnmGp188sn62c9+pqFDh+q8885r9rqS5HQ69xsoWSwW9e/fv+HnY489Vn6/X8XFxfu8TTjWr18vu92ufv36NWxzuVzq27ev1q1b17Bt7/AoPT1dUt39BwAADjyESgAAICEOO+wwZWVlacWKFY1CjXr333+/OnfurCuvvLLJZT8NHS655BKdccYZ+uCDD7RgwQLddNNNOv/885udxvXT9ZukutFCoVCo4ee9A6F6+wqFgsGgRo0apYKCgmYvl+pGPrXkp4ts2+32Zq83YMAAzZ8/Xx999JE++eQT/f3vf9crr7zSMBUt0mMbhiGr1dqkDrvdLsMwmlw/3MBnX8c1TbPR79rc73kwLK4OAMChiDWVAABAQlgsFp133nl66aWXVFtb2+iyLVu26LXXXpPD4ZBUNzKoqqqq4fLNmzc3/Lu6ulp33323DMPQqFGj9Mwzz2j8+PGaM2eOJDUJRnr37q1vvvmm0balS5eqd+/eUf0eRxxxhIqLi3XYYYc1/Pfll1/qlVdeCev27du3V+fOnbV8+fKGbWVlZdq6dWuz158+fbqWL1+uESNG6KGHHtJrr72mtWvXas2aNc2GQC0JBoONRg598803SklJUU5OTkPgU11d3XD5li1bwtrvEUccIb/fr2+//bZhm8fj0erVq5naBgDAQYpQCQAAJMx1112nUCikyy67TJ9++qk2b96swsJCjRkzRvn5+br44oslSf369dO7776rxYsXa/Xq1Zo0aVJD4JSenq4vv/xS99xzj9avX6/169ersLCwYR0fl8slt9ut9evXq7a2VldffbX+/e9/65VXXtHGjRv16quv6vXXX9dll10W1e9wxRVX6OOPP9bTTz+t4uJivf/++5o8ebI6duwY1u0Nw9Do0aM1bdo0FRYWat26dbr99tsVDAabvf62bdt07733asmSJdq8ebNmz56t9PR05ebmyuVySZJWrVrVKIRr6fi33367li9frs8//1wPPvigLrvsMqWkpOjII49UamqqHn30UW3evFmvv/56owXNpbr7d926dU0WFs/NzdXw4cN1xx13aPHixVq7dq3++te/ymq1NqyhBAAADi5MfwMAAAmTlZWlV155RU899ZTuuusu7dy5U126dNHw4cN17bXXNkyhuuKKK1RUVKQxY8aoffv2uvHGGxsWp5bqTnN/7733qqCgQMFgUKeeemrD1LeTTz5Zffv21fnnn6+//e1vOvvsszVhwgT94x//0OTJk3XYYYfp3nvv1a9//euofod+/frp8ccf1+OPP64nn3xSnTt31tVXX62rrroq7H2MGTNGPp9PEyZMkNfr1ahRo/a5ptFf/vIXTZ48Wddff72qqqp09NFH65lnnlFmZqYk6Te/+Y3uvPNOFRQU6Oijj27x2E6nUyNHjtTVV1+tQCCg888/XzfeeKOkusBu8uTJeuSRR/Tuu+/qlFNO0fXXX98wCqy+9qlTp2rZsmW6/fbbG+178uTJuv/++3XttdcqEAjoZz/7mV566SVlZWWFfd8AAIADh2EyiR0AAAAAAAARYvobAAAAAAAAIkaoBAAAAAAAgIgRKgEAAAAAACBihEoAAAAAAACIGKESAAAAAAAAImZrzZ2vW7dOL7/8siZOnNiw7dNPP9XcuXN13333SZIKCwtVWFgoq9WqkSNHatCgQfL5fHr88cdVWVkpp9OpsWPHNpw2FwAAAAAAAMnXaqHSW2+9pU8++USpqakN2zZu3KgPP/yw4efy8nLNnTtXU6ZMkd/v1/jx49W/f3/NmzdPvXr10kUXXaTPPvtMs2bN0uWXXx7WcUtLS+P+uyRKdnb2AV0/EodeQbjoFUSCfkG46BWEi15BJOgXhIteSbzs7Oxmt7fa9LeuXbvqlltuafi5qqpKL7/8skaPHt2wbf369crPz5fdbpfL5VK3bt1UXFys1atXa8CAAZKkgQMHasWKFa1VJgAAAAAAAKLQaiOVBg8erO3bt0uSQqGQpk2bpv/7v/+Tw+FouI7b7ZbL5Wr42el0yu12y+PxNGxPTU2V2+0O+7j7Ss8OFAd6/UgcegXholcQCfoF4aJXEC56BZGgXxAueqVtaNU1leoVFRVp27ZtevbZZ+X3+7Vlyxa9+OKL6tevn7xeb8P1PB6P0tLS5HQ6G7Z7vV6lpaWFfawDeQgcQ/gQLnoF4aJXEAn6BeGiVxAuegWRoF8QLnol8fYV4iUkVMrLy9MjjzwiSdq+fbsee+wxjR49WuXl5Xr11Vfl8/kUCARUUlKinJwc5efna8mSJcrLy9PSpUt11FFHJaJMAAAAAAAAhCkhodK+ZGVl6ZxzztGECRMUCoVUUFAgh8Oh4cOHa+rUqRo/frxsNpv++Mc/JrPMhKgNSs8vld5f20H+kKEUi6nhvdwa2ssrq5Hs6gAAAAAAABozTNM0k11EPB2IQ+DmbnTqxdXpKqm2K7jXo2G3hJSTHtStx1fouM6+5BWINofhnggXvYJI0C8IF72CcNEriAT9gnDRK4mX8LO/ITzvFTv1+PJMbapqHChJkj9kUVGlXRO+zNK3u5I6qAwAAAAAAKARQqUkCoSkGavTVV5r3e/1fnDb9PiydgmqCgAAAAAAoGWESkn0XrFTW6rCG4G0sdKuteWMVgIAAAAAAG0DoVISLShNVcAMbxXuKr9Fcza4WrkiAAAAAACA8BAqJVEwzECpntvPwwUAAAAAANoGUookctlCEV2/W1qglSoBAAAAAACIDKFSEl10ZI3SwgyWujoD+k2eu5UrAgAAAAAACA+hUhL16+jX4Zn+sK57VHu/2qdENrIJAAAAAACgtRAqJdnEk8qVYQ/u9zrdnX7deWJ5YgoCAAAAAAAIA6FSkvVID6q7a/+hUq/MoNLtZoIqAgAAAAAAaBmhUhtgtHASuBB5EgAAAAAAaGMIldqATs79j1Q6LIOzvgEAAAAAgLaFUKkNuOyoarVPaT5Y6u4KaHTf6gRXBAAAAAAAsH+ESm1A/05+jelbpZxMSaqb62aRqV7pfv3l+Ap1TOWsbwAAAAAAoG2xJbsA1Lkwz63/OylLT31Wpc1VVh3dwa9zc91KsSa7MgAAAAAAgKYIldqQzJS6qXAAAAAAAABtHdPfAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxGzJLgB7eAPSvE2p2u626rDMgE7pXiurkeyqAAAAAAAAmiJUagNMU/rHynT9b6u0sby9QjJkt4TUKz2gC/NqdMERnmSXCAAAAAAA0AihUhvw+LJMzS5yqTYoSXVDk/whi76vdOjpFTaFTEMX5rmTWiMAAAAAAMDeWFMpycq8Fn24JVW1weYfikq/RbO+T1MglODCAAAAAAAA9oNQKcleXZum7Z79DxjbXGXTxyWpCaoIAAAAAACgZa06/W3dunV6+eWXNXHiRG3cuFHPP/+8LBaL7Ha7xo4dq6ysLBUWFqqwsFBWq1UjR47UoEGD5PP59Pjjj6uyslJOp1Njx45VZmZma5aaNFtrWn4IAqah7yvsGprjTUBFAAAAAAAALWu1UOmtt97SJ598otTUuhE2L7zwgq644grl5ubqgw8+0FtvvaXzzjtPc+fO1ZQpU+T3+zV+/Hj1799f8+bNU69evXTRRRfps88+06xZs3T55Ze3VqlJlWYPZ16bqU6pwVavBQAAAAAAIFytNv2ta9euuuWWWxp+vummm5SbmytJCgaDstvtWr9+vfLz82W32+VyudStWzcVFxdr9erVGjBggCRp4MCBWrFiRWuVmXQFfarVzrH/wKhHWkD/7zDOAAcAAAAAANqOVhupNHjwYG3fvr3h5/bt20uS1qxZo/fff1+TJk3SN998I5fL1XAdp9Mpt9stj8fTsD01NVVud/hnPsvOzo7Tb5AY2dnSz9ZKhRuav9xukc46wq4jD+ue2MLQ5h1ovY7koVcQCfoF4aJXEC56BZGgXxAueqVtaNU1lX5q4cKFeuONN3TbbbcpMzNTLpdLXu+edYI8Ho/S0tLkdDobtnu9XqWlpYV9jNLS0rjX3drGDZQ83g5aWZaq8to92zumBjW4m1fX9KnQAfhroRVlZ2cfkL2OxKNXEAn6BeGiVxAuegWRoF8QLnol8fYV4iUsVPrkk09UWFioiRMnKj09XZKUl5enV199VT6fT4FAQCUlJcrJyVF+fr6WLFmivLw8LV26VEcddVSiykyKVKv08GllKrdn64nPalQTsKhDSlCjjqpR9zTWUgIAAAAAAG1PQkKlUCikF154QZ06ddLDDz8sSerbt68uuuginXPOOZowYYJCoZAKCgrkcDg0fPhwTZ06VePHj5fNZtMf//jHRJSZdH07S+NPrEh2GQAAAAAAAC0yTNM0k11EPB3IQ+AYwodw0SsIF72CSNAvCBe9gnDRK4gE/YJw0SuJt6/pb6129jcAAAAAAAAcvAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARI1QCAAAAAABAxAiVAAAAAAAAEDFCJQAAAAAAAESMUAkAAAAAAAARsyW7AMRfhc/QS6vT9c1Oh7wBiwxJTltIp2bX6rd5NXLazGSXCAAAAAAADnCESgeRQEh6cEk7Lf4hRVvdTR/aFbscmrPBpTN7evSHflUyjCQUCQAAAAAADgqESgeJQEj6y2cd9NW2FAXVfFpkytCWapteW5emXR6Lxv2sgmAJAAAAAABEhTWVDhIPLmm330Bpb7VBi+Zvcer579ITUBkAAAAAADgYESodBCp8hr76IbxAqZ43aNGHW5wKhFqxMAAAAAAAcNBi+lsbsctr0dMfS6u2dVAgZMhuMXVMR58u6VOjdPv+F9Z+aXW6tjWzhlJLNlXZNG9Tqn6Z642yagAAAAAAcKgiVEqy8lqL7v2qndaW27XDI0mpDZd98UOq3it26diOPt12QrlSrc3v45udjqiOHTANfbDJRagEAAAAAAAiRqiURNvdFv1pQUcVVdr3eZ3SGptKa6wqrbHq0SFlctmajlryBqKfxVgbZKVuAAAAAAAQuVYNldatW6eXX35ZEydO1LZt2zR16lQZhqGcnByNGTNGFotFhYWFKiwslNVq1ciRIzVo0CD5fD49/vjjqqyslNPp1NixY5WZmdmapSZcICT9dWGH/QZKexhasStF4xa219+HlDVzaQzIlAAAAAAAQBRabaHut956S08//bT8fr8kacaMGSooKNDdd98t0zS1ePFilZeXa+7cubrnnns0btw4vfLKK/L7/Zo3b5569eqlu+++W0OGDNGsWbNaq8ykeXejU+vKwwmU9vi2zKFVZU1zQJct+tW2Y7ktAAAAAAA4dLVaqNS1a1fdcsstDT8XFRWpb9++kqSBAwdq+fLlWr9+vfLz82W32+VyudStWzcVFxdr9erVGjBgQMN1V6xY0VplJs3cYpeCZmTDhKr9Fs1cndFk+6nZXhna/2LezUmxhHR+b3fEtwMAAAAAAGi1UGnw4MGyWhuvLG0YdSGK0+mU2+2W2+2Wy+VquLx+u8fjadiempoqt/vgCj52eS3aUh3dzMPvK5re7jd5bvVID0a8r8MyAzq1e21UdQAAAAAAgENbwhbqrg+UJMnj8SgtLU0ul0ter7fJdqfT2bDd6/UqLS0t7ONkZ2fHr+hWUrFD8kSeAUmSArKrQ5dspf7kkfv1UdIL30ieQHj7aZcijT7eoR492v79heYdCL2OtoFeQSToF4SLXkG46BVEgn5BuOiVtiFhoVJubq5WrlypY445RkuXLlW/fv2Ul5enV199VT6fT4FAQCUlJcrJyVF+fr6WLFmivLw8LV26VEcddVTYxyktLW3F3yI+dlXYZJidFM1AMTMU0PZt22X7yU0vzZWKd7TT/C1OeYP732+GPajze7t1RscqHQB3F5qRnZ19QPQ6ko9eQSToF4SLXkG46BVEgn5BuOiVxNtXiJewUOmyyy7T9OnTFQgE1KNHDw0ePFgWi0XnnHOOJkyYoFAopIKCAjkcDg0fPlxTp07V+PHjZbPZ9Mc//jFRZSZEZ2dQGY6QagKRh0ppdrNJoCRJhiGN+1mFuqcF9eEWpzZV2RT4yZpNKZaQemUENPKIGp1/hCfa8gEAAAAAAGSYphn5Cs9t2IGSVt68oL0WbnNGfLsLelfr1kGV+71OICTN25SqDza5VBs0JKPuLG/n93br1O61MiJbHxxtEMk8wkWvIBL0C8JFryBc9AoiQb8gXPRK4iV9pBIauyS/Rkt3psgTwWilTqlBXd63usXr2SzSL3O9+mWut8XrAgAAAAAARKPVzv6G/RvU2acTOtfKUHgDxRyWkM7o6VFnZ6iVKwMAAAAAAGgZoVKSGIZ078m7dVLXWtmM/QdLTmtIw3I8+tOA/U97AwAAAAAASBSmvyWRwyo9fHqZZq5K1yclqdpU7ZA7sOfyDHtIuZl+nZvr1nm9WVgbAAAAAAC0HYRKSWY1pMv7Vmv00dXaEMzW299Wq9pvqJ0jpGG9PDqqfaDlnQAAAAAAACQYoVIbYRjSab2k3jamuAEAAAAAgLaPNZUAAAAAAAAQMUIlAAAAAAAARIxQCQAAAAAAABEjVAIAAAAAAEDEWKi7DanxSavK7PIEDKXZQ+rdLiA7sR8AAAAAAGiDCJXagKIKm57/Ll3rq6StVR3lCxlKtZrq5gqqfyefruhbpa6uULLLBAAAAAAAaEColGTPfZeuWevStNtn/XFL3dAkb9DQxiqLNlbZ9cW2FF3Tr0rn5HqSVygAAAAAAMBemFyVRDNWpenVNXsHSs37wWPTE8sz9eGWlARVBgAAAAAAsH+ESkmyw2PRrO/TVBPYf6BUb3etVc98mylfsJULAwAAAAAACAOhUpK8uCpdOzyRzT7cUmXTOxtdrVQRAAAAAABA+AiVkiBoSt/siHwqW1CG3i92tkJFAAAAAAAAkSFUSoIqn0UVvuju+mhvBwAAAAAAEE8kFElQG5SCoehuGwwZ8S0GAAAAAAAgCoRKSZDhMOWwmlHdNtrbAQAAAAAAxBOhUhK4bKa6p0V3GrfDMgJxrgYAAAAAACByhEpJcm6uWzYjslFHGfaQ/u/oqlaqCAAAAAAAIHyESklyzmEeHZ7pj+g2+e19ym/PSCUAAAAAAJB8hEpJYrNIk0/ZrV7p4QVL+Vk+TT55dytXBQAAAAAAEB5CpSTqmR7UY0N2aUCnWmU6ml9jqWNKUKd29+rJX+xShoNFugEAAAAAQNtgS3YBh7puaSFNO2OXvq+w6bWNXbRxV638IUMOi6nczICu6Fulrq5QsssEAAAAAABohFCpjTiiXUBPniOVlu5KdikAAAAAAAAtYvobAAAAAAAAIkaoBAAAAAAAgIgldPpbIBDQ1KlTtWPHDlksFl1zzTWyWq2aOnWqDMNQTk6OxowZI4vFosLCQhUWFspqtWrkyJEaNGhQIksFAAAAAADAfiQ0VFq6dKmCwaDuvfdeLV++XK+++qqCwaAKCgp0zDHH6JlnntHixYvVp08fzZ07V1OmTJHf79f48ePVv39/2e32RJYLAAAAAACAfWhx+tvMmTO1bdu2uByse/fuCoVCCoVCcrvdstlsKioqUt++fSVJAwcO1PLly7V+/Xrl5+fLbrfL5XKpW7duKi4ujksNAAAAAAAAiF2LI5XS09N17733qmvXrho2bJhOPPFEWSzRLcWUmpqqHTt26E9/+pMqKyt12223adWqVTIMQ5LkdDrldrvldrvlcrkable/PRzZ2dlR1dZWHOj1I3HoFYSLXkEk6BeEi15BuOgVRIJ+QbjolbahxVBp5MiRuuCCC7Rs2TJ9+OGHevnll3Xqqadq+PDh6tChQ0QHe/fdd3Xcccfpd7/7nXbu3Km7775bgUCg4XKPx6O0tDS5XC55vd4m28NRWloaUU1tSXZ29gFdPxKHXkG46BVEgn5BuOgVhIteQSToF4SLXkm8fYV4YQ05MgxDHTp0UIcOHRQMBrVlyxZNmDBBH3zwQURF1AdGUt0IqGAwqNzcXK1cuVJS3ZpLRx99tPLy8rRq1Sr5fD653W6VlJQoJycnomMBAAAAAACg9bQ4UunDDz9UYWGhKioqNGzYME2ZMkWZmZmqrKzUzTffrGHDhoV9sF/96ld66qmndNdddykQCOiSSy5R7969NX36dAUCAfXo0UODBw+WxWLROeecowkTJigUCqmgoEAOhyOmXxQAAAAAAADx02KotHDhQo0cOVLHH398o7WUMjMzVVBQENHBUlNT9ec//7nJ9kmTJjXZNnToUA0dOjSi/QMAAAAAACAxWpz+9uc//1mbN2+WxWLRjh079OKLLzasd3TWWWe1eoEAAAAAAABoe1oMlZ566ilVVVVJUsNi2dOnT2/dqg5RtQHppdVpunNRe83Z4FTITHZFAAAAAAAAzWsxVNq2bZsuu+wySZLL5dLo0aO1ZcuWVi/sUGOa0ui3pKdWZGr+Fqce/DpL93yZleyyAAAAAAAAmtViqBQMBuV2uxt+9nq9Mk2G0MTb8l12fbNNMmVIkgKmoa+3O1TmDesEfQAAAAAAAAnV4kLdQ4YM0bhx4zR48GAZhqEvvvhCZ5xxRiJqO6SUea3yBBpvqw0aqvEb6pCanJoAAAAAAAD2pcVQ6YILLlBOTo5WrFghq9WqSy+9VAMHDkxEbYeUk7vV6vAsqah8z7Ye6UH1TA8mqyQAAAAAAIB9ajFUkqQBAwboqKOOavi5urpa6enprVbUoSjVZurvZ0sT5teqwmdRF2dQtw0ql2EkuzIAAAAAAICmWgyV5s2bpxkzZigQaDw367XXXmu1og5FIVNa9oNkSEqxmAqZ0qrddnVLq012aQAAAAAAAE20GCrNmTNH99xzj3r37p2Ieg5JpimNW9Ren22V/KGUhu0ry+xavtOjPw6oTGJ1AAAAAAAATbV4arGsrCwCpVb24ZZULdqaIn+o8XZ3wKr3Njm1qdKanMIAAAAAAAD2ocVQqX///po3b57KyspUXV3d8B/i592NLtWGmn8oymutenkt61cBAAAAAIC2pcXpb2+++aYCgYCee+65RttZUyl+aoP7X4272t9i9gcAAAAAAJBQLYZKL7/8ciLqOKR1cwX3eZkhU/ntfQmsBgAAAAAAoGUtDoEJhUJ6++23NXXqVHk8Hs2ePVuhUKilmyEClx9dpc6pgWYvy0kP6Ld57gRXBAAAAAAAsH8thkovvfSSNm3apPXr18s0TX3zzTd68cUXE1DaoaNnRlDXH1ep3HZ1I5MkyWaYOjzTrztP3C2nzUxyhQAAAAAAAI21GCqtWLFC1113nex2u1wul+68806tWLEiEbUdUob38mru76WbBlTowiOqdfsJuzVz2A4d27H5EUwAAAAAAADJ1OKaSjabTRbLnuzJbrc3+hnx47JLFx3JVDcAAAAAAND2tRgq5eTk6L333lMoFFJpaaneeecd5ebmJqA0AAAAAAAAtFUtDjkaPXq0NmzYoIqKCo0fP15er1ejR49OQGkAAAAAAABoq1ocqeRyuXTttdcmohYAAAAAAAAcIFoMlZ5//vlmt19xxRVxLwYAAAAAAAAHhhanv2VkZDT853Q6tWrVKhmGkYjaAAAAAAAA0Ea1OFLpt7/9baOfzz//fD344IOtVhAAAAAAAADavhZHKv2U0+lUWVlZa9QCAAAAAACAA0TEayoVFRWpR48erVYQAAAAAAAA2r4WQ6WMjIyGfxuGoSFDhui0005r1aIAAAAAAADQtkW8phIAAAAAAADQYqg0duzY/Z7t7cknn4xrQQAAAAAAAGj7WgyVTj/9dFVWVmr48OGy2Wz6+OOPVVZWpl/96leJqA8AAAAAAABtUIuh0vLlyzV58uSGny+99FLdfvvt6t27d1QHnD17thYvXqxAIKCzzz5bffv21dSpU2UYhnJycjRmzBhZLBYVFhaqsLBQVqtVI0eO1KBBg6I6HgAAAAAAAOKvxVCppqZGlZWVyszMlCTt2rVLgUAgqoOtXLlSa9as0T333COfz6e3335bM2bMUEFBgY455hg988wzWrx4sfr06aO5c+dqypQp8vv9Gj9+vPr37y+73R7VcQEAAAAAABBfLYZKv/zlL3XzzTfruOOOkyStWLFCY8aMiepgy5YtU69evfTwww/L4/Ho0ksv1fz589W3b19J0sCBA7Vs2TJZLBbl5+fLbrfLbrerW7duKi4uVl5eXlTHBQAAAAAAQHy1GCqdffbZOvLII7Vy5Uo5HA5deOGF6t69e1QHq6ys1M6dO3Xbbbdp+/bteuCBB2SaZsNC4E6nU263W263Wy6Xq+F29dvDkZ2dHVVtbcWBXj8Sh15BuOgVRIJ+QbjoFYSLXkEk6BeEi15pG1oMlSRp+/btqqmp0bBhw7R48eKoQ6WMjAz16NFDNptN2dnZcjgc2rVrV8PlHo9HaWlpcrlc8nq9TbaHo7S0NKra2oLs7OwDun4kDr2CcNEriAT9gnDRKwgXvYJI0C8IF72SePsK8Swt3fDNN9/UvHnztGjRIvn9fr3++ut6/fXXoyriqKOO0jfffCPTNFVWViav16t+/fpp5cqVkqSlS5fq6KOPVl5enlatWiWfzye3262SkhLl5OREdUwAAAAAAADEX4sjlT777DNNnjxZ48aNU0ZGhu677z7deeed+s1vfhPxwQYNGqRVq1bpjjvuUCgU0pgxY9SlSxdNnz5dgUBAPXr00ODBg2WxWHTOOedowoQJCoVCKigokMPhiOoXBAAAAAAAQPy1GCrZbLZGZ11LS0uT1WqN+oCXXnppk22TJk1qsm3o0KEaOnRo1McBAAAAAABA62kxVOrYsaOWLFkiwzDk9/s1Z84cderUKRG1AQAAAAAAoI1qcU2lK664Qu+8846Ki4s1atQoLV26VFdeeWUiajsklVRb9dGWFO3ytvjQAAAAAAAAJE2LI5W+//573XXXXaqtrVUoFJLT6UxEXYcc05T+9L704YZOKq+1qrMzoF8e5tEfjq1KdmkAAAAAAABNtDgc5tVXX5UkpaSkECi1og+3pOrddVJ5bd16VTs8Nr21waXiyujXrwIAAAAAAGgtLY5U6tWrl9544w0dddRRSk1Nbdjeu3fvVi3sUPPxllTVBhtvK6+16oPNTl15THVyigIAAAAAANiHfYZK//rXv1RQUKDPP/9c69at0/z58xsuMwxDTz75ZEIKPFRkpwebbLNbQuqdGUhCNQAAAAAAAPu3z1Dps88+0/Dhw9WzZ09NnDhRpmnKMIxE1nZI+X1+tRZtz9C6sj3b8rMC+nlPb/KKAgAAAAAA2Id9hkr9+/fXtddeK0kaM2ZMk8tfe+211qvqEJTpMPXKSOmP73i0w2NV73Z+3TqoUlZyPAAAAAAA0AbtM1S66qqrdNVVV2nChAmaNGlSIms6pARC0tyNTs1cna4dXqk2mCrJ0PoKuz7e4lRORkBX96vSad1rxUAxAAAAAADQVrS4UDeBUuuZvyVFz6/M1IZKm0zVJ0Z1/zdlqDZkaH2FQ3cs7KAjsvy6eUCFju3kT17BAAAAAAAAP7Iku4BDUciU7v2qnaYszlJRpX2vQKl5AdPQmt0O/XVhBz27Mj1BVQIAAAAAAOxbiyOVEH93f5ml+ZudCpiRzWfbXWvVv9amKWQaurpfVStVBwAAAAAA0DJGKiXYm9879UlJasSBUr2agFVvFrm0bKc9zpUBAAAAAACEj1Apgar9hl5Zmy5PMLa7fXetVX9f2k4hM06FAQAAAAAARIhQKYFeWZOuzdXxGWG0sdKm/5WkxmVfAAAAAAAAkSJUSqDPt6XEbV+1IYveKnLFbX8AAAAAAACRIFRKkBq/oV3e+N7dO73WuO4PAAAAAAAgXIRKCVJUaVNZnEOg8lqLKmqjW/AbAAAAAAAgFoRKCVLls0R9xrd98YekmgAPIQAAAAAASDwSiQRJtZqyKL6na7MaksPCKeAAAAAAAEDiESolSG5mQO1TQnHdZ6YjpI6p8d0nAAAAAABAOAiVEqRDakjtU4Nx3WfH1JAMllQCAAAAAABJQKiUQH07+OO2L4tMnZ7tidv+AAAAAAAAIkGolEBX9K1SZ2cgLvvKyQjogiPccdkXAAAAAABApAiVEqirK6ShOZ6YF+x22kL6fX61UqxxKgwAAAAAACBChEoJdt2xVTq2ky/q21tk6uRuXo04PLypb56Aodr4LuUEAAAAAABAqJRoNov0t9PKdFyn2ohHLDksIZ2W7dWkk8rDuv7La9J0yXud9bv3u2j+5tQoqgUAAAAAAGgeoVISpNlNPfnzXfrtkTXqFOYZ4bLTArq6X5WmnLJbtjAftfeKnfrBY1NpjU2vr0+LoWIAAAAAAIDGbMk4aEVFhW677Tbdeeedslqtmjp1qgzDUE5OjsaMGSOLxaLCwkIVFhbKarVq5MiRGjRoUDJKbTU2i3TTgEpdfGSNnv8uXd+VObTdY1d1wwniTGU5QuriCmpgZ5/+7+hqtU8JRXSMDPuekVDtUyO7LQAAAAAAwP4kPFQKBAJ65pln5HA4JEkzZsxQQUGBjjnmGD3zzDNavHix+vTpo7lz52rKlCny+/0aP368+vfvL7vdnuhyW133tKDG/axCpimVO7I1enZAOz1W9UgP6Mmf71IXV/Rh0H2n7NYTyzKUajV1w3FVcawaAAAAAAAc6hIeKv3zn//UsGHD9Oabb0qSioqK1LdvX0nSwIEDtWzZMlksFuXn58tut8tut6tbt24qLi5WXl5eostNGMOQHBbJakgpVlN2iylHjGd3a58S0l0nVsSnQAAAAAAAgL0kNFT6+OOPlZmZqQEDBjSESpJkGIYkyel0yu12y+12y+VyNVxevz0c2dnZca05kY6fLu3y1j0kRZUO3bCgm+ZfluSi0GYdyL2OxKJXEAn6BeGiVxAuegWRoF8QLnqlbUhoqPTRRx9JklasWKGNGzfqySefVEXFnpE0Ho9HaWlpcrlc8nq9TbaHo7S0NL5FJ0ggJFX4Gv9RbKkMqbR0W5IqQluWnZ19wPY6EoteQSToF4SLXkG46BVEgn5BuOiVxNtXiJfQUGnSpEkN/544caKuuuoq/fOf/9TKlSt1zDHHaOnSperXr5/y8vL06quvyufzKRAIqKSkRDk5OYksNeFsP059C+y1zW4x93n9cDy7Ml0fbXHKYpi68IganX+EJ7YiAQAAAAAAfpSUs7/t7bLLLtP06dMVCATUo0cPDR48WBaLReecc44mTJigUCikgoKChoW9D2Y3/Ex69AtTAVNyWEyNP3F31PtauDVF/1qbrpqARZL0j5VWDeriU05GMF7lAgAAAACAQ1jSQqWJEyc2/HvvEUz1hg4dqqFDhyawouS74STp9E4/qKTapsMzA8pKif7Mb8t3OhoCJUkqq7VqfYWNUAkAAAAAAMSFpeWrIJG6OEMa2NkXU6AkSSd39yorZU+A1NUZUN8O/ljLAwAAAAAAkNQGpr+hdRzXya9r+1Xq3Y11Z9EbfXS1urpiC6oAAAAAAADqESq1MYGQ5AkYctlNWY3Y9vXr3h79ujeLcwMAAAAAgPgjVGoDTFP6uCRV7yySisq6KBiSHFbpsMyALs2v0sDOTFsDAAAAAABtC6FSkoVMacLnWVpQmqrakLT3Q1JSY9OKnQ6NOLxGNxxXlbQaAQAAAAAAfoqFupPsb0sz9XGJU7Wh5h+KKr9Fbxa59K+1aQmuDAAAAAAAYN8IlZKo2m/o822pCpj7XzzJHbDqvxudCpkJKgwAAAAAAKAFhEpJ9NraNJXWhDcDcVOVTZ9tTWnligAAAAAAAMJDqJRE31faw75ubcii5TsdrVgNAAAAAABA+AiVkmj/k96askR6AwAAAAAAgFZCqJRER7f3yVB4CyU5rSEN6lLbyhUBAAAAAACEh1ApiS7Mc6tHWjCs6/bKCOhnXXytXBEAAAAAAEB4CJWSyGkzdWwnr9TCaCWLTA3Pcctg+hsAAAAAAGgjwjv1GOJubblNT6/I0Jc/pKql1ZVCMjR9ZabWVth1Tb9qdQ9zdBMAAAAAAEBrIVRKsJJqqyYvztK6cruq/OEPFPOFLHp/U5q++iFVx3T0adwJ5WqXEt56TAAAAAAAAPHG9LcECZnSC6vSdf3/OmrJjpSIAqW9ldVataDUqas/7KT/bnTGuUoAAAAAAIDwMFIpAQIh6c5F7bVoW4p8ofjkeJuq7XpkaaZW7bbrzwMqWW8JAAAAAAAkFKFSKwua0m0L22vR1lSFWlg7KVI1AavmbHApGJJuHVQZ130DAAAAAADsD9PfWtmUxe30eSsESvVqgxa9V+zSi6vSWmX/AAAAAAAAzSFUakWLtqZoQWmqgq0UKNXzBC16syhNm6usrXocAAAAAACAeoRKrcQTMPTk8kxV+BIT9Pzgtuner7IU4oRwAAAAAAAgAQiVWslzK9NVVGlP6DFX77Zr3qbUhB4TAAAAAAAcmgiVWkHIlL74ISXhx/WFLHq7aM/aSuvKbbp/cTs9vCRTpTVMjQMAAAAAAPHD2d9awcclqdpUlZy7dkOVTZsqrfpvsUtvFrkapt/9r8Spy/tWauQRnqTUBQAAAAAADi6MVGoF7xc75Qsl564tr7XqpTXpemejq9F6Tju9Vv1rbbq8gdZdNBwAAAAAABwaCJVawS5vcqeardhlb7aGkmqbvitL7DpPAAAAAADg4ESoFGe1QanMm9y71Rs0ZFXT08A5baYyU0JJqAgAAAAAABxsCJXibGuNTZW+5N6tpmmoV2agyfbDM/06opntAAAAAAAAkSJUijNv0JA/yYOBQpLuGLRb/TrUqkNqUJ1SAxrU2av7T9ktgyWVAAAAAABAHCT0FGWBQEDTpk3Tjh075Pf7deGFF6pnz56aOnWqDMNQTk6OxowZI4vFosLCQhUWFspqtWrkyJEaNGhQIkuNmvHjf8mu4YisoP5x1i7t8lpkM0y1S2k6HQ4AAAAAACBaCQ2VFixYoIyMDN1www2qqqrSrbfeqtzcXBUUFOiYY47RM888o8WLF6tPnz6aO3eupkyZIr/fr/Hjx6t///6y29v+ItMuW0gOq1SbxNFKVkNyWOtCpI6prKEEAAAAAADiL6Gh0sknn6zBgwc3/Gy1WlVUVKS+fftKkgYOHKhly5bJYrEoPz9fdrtddrtd3bp1U3FxsfLy8hJZblS6pwWV6Qipyp+8mYXtU0KyJnu4FAAAAAAAOKglNFRKTU2VJHk8Hj3yyCMqKCjQP//5Txk/LvTjdDrldrvldrvlcrkable/PRzZ2dnxLzxC3TOlkprkHb9ne4eys7MVMqXicslqkXIyxXpKB5m20Os4MNAriAT9gnDRKwgXvYJI0C8IF73SNiQ0VJKknTt36uGHH9bw4cN12mmn6aWXXmq4zOPxKC0tTS6XS16vt8n2cJSWlsa95khl2bIkuVq6WqvpkVKpaZ8GNWt9mra5bbIYprLTghrTt0qnZtcmrS7ET3Z2dpvodbR99AoiQb8gXPQKwkWvIBL0C8JFryTevkK8hM7RKi8v13333aff//73OvPMMyVJubm5WrlypSRp6dKlOvroo5WXl6dVq1bJ5/PJ7XarpKREOTk5iSw1Jr/Jq5HLGkzKsbs4A+qcGtS0FZlaV+FQld+iCp9Vq3Y7NOXrdvpuV8JzRAAAAAAAcBBKaMIwe/ZsVVdXa9asWZo1a5YkafTo0XrhhRcUCATUo0cPDR48WBaLReecc44mTJigUCikgoICORyORJYak/4d/cptF9R3ZdaEHzuvXUBzN7lU4Wt67J1em577LkN/O313wus6kHiD0pvfu2QxpAuOcMuevOWxAAAAAABosxIaKl1++eW6/PLLm2yfNGlSk21Dhw7V0KFDE1FW3BmGdFZPj1aV2WUqcQsZ2Y2QLu5TrfsXZ+3zOjs8jFTan6Ap3fRJRy3b6ZAhaUGpU48P2cV6VAAAAAAA/ARjMFrJxX1qdGSWP6HHPLFrrX7WxSeHxdzndez7uQzSdrdVxZU2SYZMGdpQaVOFjz8TAAAAAAB+ik/LrcRqSBNP2i2HJZSQ46XZgrrrpHIZhnRkVmAf1zI1oDMLde9Pu5SQ0ux7grc0W0hp9sQ8hgAAAAAAHEgIlVrR4ZlB/bp3jaTWHR1kkak/DqhUpqPuOLccX6Ej2/kaHdciU8d18umqflWtWsuBzmUzdcvx5erfsVb9O9bqr4MqWFMJAAAAAIBmsMBOK7t5YJU+35qqLTV1U6riz9TJ3bwacbinYUtWSkjTztilV9amacVOhwxDOrmbVyOPcMuR+LXDDziDu/k0uNuuZJcBAAAAAECbRqjUyjwB48cgp7VWejZU5bcoZEqWvQ6RZjd11THVrXRMAAAAAABwqGNiTyv729JMFVXaW/UYq3bb9c/Vaa16DABAcmyusmrJDodW77YryLkWAAAA0IYwUqkVVfsNLd2e0urH8Ycsmr/ZqVFH1TQarQQAOHDN2eDU2xvStKnKqiqfRSlWU9lpQf2sq1dj+1ex3hsAAACSjlCpFb2yJl2l7sTcxZuqbFpQmqKf9+DsbgBwoHt8WabeLnKqJrBnITxv0FBRpUUbKm1aV+7Q30/fxTp5AAAASCq+52xFi7c7Enas2pBFcza4Gm37fJtDoz/opDHzO2ldOfkhABwIFpSm6O0iV6NAaW+mDC3d4dDflrZLcGUAAABAY4RKrcQfknZ5E/sV8k+Pd89XWVpT7tB3ZQ7duah9QmsBAETn3+vSVBPY/8tzfbDkDSaoKAAAAKAZhEqtpKjCpjJvYu/eMq9FNf49iypV1e4JmXYmOOACAETOEzC0qSq8kaUl1TYtKElt5YoA4MAxb5NTDy/J1KYq3vcCQKIQKrWSdeV2eYOJvXur/BZtrdnzIuq07fkKu0tqIKG1JNp2t0UvrU7T7lpaGsCBq8pvyB8K74wLIRna7uGDEwBI0hvrXXrw60zN+j5dt3zaQVU+zl4DAInAJ/BW4g4k/oUsEJJqf/wwsrnKqkp//cNrqrTGqorag/fF9Y5F7TV1RTum+QE4oGXYTTksZljXtchUFyfz3wBAkpbsSGlYi26Hx6rSGtYTBYBEIFRqJSlJ+PLYakhmSJq6PEO/e7+L9jy8hnymVee901WvrnEpEEp8ba3N+mNeZjPC+zAGAG2R02YqJyO8kaU90wM6vYe3lSsCgAPDL3Pd6phaF7TnZgZ0WKY/yRUBwKGBCL+V9MoIyG4JyR9KXG7nspl6YEk7ra+wS2o6Kqk2ZNETy9tpwVanHjq1TGn2gyOA+fe6umlvLmtQ2zxWzdng1IjDPckuCwCiUnBkjVbvdqjav+/XD0OmBnb2KZXZbwDCsMNjUbrdlNN2cLz3a84p3Ws17Yyd2lBh0wldeX4EgERhpFIrOaq9Xx1SEzskqNpvaH2FQ80FSvXqzhiUor982iHiEUuvrE3Thf/tonmb2s7CsJsqrXpxVbo2V9vlDlq1qcquZ1dmaKeH1gZwYDo1u1bnHV6jNFvzU9ssMjWoi083H1+R4MoAHIieXpGh0R901ujCTtpWc3C/P8pJD2pIj1q5DuLwDADamoP7lSWJnDZTHVISGyr5IhgVtWynQ/9Z7wr7+m8WOTVteYZKa2ya/FWWPt/miKbEuHtzg0u7axt/FbXdY9N7xc4kVQQAsbv+uCr9aWCl+nesVTtHUBaZctpCymvnU0Gfav399F2y8woOIAxLdzhUVlv3xdvnP7SdLwYBAAcHpr+1ovz2fq3anajwxdT+Rij9VEiGPtzs0iV93GFd//NtqQqYdZ9gakMWzd/s1OBuvmgKlSSZprTTa5HFkDqkhGREuYZ4V2dQhkyZe/3uNsNUFxeL1wI4sJ2b69G5uR5tqbZql9cqly2k3u0CDWvIAUA4huZ4tMtrVYYjpDN6sDwAACC+CJVa0eVHV+nT0lTt9LbNSd0bKm1at9umI9u3vCjsgE4+/a8kRZJFdoV0SvfoFoc1TWnm6jS9V+zUlmq7DEm5mX79urdbv8kLL+Da2697e/T2hjQVVdobth3Rzq8ze7J4LYCDQ8/0oHqmE5QDiM5vj3Trwjy3LATSAIBWwOD5VtTFFVJ++0SceSKyUUr1agIWFVWGlyue1t3bcAy/DA3qEt0opSlft9Pz32VoY5VDAdOQ3zS0rsKhaSsyNHV5RsT7c9pMPf7zXQ1nfbNbQnpsyC7Z6GwAAABJIlACALQaPnq3stsGlSs7LbzTQ0ernSP6tZsCZnjvMgo3N56Dv3R75NP6iips+l9JarNrP7kDVs3b5NQub+Qt2TE1pII+VWrnCOqqvlVql8LijOGq9Bl6aU2aKmp5twkAAAAAiAyhUivr5Ayp4MhqOa2ts2h3liOo4Tlu1Y1WiozDElKPMAOvxdtTtGc0lKG5xeEv8l3v5TXpqvDteyrgdo9Nr6xJi3i/ZV6LZq1PV4XPoplr0lXtjz0g2eGxRBVwHWjuWNhBU5e3018Xdkh2KU2sLrPprs+z9M2OtrEofGt67JtM3f1llkLkoQAAAAAOIAf/p+Y24Dd5bp2Z45HdEt9gKd0WVEGfal1zbLUyoxit1MkZVP9O4U3P++nCsA5r5J9+K30thz3bPZGvP/WnBR3kCVokGar2W/WXBe0j3sfettZYNWZ+J105v5N2etren8gOj0U/VMe+H39I+r6ibvrjhkqbvG1syZYHlmTpg80uPbSkXbJLaXWLtqXo6+0OeYOMGAMAAABw4GCh7gQwDGncCRUyJBVudsobjD2oaOcI6qIja/R/R9dIkjIdIVXuZxRQc3plBMOeY2+aIe1Zu8lUTlrkayplpbQcfHWP8KxtgZBU/JN1odaUO2SaivqMckFTCoYMyWK2uZEjQVO6aG5nGYb0wflNw75ImKaUZjdV7pPSbKZk1j22bUX7lJCshhnT9M4DwZYqq4b29Kg2aKik2qojs1p3uiwAAAAAxEvbG4ZxkDIM6Y4TKnTtsZXKdsX2oTE3w6/bB5Xrir57hquc2i3Ss52ZOjc3vLOtFVVa9dUOp/ae/vb86sywRh7t7bKjqpWVsu/QqKsroN/l10S0zyXb7fL/JHPwBaV15dGfcc8iqTYoeQNGFMufNxUy60YCmXHIaxb/4JA3aJEnIH31Q2zTwhxW6ZRuHqXZgjqxq1epttgKNE3pnQ1OvVnkisvvOuWUMk39xS49cnpZ7DuT9PGWVL2zwRmXfYVM6bV1aaqNYXTXunKbxn7cUVd/1EnPrcrUS2szNPbjTrr6w476YlvbmfL3341OzVgV+bRUoC3YXGVV4ODOpQEAAJKKUCmBDEO66Ei3pp+5U73S/Yp0VIghU8d38urZs3bq5z1rG112cR+3Mmzhf8LtmhrUKd1rW76ipPu/ylLTs8sZenxZZtjHk6ScjKCG5XiUYjR9h59uD2pErjus0Uz11pXbNHlxe4V+0sZBWXTHog7aUh1dsDRtRYZqAlZV+a2auTq2D9OlNVad/24X/e79zhr5bmf9UBPbn1yf9gHZZMpuSPntYwsnl+yw6/Xv01QTsOqtDWn6PMYg438lKfrb0nb6+9JMvbsx9vDGbpHW7bbJZonP6KmagKGaQHyml63cZdO05Rn6pCQlqtuvKrPpr5910JIdKdpdu6dPq/wWrdiVonu/aq+PtkS3b0naVGWN2yi7p1dkaObqdPnb2PTI1lBUYWtzoxPjyTSlt4qc+uMnHTT24456YlmGauKwBl1bVVFr6Mr5nfXCd+nJLgXAftT4DcJfADiAESolQSdnSP/6fzt0Sjevwg2WrIapC4+o0dQzypRmb3qb7mlB9YkgZDi2s0+uMEem1ASaaxMjqoWs/zywUpceXaXGv3dI1/ev1JhjIlso6KnlmfrB0/wMzpIau6Yujyz0que0BH6sz1SWI/rgxh+SbvusvXZ4bJIMbfPY9deFHWJ641TtkwIy5Dfr/h2Lb3c5ZDY8BRhauSu2UCnVJpmhuv+cMY56kqRdHmn6t+kqiTIc/Klzcz26+MjwRue15M5FHVQbsuihJVkR39Y0pQe/ztJW975nH+/0WjX920z5oghyZq5y6ZL3uui2z2JbW6yBIRkyolrv7EAzblH7NrmOWrxM/CJLjyxtpy9/SNWSHSl6ZW2Grvu4o6oiHHV6oMh0mLppYLkuOjKyEbCJ4gkYbTbE/MNHHfW/KENzIBJlXotGzeusOxbG6TUrzmZ/79KqMlYLAYD9OXjfPbdxhiE9eNpuDezc8mghQ6bO712jm4+v3O/1ru9foa7OlkOQXul+3dB///va28VHVqtp+GXq/46KbrXounWgGodK5/X2RLQPb8DQxqr9v8h/XxHdlLPvdu4JV9btjj5oKam2NQkOtrmt2uaO7sP50h0O3fC/Tg0/3/C/TlqyPfr6zs31yKagJFM2BTXi8NgCl+01FtWahvwy4vLB/Ir5nVUdsOryDzrGvC9JWlRq0wfF8fmQlOGou99Sojir4+LtDhVXt/wGdXOVTW8VRX6WxXnFToVkaNkOe8S3bU6GLSSHxVR2WnyGKtX4jbhMj5TqRox9vCV+UwVf/X871MUVn6/Lv9tl07zi1LjsKx5Wl9m0aFuqfKHGf5tryx16dmVG1Put9hu676t2Wr4z9n7b7rbo9oXt9ecFHfRhDCP16n2+za6Hvs7S3V9mxbyveHuv2KlL3uusv3za9s68aZpSF2dA7fczXT0StUFpexzD2oVbU+I2ws4bqPuCLF7PSYhcqs1UV1dQvTLb3nqC/pD03HcZevrb6L6kBIBDRZsNlUKhkJ555hmNGzdOEydO1LZt25JdUtxZDWnyyeVq38JomJ7pAd00oOUQ6KgOAd15YvmPwVJz75BMHZbh1/2nlEX0wWnE4Z4m+3NaQhrQObwzx/1UMGSo8XQ6q4IRvqHzBA35Q/t/U+kLGgpE8UZxo9uuuvoMfR1DaJNur/swvje7xVR6MyPNWhIISQ8taffjyKy63/sHj00PL20X9cinjqkhBVR31ryALDF9mDZNadq3maq/3577LiOmN+mBkLTDa5VkyBOyyB3jtLXPSlP05886664vO2huHKbm1U1jNLTTG3lAOLfYJU+zo/8aC8nQFz9E/sE6r13d1FpbnM42WVxl026fJeK/0ea8+b1TQ9/spls+zYp5X1uqrbryw866fVFHzVgVefj2UyXVFp0xq5tmrY9P8PiHjztpwpft4/Zh9ftyi0IxPKRzNrhU5W++79bsjj4QmvV9mt7ZmKa/LY3tQ1cgJP1pQUd9XOLUom2pmrI4S9/siC0w/KzUKU/Q0Ldl8Qket1Rb47a+2Dc77PrBY41b+GuadQFJPPxjZboKN7t0d5z6d+zHHfXb/3aJy4i41bttGreovcYtin1Uy4LSFF06r7Mum9dZf14Q2yji1lBYnKIr53eIasRqa3uv2KlJX2SpLIoR6z/lspl6dMgujT22Kg6V1f0t/HStzWi5A4ZkhmRTfHZYXmvRnA1OQsyDyLe7bLp/cTvtcLfZj9RxU+kz5InT6wwOPm32L+Crr76S3+/Xfffdp9/97neaOXNmsktqFVkpIQ3osu9wxpCp07K9soX5SJ3QxadHh+ySvZlQKd0W0jNn7FTvdpG9Q7EY0tk5ewdLpq48JvoX/+Kqph/EI51Kl2EPKcO+/xf5TEdI9gg73DSlununbvpbTSj6P5FOzpBObjTF0dSp3WsjWjeq3opdDm1uZmTW5iqblu+M7gNT3bSLPbXF8ob6hVXpKvftua+q/BZNWxH96AdvcO8XLUOVvugfhyXbHZq8OEv1gdffv8nUB5tiG0HiCUrRnikvkje7QTPyF++FpXX9UBbh2SD3WcOPIWZ1bexvJD7eXFfbwm2xBzff7TUdYcHm2EcE3fxJe3lDFj28ND5TMOof53h8dvhgo12XftBVv5jVqeUr74NrP2G2NYZ3At2cPkmm1pbHNj1kh8eqTXs9x1X5rZob40ivn3WtGwnsj3GqcL1L53aI24iFyh9rqonD2WAl6doPs3Tm7K5xCX+r/BaZkmr8lrh8lM52+uQPqdmp+5H6fJtD3qChlbvsMX8wn7EqXSU1NpXVWvXVDyn6X0ls/Xb/4kyd/J/uOuONrvq+Ivbn30eXt9PKshR9F4dQdPb3Tp38n2466/Uuqo1xQJAnYGjaigy9t8mlB75uF3Ntbr+hM97ortHz4jNq77J5HTVkVnd99UPsge205enaVWvTwh+cCsbhj+HRpRm6f3GWNsdpWn+1L35rUZmm4hYYhEzpl2930R8/js/r6eoymy78b+c2F/xK0v2L2+vtDWmaEoe/hXgrrzV0+8KsuE2zvu6jTro1XksrtFGmKb28Jk1/Xdhes7+Pz8l9DhVtNlRavXq1BgwYIEnq06ePvv/+++QW1Iru/Fm58rOae9dranC3Wo3tH1mAs6nKJn9zD61hqKw2yhcyY+/RRYYq/dG/IHZzNQ21siI8bbzNIvXvtL9PCqZO7BreQuR7211bNwKl/j+LYkvl+3b0a+/7rd9+a943Q5JhNPOqYJiyxPQeID6vNAtKU9V49Jmhz2MIDlKsZqP9uaKYZlZvdpGrUd9X+a2atym2F4pgDE+dvTLCf0ffPooAsja0p99itXcA/GFp7C+uZTXxq+0X2Xv+vocfFtn02eZ0cOxrhGe0fgzj4jBNp6S6rt/8iv5596Ija9S5menRNsPUqd0jPXvoHi+tSlPd7xrb24mmvW6qQ0psj8fyHXU1eeLQb/6QVPvj/V8f3MZidVmK6ntkRRymDi4rc8qUoW+2xb6vK/vWveco95myxuEz5gcldbXF9lpV538lLkmGqgMWeWMcwbP3+V1NKab6PilJ0Tsb6mrzBq2avDj2D15ub93f6/7f64TnsW/aSbLIbVo1J8azoNotprZ7DEmmujqjG7G+t3u+bCdT0trKlKjW6vyp9ZV1fwMfF8f+d3rEXlPyjDj07/ubU2RK2lQZ++9ZXmvRsLe66fRZ3WMvTNIpr3fWmbO76allsZ/YwJC0u9aqL3fEZ+TvjfMzVFpj05Lt8RnZefJ/uunk/3SNy74ybXXLIfRuF5/pmyf/p5OG/ScrLvsaPa+TPi5x6tY4jA43Ten7SqsWxzCDY2/Pf+vSyf/prs9K4vWYdtYZ/4k9mH51XZqe/TZDn5Q4NXV5pt4rjv2974OfOzVt8cG/RmGbDZU8Ho9crj1TGiwWi4LBNjgGOA5cNlPPnrVTN50o1Y+QkUzddeJu/e20sojf1B2Z1fxaCO0cQXVpJtAJxwVH7L0Okqlf5ka//k67FPPHJ+E62a6AHFF8VvrTgEr171irph8ETZ3QpVbXRDGUOs0eUpZjz/7ap4Z+DDii0ydr77P8mT9OTYrcsZ186pXR9LE7LCOoY6N8w1n3Btr3Y32+sEfDNae5b/CiGWWz57aNfw7EsK/mzh4X64eb/pn1IUbkbyIuPrJG3V0t366dI6hRR0Xew5cdVb8ocewfROx7BZkpcZhON7hHfRAU+5uvvR/VdEfsYVDfjvX3V3znJQRamKYbjnisZ9XZGdIlR9Yoa6/XBqtCOqW7Vxf3iX4h66Pb1z/HxXa/pdpM5WXteX502Uz9Ji+2BbY9+5juF41q/54vHGIJzOu1awjRTGXEoX/r7/9jopyWvrd4nGihsfhNl9jz3saULxjbfq86plL1vTugc62G9Ig+XN1UZWt0Jtp4jPioD0Pjce+l7/XFXRdnbM8nde8V6n7XSE4Qsy+bquqmukvxmsJZt49Sb+wfVs/qtefLi3iEovW1xeN1If7TIuseh09KYx/5W9vQbvH526/6MdCPx2jHOj9dhiN6pWV1PXJ53+jWmW3KrmrFZ4TMD966JTMWb4/9Ma3w7f2le+z+sSpdkhH1SZWassmr2F+bV+x0yPvjLJWagFVfRrEMxU/N3pylmRva3vqJ8WaYZtuc2TtjxgwdeeSROuWUUyRJf/jDH/T0008nuarWV+GVviqRTjus7mxa0bp+rvTfdXs+nDut0qjjpHGnR7/Pr7dI178nvTJSOjzGv43nl0qTF9S9hN0/TBp5dHT78QakfyyR3lotlXmlTi7pwqOlKwZI9ii/1P+0WLr2v3VvIJ4/TxoU45dADy+UXvhGuvp46Y+Do9/P0q3Sje9Lmyrqfj6snfTY2dLAGOoLmdL766ThebFNgbnzI+nl5Wo0VeK3faWHh0W/z5nLpMc+ly4fKF1/YvT72VIp/f4NaeOP91uPDOkfv5KO6RL9PiVpe7XUJcov9O6YL732nfY7lHvo4dJzv45836YpfbtD6tsptse03telUplHGnZE7PuSpBqf5LLH51vfv8yT1pVJsy+Oz/6WlEjHdov+uWNvW6uknW7p2Ph8Gari3VKvrNh/z5JKadSb0m6P9OBQaWjv2Pf50QZpcE/JGeNnuBqfdNdH0tZq6a+nSsd1i21/Ut3+rjle6hGHmQlPfiF9tkV6doSUFuOXtbvc0tSvpFNzpLN6x15bVa20YbfUPw73mST9UCN1dCqmLxvqmaZU45fS4/AF9w/Vda83J/WQrjw+9v1VeqUVP0inHhbbfrZVSQVvSBvKpVRr3Xua+8+Kvb54WbNTuuND6Yj20gNDY/+b37Bb+vdK6dZTY9/XLrd05gxpQHdpxvmx7UuSvtwsPfaV9OJ58Xkuf3aJdEL3uvriocYX+/NHvZU/SNkZUvvYlxXUKyvq3qv+Y4SUmxX7/uaskXpnScfE4TXQH5SWbZNO6BH7viTpfxuk7hlSn+hnlDcwzbr3SB3j8BhI0tdbpU5O6bCs2Pf19FfStK+lJ8+RTo/xOU6Spi+WurikC/rGvq+SSumvhdK0c6WMOAzieWOl1N4pnRHj6+l/vpPu/kSqrJU6OKW/DZPOPDy2fQZ+DIBtB/lJlNtsqPT555/r66+/1tixY7V27Vq9/vrruuOOO1q8XWlpaQKqax3Z2dlxqz/445zQL7elyjBMDcvxaMThnrh88IoXT8CQYZhKPcj/yOIpZEqryuzq1LmzOgdL4/TNWewCIemBr9tp+U6HTEl9O/h1xwnlUY1Aaw0/1Fg0c3W6AqahS/pUKzczuaMeg6Y06YssLdyaqpqfLNqdYgnpuM4+PXBqWVz+NuL5vIKDH/2CcNErjW13WzRng0s9MwIanuNtU++3ko1eQSToF4SrNXrlwy0pWrQ1VWf19Ghw9zgtyngQyc7ObnZ7mw2VQqGQnn32WW3atEmmaeq6665Tjx4tR9QH8pMQT6IIV1vtlfpnE95Mh2f5TrteWpOuHW6rTNUt3P/bI2t0SrfauN2HbbVX0DbRLwgXvYJw0SuIBP2CcNEribevUCm207W0IovFoquvvjrZZQCIAGFSZPp38uvBTruTXQYAAAAARKXNLtQNAAAAAACAtotQCQAAAAAAABEjVAIAAAAAAEDECJUAAAAAAAAQMUIlAAAAAAAARIxQCQAAAAAAABEjVAIAAAAAAEDECJUAAAAAAAAQMcM0TTPZRQAAAAAAAODAwkglAAAAAAAARIxQCQAAAAAAABEjVAIAAAAAAEDECJUAAAAAAAAQMUIlAAAAAAAARIxQCQAAAAAAABGzJbuAQ10oFNKzzz6r4uJi2e12/eEPf1C3bt2SXRbamFtvvVUul0uS1KVLF40cOVJTp06VYRjKycnRmDFjZLGQER/K1q1bp5dfflkTJ07Utm3bmu2PwsJCFRYWymq1auTIkRo0aFCyy0YS7N0rRUVFeuCBB9S9e3dJ0vDhw3XKKafQK1AgENC0adO0Y8cO+f1+XXjhherZsyfPLWiiuV7p0KEDzy1oVigU0tNPP62tW7fKYrHo2muvlSSeW9BEc73idrt5bmmDCJWS7KuvvpLf79d9992ntWvXaubMmbr11luTXRbaEJ/PJ0maOHFiw7YHHnhABQUFOuaYY/TMM89o8eLFOvHEE5NUIZLtrbfe0ieffKLU1FRJ0owZM5r0R58+fTR37lxNmTJFfr9f48ePV//+/WW325NcPRLpp72yYcMG/epXv9KIESMarlNeXk6vQAsWLFBGRoZuuOEGVVVV6dZbb1Vubi7PLWiiuV75zW9+w3MLmrV48WJJ0j333KOVK1dq5syZMk2T5xY00VyvDBo0iOeWNohQKclWr16tAQMGSJL69Omj77//PrkFoc0pLi5WbW2t7r33XgWDQV1yySUqKipS3759JUkDBw7UsmXLCJUOYV27dtUtt9yiJ598UpKa7Q+LxaL8/HzZ7XbZ7XZ169ZNxcXFysvLS2bpSLDmeqW0tFSLFy9Wt27dNHr0aK1fv55egU4++WQNHjy44Wer1cpzC5q1r17huQXNOfHEExtGkezYsUPt2rXTkiVLeG5BE831Cs8tbROhUpJ5PJ6GaU2SZLFYFAwGZbVak1gV2pKUlBSNGDFCZ511lrZu3ar7779fkmQYhiTJ6XTK7XYns0Qk2eDBg7V9+/ZG237aH263u9FzDX1zaPppr+Tl5emss85S79699cYbb+g///mPcnNz6RU0jGbzeDx65JFHVFBQoH/+8588t6CJ5nrF7/fz3IJ9slqtevLJJ/XVV1/pz3/+s5YsWcJzC5r1014pKyvjuaUNYhGWJHM6nfJ4PA0/m6ZJoIRGunfvriFDhsgwDGVnZys9PV3l5eUNl3s8HqWlpSWvQLQ59W/MpD394XK55PV6m2zHoe3EE09U7969G/69ceNGegUNdu7cqUmTJun000/XaaedxnML9umnvcJzC1py/fXX67HHHtP06dMblnqQeG5BU3v3ynHHHcdzSxtEqJRk+fn5Wrp0qSRp7dq16tWrV5IrQlvz0UcfaebMmZKksrIyeTweHXfccVq5cqUkaenSpTr66KOTWSLamNzc3Cb9kZeXp1WrVsnn88ntdqukpEQ5OTlJrhTJdt9992n9+vWSpBUrVqh37970CiTVrVFx33336fe//73OPPNMSTy3oHnN9QrPLdiXTz75RLNnz5YkORwOGYah3r1789yCJprrlYcffpjnljbIME3TTHYRh7L6s79t2rRJpmnquuuuU48ePZJdFtqQQCCgqVOnaufOnTIMQ7///e+VkZGh6dOnKxAIqEePHvrDH/7A2d8Ocdu3b9djjz2m++67T6Wlpc32R2FhoebPn69QKKQLLrig0RoYOHTs3StFRUV6/vnnZbPZlJWVpauvvloul4tegV544QUtXLiw0XuS0aNH64UXXuC5BY001ysFBQV66aWXeG5BE16vV0899ZQqKioUCAR0/vnnq0ePHrxvQRPN9UrHjh1539IGESoBAAAAAAAgYgxtAAAAAAAAQMQIlQAAAAAAABAxQiUAAAAAAABEjFAJAAAAAAAAESNUAgAAAAAAQMQIlQAAAAAAABAxQiUAAAAAAABEzJbsAgAAANq6lStX6sUXX1RKSoq8Xq8uvvhizZ49W4FAQCkpKRo1apT69OmjYDCol156SUuWLJHFYlF+fr6uvPJK2Ww2vfHGG/riiy8UCoXUuXNnXXnllerQoYMmTpyoPn36aM2aNdq5c6eOPfZYXX311bJYLPr666/1r3/9S6ZpKiUlRVdddZWWLFmiLVu26MYbb5QkrV69Ws8//7wefPDBJN9LAADgUEOoBAAAEIZNmzbpySefVCAQ0MMPP6yJEycqIyNDmzdv1j333KPHH39cH374oYqKivTQQw/JZrPpscce08KFC2WapjZt2qTJkyfLarWqsLBQ06dP1+233y5J2rZtmyZMmCCv16s//elP+u6779SzZ0898cQTmjBhgg4//HB98cUXeuWVVzR27FjdeOONqq6uVnp6ugoLCzVs2LAk3zsAAOBQRKgEAAAQhk6dOqlz5856//33VV5errvvvrvhMsMwtG3bNq1YsUJDhgyRw+GQJP3pT3+SJD3yyCP6/vvvddttt0mSQqGQfD5fw+1POOEEWSwWuVwudevWTdXV1VqzZo1ycnJ0+OGHS5JOOukknXTSSZKkQYMG6ZNPPtGQIUO0bNkyXXnllQm5DwAAAPZGqAQAABCG1NRUSXWBUL9+/RoCI0nauXOnOnToIKvVKsMwGraXl5fLNE2FQiGdd955Gj58uCTJ7/erpqam4Xr1IZSkhtv/dF/1o50OO+wwnX322Xr22WdlsVh00kknNdQGAACQSCzUDQAAEIFjjz1Wy5cvV0lJiSRpyZIl+stf/iKfz6djjz1Wn376qfx+v0KhkJ599ll99tlnGjBggObPny+32y1Jeu211/TEE0/s9zh5eXkqKSnR5s2bJUlfffVVw23y8/NlGIbmzJnD1DcAAJA0jFQCAACIQM+ePXX11Vfr0UcflSRZLBbdeuutSk1N1bBhw7Rjxw7ddtttMk1Tffv21TnnnCPDMFRWVqZx48bJMAx16tRJY8eO3e9xsrKydMMNN2jq1KkKBoNyuVy66aabGi7/xS9+oUWLFumwww5rxd8WAABg3wzTNM1kFwEAAIDwBYNBPfTQQxoyZIhOOeWUZJcDAAAOUUx/AwAAOIBs2bJFV155pTIzMzV48OBklwMAAA5hjFQCAAAAAABAxBipBAAAAAAAgIgRKgEAAAAAACBihEoAAAAAAACIGKESAAAAAAAAIkaoBAAAAAAAgIgRKgEAAAAAACBi/x/zZF7rg0qUTAAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 1440x360 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "# Scatterplot to explore the distribution of customers\n",
    "# Using 'monetary' as the size of the points, we see that \n",
    "# the majority of customers who spend the most also purchase more frequently\n",
    "\n",
    "plt.style.use('ggplot')\n",
    "rfm.plot.scatter(x='recency',\n",
    "                 y='frequency',\n",
    "                 s=rfm['monetary']*5e-5,\n",
    "                 figsize=(20,5),\n",
    "                 c='dodgerblue')\n",
    "\n",
    "plt.gca().set(xlabel='recency',\n",
    "              ylabel='frequency',\n",
    "              title='Customer distribution');"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 65,
   "metadata": {
    "id": "KmxTpRsMvmqD"
   },
   "outputs": [],
   "source": [
    "# Export the dataframe to a CSV file for processing in PowerBI\n",
    "# (We added the parameter float_format='%.2f' for setting numbers to two decimals)\n",
    "\n",
    "rfm.to_csv('RFM_Asia.csv',\n",
    "           encoding='utf-8',\n",
    "           index=False,\n",
    "           float_format='%.2f')"
   ]
  }
 ],
 "metadata": {
  "colab": {
   "collapsed_sections": [],
   "include_colab_link": True,
   "name": "customer_segmentation_asia.ipynb",
   "provenance": []
  },
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 1
}